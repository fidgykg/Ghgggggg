import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nodecraft.app',
  appName: 'NodeCraft',
  webDir: 'dist',
};

export default config;
