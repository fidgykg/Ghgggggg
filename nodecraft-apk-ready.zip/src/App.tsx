import React, { useState, useEffect } from 'react';
import { Crown, ShieldCheck, Shield, Megaphone, X, Sparkles, LogIn, CheckCircle } from 'lucide-react';
import { Header } from './components/Header';
import { MetricsBar } from './components/MetricsBar';
import { ServerCard } from './components/ServerCard';
import { ServerDetail } from './components/ServerDetail';
import { NewServerModal } from './components/NewServerModal';
import { PortManagerView } from './components/PortManagerView';
import { NetworkView } from './components/NetworkView';
import { SnapshotsView } from './components/SnapshotsView';
import { AdminPanelModal } from './components/AdminPanelModal';
import { ChatModeratorView } from './components/ChatModeratorView';
import { SuggestionsView } from './components/SuggestionsView';
import { LoginModal } from './components/LoginModal';
import { AccountProfileModal } from './components/AccountProfileModal';
import { LocalServer, LocalNetworkInfo } from './types/server';
import { Language, I18N } from './utils/i18n';
import {
  loadSavedServers,
  saveServers,
  loadNetworkInfo,
  saveNetworkInfo,
} from './utils/storage';
import { useAuth } from './contexts/AuthContext';
import { SUPER_ADMIN_EMAIL } from './lib/firebase';

export default function App() {
  const [servers, setServers] = useState<LocalServer[]>(() => loadSavedServers());
  const [networkInfo, setNetworkInfo] = useState<LocalNetworkInfo>(() => loadNetworkInfo());
  const [selectedServerId, setSelectedServerId] = useState<string>('mc-paper-01');
  const [currentTab, setCurrentTab] = useState<'servers' | 'ports' | 'network' | 'snapshots' | 'chat' | 'suggestions'>('servers');
  const [lang, setLang] = useState<Language>('ar');
  const [isNewServerModalOpen, setIsNewServerModalOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // Global Admin Announcement state (persisted)
  const [adminNotice, setAdminNotice] = useState<string>(() => {
    return localStorage.getItem('ahop508_admin_notice') || '';
  });

  const {
    currentUser,
    userProfile,
    isAdmin,
    isSuperAdmin,
    isChatModerator,
    authNotice,
    authError,
    clearAuthNotice,
    clearAuthError,
    signInWithGoogle,
    isAccountModalOpen,
    setIsAccountModalOpen,
  } = useAuth();

  const handleUpdateAdminNotice = (notice: string) => {
    setAdminNotice(notice);
    if (notice) {
      localStorage.setItem('ahop508_admin_notice', notice);
    } else {
      localStorage.removeItem('ahop508_admin_notice');
    }
  };

  // Sync document language and direction
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  // Persist servers
  useEffect(() => {
    saveServers(servers);
  }, [servers]);

  // Persist network info
  useEffect(() => {
    saveNetworkInfo(networkInfo);
  }, [networkInfo]);

  // Subtle live metrics simulation (Uptime, RAM, CPU fluctuation)
  useEffect(() => {
    const interval = setInterval(() => {
      setServers((prev) =>
        prev.map((srv) => {
          if (srv.status !== 'online') return srv;

          // Gentle random drift for live feel
          const cpuDrift = (Math.random() - 0.48) * 1.5;
          const newCpu = Math.max(
            1.0,
            Math.min(95, parseFloat((srv.metrics.cpuUsage + cpuDrift).toFixed(1)))
          );

          return {
            ...srv,
            metrics: {
              ...srv.metrics,
              uptimeSeconds: srv.metrics.uptimeSeconds + 1,
              cpuUsage: newCpu,
            },
          };
        })
      );
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const selectedServer = servers.find((s) => s.id === selectedServerId) || servers[0] || null;

  // Server Actions
  const handleStartServer = (id: string) => {
    const time = new Date().toLocaleTimeString('en-GB');

    // Step 1: Set to starting
    setServers((prev) =>
      prev.map((s) => {
        if (s.id !== id) return s;
        return {
          ...s,
          status: 'starting',
          logs: [
            ...s.logs,
            {
              id: `boot-${Date.now()}`,
              timestamp: time,
              level: 'INFO',
              message: `[System] Initializing server environment... Allocating ${s.allocatedRamMB}MB RAM.`,
            },
          ],
        };
      })
    );

    // Step 2: Complete boot sequence
    setTimeout(() => {
      const finishTime = new Date().toLocaleTimeString('en-GB');
      setServers((prev) =>
        prev.map((s) => {
          if (s.id !== id) return s;

          const baseMem = Math.floor(s.allocatedRamMB * 0.45);
          const completionLog =
            s.type === 'minecraft'
              ? `Done (1.824s)! For help, type "help". Listening on 0.0.0.0:${s.port}`
              : s.type === 'web'
              ? `HTTP Server listening on port ${s.port} (Ready for local connections)`
              : `Server initialized and listening on port ${s.port}`;

          return {
            ...s,
            status: 'online',
            metrics: {
              ...s.metrics,
              uptimeSeconds: 1,
              cpuUsage: s.type === 'minecraft' ? 12.8 : 2.0,
              memoryUsageMB: baseMem,
              tps: s.type === 'minecraft' ? 20.0 : undefined,
            },
            logs: [
              ...s.logs,
              {
                id: `boot-done-${Date.now()}`,
                timestamp: finishTime,
                level: 'INFO',
                message: completionLog,
              },
            ],
          };
        })
      );
    }, 1200);
  };

  const handleStopServer = (id: string) => {
    const time = new Date().toLocaleTimeString('en-GB');
    setServers((prev) =>
      prev.map((s) => {
        if (s.id !== id) return s;
        return {
          ...s,
          status: 'offline',
          players: [],
          metrics: {
            ...s.metrics,
            cpuUsage: 0,
            memoryUsageMB: 0,
            uptimeSeconds: 0,
          },
          logs: [
            ...s.logs,
            {
              id: `stop-${Date.now()}`,
              timestamp: time,
              level: 'INFO',
              message: `Server stopped gracefully. Port ${s.port} released.`,
            },
          ],
        };
      })
    );
  };

  const handleRestartServer = (id: string) => {
    handleStopServer(id);
    setTimeout(() => {
      handleStartServer(id);
    }, 600);
  };

  // Batch Admin Server Operations
  const handleStartAllServers = () => {
    servers.forEach((s) => {
      if (s.status === 'offline') {
        handleStartServer(s.id);
      }
    });
  };

  const handleStopAllServers = () => {
    servers.forEach((s) => {
      if (s.status !== 'offline') {
        handleStopServer(s.id);
      }
    });
  };

  const handleRestartAllServers = () => {
    servers.forEach((s) => {
      handleRestartServer(s.id);
    });
  };

  const handleDeleteServer = (id: string) => {
    setServers((prev) => {
      const filtered = prev.filter((s) => s.id !== id);
      if (selectedServerId === id && filtered.length > 0) {
        setSelectedServerId(filtered[0].id);
      }
      return filtered;
    });
  };

  const handleCreateServer = (newServer: LocalServer) => {
    setServers((prev) => [newServer, ...prev]);
    setSelectedServerId(newServer.id);
    setCurrentTab('servers');
  };

  const handleUpdateServer = (updated: LocalServer) => {
    setServers((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
  };

  const handleRestoreSnapshot = (serverId: string, snapshotName: string) => {
    setServers((prev) =>
      prev.map((s) => {
        if (s.id !== serverId) return s;
        return {
          ...s,
          logs: [
            ...s.logs,
            {
              id: `rest-${Date.now()}`,
              timestamp: new Date().toLocaleTimeString('en-GB'),
              level: 'WARN',
              message: `Snapshot "${snapshotName}" restored into active storage.`,
            },
          ],
        };
      })
    );
  };

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'ar' ? 'en' : 'ar'));
  };

  const t = I18N[lang];

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* Top Header */}
      <Header
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        onOpenNewServer={() => setIsNewServerModalOpen(true)}
        onOpenAdminPanel={() => setIsAdminPanelOpen(true)}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        lang={lang}
        onToggleLang={toggleLanguage}
        localIp={networkInfo.localIp}
      />

      {/* Auth Status Notification / Fallback Banner */}
      {authNotice && (
        <div className="bg-sky-500/15 border-b border-sky-500/30 px-4 py-2 text-xs text-sky-200">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-sky-400 shrink-0" />
              <span>{authNotice}</span>
            </div>
            <button
              onClick={clearAuthNotice}
              className="text-sky-300 hover:text-white font-bold px-2 py-0.5"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {authError && (
        <div className="bg-rose-500/15 border-b border-rose-500/30 px-4 py-2 text-xs text-rose-200">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <X className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{authError}</span>
            </div>
            <button
              onClick={clearAuthError}
              className="text-rose-300 hover:text-white font-bold px-2 py-0.5"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Global Admin Broadcast Announcement Banner */}
      {adminNotice && (
        <div className="bg-gradient-to-r from-amber-500/20 via-emerald-500/15 to-amber-500/20 border-b border-amber-500/30 px-4 py-2.5 text-xs text-amber-200">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="p-1 rounded bg-amber-500/20 text-amber-300 shrink-0">
                <Megaphone className="w-3.5 h-3.5" />
              </span>
              <span className="font-bold text-amber-300 shrink-0">
                {lang === 'ar' ? 'إشعار من إدارة النظام:' : 'Admin Broadcast:'}
              </span>
              <span className="truncate">{adminNotice}</span>
            </div>

            {isAdmin && (
              <button
                onClick={() => handleUpdateAdminNotice('')}
                className="text-amber-400/80 hover:text-white shrink-0 p-1 rounded"
                title={lang === 'ar' ? 'إغلاق الإشعار' : 'Dismiss notice'}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Super Admin Welcome Banner if logged in as ahmedopyj@gmail.com */}
      {isSuperAdmin && (
        <div className="bg-neutral-900/60 border-b border-amber-500/20 px-4 py-2 text-xs">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-amber-300">
              <Crown className="w-4 h-4 text-amber-400" />
              <span>
                {lang === 'ar'
                  ? `مرحباً بك يا مدير النظام الأعلى (${SUPER_ADMIN_EMAIL}) - تمتلك صلاحيات تحكم كاملة وتعيين المشرفين`
                  : `Welcome Super Admin (${SUPER_ADMIN_EMAIL}) - Root access & role promotion unlocked`}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsAdminPanelOpen(true)}
                className="text-[11px] font-semibold text-amber-400 hover:text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-md border border-amber-500/30 transition-colors"
              >
                {lang === 'ar' ? 'لوحة الإدارة' : 'Admin Panel'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Guest Sign In Callout (if not logged in) */}
      {!currentUser && (
        <div className="bg-neutral-900/40 border-b border-neutral-800 px-4 py-2 text-xs text-neutral-400">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>
                {lang === 'ar'
                  ? 'سجّل دخولك بحساب Google أو كعضو للوصول إلى الشات والاقتراحات وإدارة السيرفرات.'
                  : 'Sign in with your Google account or as a member to access chat and suggestions.'}
              </span>
            </div>
            <button
              onClick={() => setIsLoginModalOpen(true)}
              className="text-[11px] font-medium text-emerald-400 hover:text-emerald-300 underline"
            >
              {lang === 'ar' ? 'تسجيل الدخول الآن' : 'Sign in now'}
            </button>
          </div>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* System Resource Overview */}
        <MetricsBar servers={servers} lang={lang} />

        {/* Tab 1: SERVERS & WORKSTATION */}
        {currentTab === 'servers' && (
          <div className="space-y-6">
            {/* Servers Grid */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold text-white tracking-tight">
                    {lang === 'ar' ? 'السيرفرات المثبتة محلياً' : 'Locally Installed Servers'}
                  </h2>
                  <span className="text-xs font-mono text-neutral-400">
                    ({servers.length})
                  </span>
                  {isAdmin && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/20 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" />
                      {lang === 'ar' ? 'وضع المشرف نشط' : 'Admin Mode Active'}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {isAdmin && (
                    <button
                      onClick={() => setIsAdminPanelOpen(true)}
                      className="text-xs font-medium text-amber-400 hover:text-amber-300 flex items-center gap-1 px-2.5 py-1 rounded bg-amber-500/10 border border-amber-500/20"
                    >
                      <Crown className="w-3 h-3" />
                      <span>{lang === 'ar' ? 'خيارات الإدارة والتحكم' : 'Admin Controls'}</span>
                    </button>
                  )}
                  <span className="text-xs text-neutral-400 hidden sm:inline">
                    {lang === 'ar' ? 'اضغط على أي سيرفر لفتح وحدة التحكم والإعدادات' : 'Click any server to launch console & workstation'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {servers.map((srv) => (
                  <ServerCard
                    key={srv.id}
                    server={srv}
                    isSelected={selectedServer?.id === srv.id}
                    onSelect={() => setSelectedServerId(srv.id)}
                    onStart={handleStartServer}
                    onStop={handleStopServer}
                    onRestart={handleRestartServer}
                    lang={lang}
                    localIp={networkInfo.localIp}
                  />
                ))}
              </div>
            </div>

            {/* Selected Server Full Workstation Detail */}
            {selectedServer ? (
              <div className="mt-8">
                <ServerDetail
                  key={selectedServer.id}
                  server={selectedServer}
                  onUpdateServer={handleUpdateServer}
                  onDeleteServer={handleDeleteServer}
                  onStart={handleStartServer}
                  onStop={handleStopServer}
                  onRestart={handleRestartServer}
                  lang={lang}
                  localIp={networkInfo.localIp}
                />
              </div>
            ) : (
              <div className="py-16 text-center border border-dashed border-neutral-800 rounded-xl">
                <p className="text-neutral-400 text-sm mb-3">{t.selectServerToView}</p>
                <button
                  onClick={() => setIsNewServerModalOpen(true)}
                  className="px-4 py-2 bg-emerald-400 text-neutral-950 font-bold text-xs rounded-lg shadow-sm"
                >
                  {t.newServerBtn}
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: PORT MAP & DETECTOR */}
        {currentTab === 'ports' && (
          <PortManagerView servers={servers} lang={lang} />
        )}

        {/* Tab 3: LAN & NETWORK GUIDE */}
        {currentTab === 'network' && (
          <NetworkView
            servers={servers}
            networkInfo={networkInfo}
            onUpdateNetworkInfo={setNetworkInfo}
            lang={lang}
          />
        )}

        {/* Tab 4: SYSTEM SNAPSHOTS ARCHIVE */}
        {currentTab === 'snapshots' && (
          <SnapshotsView
            servers={servers}
            onRestoreSnapshot={handleRestoreSnapshot}
            lang={lang}
          />
        )}

        {/* Tab 5: SERVER CHAT & MODERATOR */}
        {currentTab === 'chat' && (
          <ChatModeratorView lang={lang} />
        )}

        {/* Tab 6: COMMUNITY SUGGESTIONS */}
        {currentTab === 'suggestions' && (
          <SuggestionsView lang={lang} />
        )}
      </main>

      {/* New Server Creation Wizard Modal */}
      <NewServerModal
        isOpen={isNewServerModalOpen}
        onClose={() => setIsNewServerModalOpen(false)}
        onCreateServer={handleCreateServer}
        existingServers={servers}
        lang={lang}
      />

      {/* System Admin Control & User Management Modal */}
      <AdminPanelModal
        isOpen={isAdminPanelOpen}
        onClose={() => setIsAdminPanelOpen(false)}
        lang={lang}
        servers={servers}
        onStartAllServers={handleStartAllServers}
        onStopAllServers={handleStopAllServers}
        onRestartAllServers={handleRestartAllServers}
        adminNotice={adminNotice}
        onUpdateAdminNotice={handleUpdateAdminNotice}
      />

      {/* Login & Role Selection Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        lang={lang}
      />

      {/* Account Profile & Avatar Customization Modal */}
      <AccountProfileModal
        isOpen={isAccountModalOpen}
        onClose={() => setIsAccountModalOpen(false)}
        lang={lang}
      />
    </div>
  );
}
