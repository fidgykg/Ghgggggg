import { LocalServer } from '../types/server';

export const INITIAL_SERVERS: LocalServer[] = [
  {
    id: 'mc-paper-01',
    name: 'سيرفر ماين كرافت (PaperMC SMP)',
    type: 'minecraft',
    port: 25565,
    status: 'online',
    autoRestart: true,
    allocatedRamMB: 4096,
    createdAt: '2026-10-28 14:30',
    imageBanner: '/src/assets/images/minecraft_server_hero_1793499576781.jpg',
    description: 'سيرفر سرفايفل محلي متوافق مع ماين كرافت الجافا 1.21.1 يدعم الإضافات وأداء عالي على الشبكة المحلية.',
    metrics: {
      cpuUsage: 14.5,
      memoryUsageMB: 1840,
      memoryAllocatedMB: 4096,
      tps: 20.0,
      uptimeSeconds: 7420,
      networkInKBps: 24.8,
      networkOutKBps: 118.2,
    },
    logs: [
      {
        id: 'log-1',
        timestamp: '19:15:02',
        level: 'INFO',
        message: 'Starting minecraft server version 1.21.1-R0.1-SNAPSHOT (PaperMC)',
      },
      {
        id: 'log-2',
        timestamp: '19:15:04',
        level: 'INFO',
        message: 'Loading properties from server.properties [port=25565, pvp=true, online-mode=false]',
      },
      {
        id: 'log-3',
        timestamp: '19:15:06',
        level: 'INFO',
        message: 'Preparing level "world" [Seed: 84920491823901]...',
      },
      {
        id: 'log-4',
        timestamp: '19:15:09',
        level: 'INFO',
        message: 'Preparing spawn area: 100% [Done in 2.84s]',
      },
      {
        id: 'log-5',
        timestamp: '19:15:10',
        level: 'INFO',
        message: 'Server listening on 0.0.0.0:25565. LAN broadcast active!',
      },
      {
        id: 'log-6',
        timestamp: '19:16:30',
        level: 'INFO',
        message: 'AhmedCraft[/192.168.1.105:54120] logged in with entity id 142 at (124.5, 68.0, -89.2)',
      },
      {
        id: 'log-7',
        timestamp: '19:18:12',
        level: 'INFO',
        message: 'Omar_Sniper[/192.168.1.112:54122] logged in with entity id 143 at (130.0, 67.5, -85.0)',
      },
      {
        id: 'log-8',
        timestamp: '19:18:40',
        level: 'INFO',
        message: '<AhmedCraft> يا شباب بنيت القلعة بجانب النهر، تعالوا نجمع دايموند!',
      },
    ],
    players: [
      {
        id: 'p-1',
        name: 'AhmedCraft',
        uuid: '4f2d9c12-3b6a-4d29-a548-81e05a819b10',
        ping: 4,
        health: 20,
        isOp: true,
        joinedAt: '19:16',
        gamemode: 'survival',
      },
      {
        id: 'p-2',
        name: 'Omar_Sniper',
        uuid: '7c8a1109-12aa-41f2-95cd-456720188bc3',
        ping: 12,
        health: 18,
        isOp: false,
        joinedAt: '19:18',
        gamemode: 'survival',
      },
      {
        id: 'p-3',
        name: 'NoobMaster',
        uuid: '89104bce-9811-402a-9ac2-120938491201',
        ping: 28,
        health: 14,
        isOp: false,
        joinedAt: '19:22',
        gamemode: 'survival',
      },
    ],
    minecraftConfig: {
      motd: 'سيرفر الأصدقاء المحلي §a[Survival 1.21.1] §e- أهلاً بالجميع!',
      maxPlayers: 20,
      gamemode: 'survival',
      difficulty: 'normal',
      pvp: true,
      hardcore: false,
      viewDistance: 12,
      onlineMode: false,
      allowFlight: false,
      spawnProtection: 16,
      seed: '84920491823901',
      serverSoftware: 'PaperMC',
      version: '1.21.1',
    },
    plugins: [
      {
        id: 'pl-1',
        name: 'WorldEdit',
        fileName: 'WorldEdit-7.3.0.jar',
        version: '7.3.0',
        author: 'sk89q, EngineHub',
        enabled: true,
        description: 'أقوى أداة لبناء وتعديل وتشكيل عوالم ماين كرافت بالأوامر السريعة والفرشاة.',
        category: 'world',
        fileSizeMB: 4.8,
      },
      {
        id: 'pl-2',
        name: 'EssentialsX',
        fileName: 'EssentialsX-2.20.1.jar',
        version: '2.20.1',
        author: 'EssentialsX Team',
        enabled: true,
        description: 'إضافة الأوامر الأساسية لسيرفرات سرفايفل (الانتقال السريع /home، /spawn، /tpa، والاقتصاد).',
        category: 'admin',
        fileSizeMB: 3.2,
      },
      {
        id: 'pl-3',
        name: 'Geyser-Spigot',
        fileName: 'Geyser-Spigot-2.4.0.jar',
        version: '2.4.0',
        author: 'GeyserMC',
        enabled: true,
        description: 'جسر يتيح للاعبي ماين كرافت بيدروك (الجوال والكونسول) الدخول إلى سيرفر الجافا المحلي!',
        category: 'utility',
        fileSizeMB: 18.5,
      },
      {
        id: 'pl-4',
        name: 'LuckPerms',
        fileName: 'LuckPerms-Bukkit-5.4.102.jar',
        version: '5.4.102',
        author: 'Luck',
        enabled: true,
        description: 'نظام إدارة رتب وصلاحيات اللاعبين والمشرفين باحترافية وسهولة فائقة.',
        category: 'protection',
        fileSizeMB: 2.1,
      },
      {
        id: 'pl-5',
        name: 'ClearLag',
        fileName: 'Clearlag-3.2.2.jar',
        version: '3.2.2',
        author: 'bob7l',
        enabled: false,
        description: 'إزالة الأدوات الملقاة في العالم وتنظيف الذاكرة دورياً لتقليل اللاغ ورفع الـ TPS.',
        category: 'utility',
        fileSizeMB: 0.6,
      },
    ],
    files: [
      {
        path: '/server.properties',
        name: 'server.properties',
        isDirectory: false,
        sizeBytes: 1420,
        lastModified: '2026-10-28 14:32',
        content: `# Minecraft server properties
# Mon Oct 28 14:32:00 UTC 2026
enable-jmx-monitoring=false
rcon.port=25575
level-seed=84920491823901
gamemode=survival
enable-command-block=true
enable-query=false
generator-settings={}
enforce-secure-profile=false
level-name=world
motd=سيرفر الأصدقاء المحلي §a[Survival 1.21.1] §e- أهلاً بالجميع!
query.port=25565
pvp=true
generate-structures=true
difficulty=normal
network-compression-threshold=256
max-tick-time=60000
require-resource-pack=false
max-players=20
use-native-transport=true
online-mode=false
enable-status=true
allow-flight=false
broadcast-rcon-to-ops=true
view-distance=12
server-ip=0.0.0.0
resource-pack-prompt=
allow-nether=true
server-port=25565
enable-rcon=false
sync-chunk-writes=true
op-permission-level=4
prevent-proxy-connections=false
hide-online-players=false
entity-broadcast-range-percentage=100
simulation-distance=10
player-idle-timeout=0
force-gamemode=false
rate-limit=0
hardcore=false
white-list=false
broadcast-console-to-ops=true
spawn-npcs=true
spawn-animals=true
function-permission-level=2
initial-enabled-packs=vanilla
level-type=minecraft:normal
text-filtering-config=
spawn-monsters=true
enforce-whitelist=false
spawn-protection=16
resource-pack-sha1=
max-world-size=29999984`,
      },
      {
        path: '/eula.txt',
        name: 'eula.txt',
        isDirectory: false,
        sizeBytes: 180,
        lastModified: '2026-10-28 14:30',
        content: `# By changing the setting below to TRUE you are indicating your agreement to our EULA (https://aka.ms/MinecraftEULA).
# Mon Oct 28 14:30:00 UTC 2026
eula=true`,
      },
      {
        path: '/whitelist.json',
        name: 'whitelist.json',
        isDirectory: false,
        sizeBytes: 154,
        lastModified: '2026-10-28 14:35',
        content: `[
  {
    "uuid": "4f2d9c12-3b6a-4d29-a548-81e05a819b10",
    "name": "AhmedCraft"
  },
  {
    "uuid": "7c8a1109-12aa-41f2-95cd-456720188bc3",
    "name": "Omar_Sniper"
  }
]`,
      },
      {
        path: '/ops.json',
        name: 'ops.json',
        isDirectory: false,
        sizeBytes: 198,
        lastModified: '2026-10-28 14:35',
        content: `[
  {
    "uuid": "4f2d9c12-3b6a-4d29-a548-81e05a819b10",
    "name": "AhmedCraft",
    "level": 4,
    "bypassesPlayerLimit": true
  }
]`,
      },
      {
        path: '/paper-global.yml',
        name: 'paper-global.yml',
        isDirectory: false,
        sizeBytes: 2480,
        lastModified: '2026-10-28 14:32',
        content: `# Paper Global Configuration
messages:
  kick:
    connection-throttle: Connection throttled! Please wait before reconnecting.
timings:
  enabled: true
  verbose: true
  server-name: Local-NodeCraft-Paper
unsupported-settings:
  allow-piston-duplication: true
  perform-username-validation: false`,
      },
      {
        path: '/plugins/Essentials/config.yml',
        name: 'config.yml',
        isDirectory: false,
        sizeBytes: 1850,
        lastModified: '2026-10-28 15:00',
        content: `# EssentialsX Global Configuration
ops-name-color: 'c'
nickname-prefix: '~'
max-nick-length: 15
change-displayname: true
teleport-cooldown: 0
teleport-delay: 3
spawn-on-join: true
starting-balance: 500
currency-symbol: '$'`,
      },
      {
        path: '/logs/latest.log',
        name: 'latest.log',
        isDirectory: false,
        sizeBytes: 3420,
        lastModified: '2026-10-31 19:18',
        content: `[19:15:02] [Server thread/INFO]: Starting minecraft server version 1.21.1
[19:15:04] [Server thread/INFO]: Loading properties
[19:15:06] [Server thread/INFO]: Default game type: SURVIVAL
[19:15:08] [Server thread/INFO]: Generating spawn area: 100%
[19:15:10] [Server thread/INFO]: Done (2.84s)! For help, type "help"
[19:16:30] [User Authenticator #1/INFO]: UUID of player AhmedCraft is 4f2d9c12-3b6a-4d29-a548-81e05a819b10
[19:16:30] [Server thread/INFO]: AhmedCraft joined the game`,
      },
    ],
    backups: [
      {
        id: 'bak-1',
        name: 'نسخة أولية قبل بداية البناء',
        createdAt: '2026-10-28 15:00',
        sizeMB: 148,
        serverType: 'minecraft',
        description: 'نسخة احتياطية خفيفة لعالم البداية والإحداثيات الصفرية.',
      },
      {
        id: 'bak-2',
        name: 'تثبيت قلعة الحصن والمزرعة',
        createdAt: '2026-10-30 20:30',
        sizeMB: 312,
        serverType: 'minecraft',
        description: 'بعد بناء القلعة المائية ومزرعة القمح والأبقار.',
      },
    ],
  },
  {
    id: 'mc-fabric-04',
    name: 'سيرفر فابريك مودات (Fabric 1.21.1)',
    type: 'minecraft',
    port: 25567,
    status: 'online',
    autoRestart: true,
    allocatedRamMB: 6144,
    createdAt: '2026-10-30 18:00',
    imageBanner: '/src/assets/images/minecraft_server_hero_1793499576781.jpg',
    description: 'سيرفر ماين كرافت فابريك مودات مع تسريع الأداء ومودات عوالم وأصوات واقعية على الشبكة المحلية.',
    metrics: {
      cpuUsage: 16.2,
      memoryUsageMB: 2450,
      memoryAllocatedMB: 6144,
      tps: 20.0,
      uptimeSeconds: 3820,
      networkInKBps: 32.1,
      networkOutKBps: 145.6,
    },
    logs: [
      {
        id: 'fab-log-1',
        timestamp: '19:00:01',
        level: 'INFO',
        message: 'Loading Minecraft 1.21.1 with Fabric Loader 0.16.5...',
      },
      {
        id: 'fab-log-2',
        timestamp: '19:00:03',
        level: 'INFO',
        message: 'Loading 6 mods: fabricloader 0.16.5, fabric-api 0.100.1, lithium 0.12.7, ferritecore 6.0.3, voicechat 2.5.15, terralith 2.5.4',
      },
      {
        id: 'fab-log-3',
        timestamp: '19:00:05',
        level: 'INFO',
        message: '[Lithium] Successfully applied 112 physics and chunk optimizations.',
      },
      {
        id: 'fab-log-4',
        timestamp: '19:00:08',
        level: 'INFO',
        message: '[VoiceChat] Voice chat server listening on UDP port 24454',
      },
      {
        id: 'fab-log-5',
        timestamp: '19:00:10',
        level: 'INFO',
        message: 'Fabric Server loaded in 3.12s. World generation: Terralith Overworld active.',
      },
    ],
    players: [
      {
        id: 'p-fab-1',
        name: 'ModderPro',
        uuid: '11223344-5566-7788-9900-aabbccddeeff',
        ping: 8,
        health: 20,
        isOp: true,
        joinedAt: '19:05',
        gamemode: 'survival',
      },
    ],
    minecraftConfig: {
      motd: 'سيرفر فابريك المودات §b[Fabric 1.21.1 + Terralith] §aأداء خارق',
      maxPlayers: 16,
      gamemode: 'survival',
      difficulty: 'hard',
      pvp: true,
      hardcore: false,
      viewDistance: 14,
      onlineMode: false,
      allowFlight: true,
      spawnProtection: 8,
      seed: '91823901928341',
      serverSoftware: 'Fabric',
      version: '1.21.1',
    },
    mods: [
      {
        id: 'mod-1',
        name: 'Fabric API',
        fileName: 'fabric-api-0.100.1+1.21.jar',
        version: '0.100.1',
        author: 'FabricMC',
        enabled: true,
        description: 'المكتبة الأساسية لربط وتشغيل جميع مودات فابريك على السيرفر.',
        side: 'both',
        fileSizeMB: 2.4,
      },
      {
        id: 'mod-2',
        name: 'Lithium',
        fileName: 'lithium-fabric-0.12.7.jar',
        version: '0.12.7',
        author: 'CaffeineMC',
        enabled: true,
        description: 'مود تحسين الأداء العام للسيرفر والفيزياء وتسريع حسابات الريدستون والذكاء الاصطناعي.',
        side: 'server',
        fileSizeMB: 0.8,
      },
      {
        id: 'mod-3',
        name: 'FerriteCore',
        fileName: 'ferritecore-6.0.3-fabric.jar',
        version: '6.0.3',
        author: 'malte0811',
        enabled: true,
        description: 'تقليل استهلاك الذاكرة العشوائية (RAM) بنسبة تصل إلى 40% دون التأثير على اللعبة.',
        side: 'both',
        fileSizeMB: 0.3,
      },
      {
        id: 'mod-4',
        name: 'Simple Voice Chat',
        fileName: 'voicechat-fabric-1.21-2.5.15.jar',
        version: '2.5.15',
        author: 'henkelmax',
        enabled: true,
        description: 'شات صوتي تقاربي (Proximity Voice Chat) ثلاثي الأبعاد مع أصدقائك في اللعبة.',
        side: 'both',
        fileSizeMB: 5.6,
      },
      {
        id: 'mod-5',
        name: 'Terralith',
        fileName: 'Terralith_1.21_v2.5.4.jar',
        version: '2.5.4',
        author: 'Stardust Labs',
        enabled: true,
        description: 'إضافة ما يزيد عن 85 منطقة حيوية (Biomes) وجبال وأنهار مذهلة لعالم اللعبة.',
        side: 'both',
        fileSizeMB: 8.2,
      },
      {
        id: 'mod-6',
        name: 'Waystones',
        fileName: 'waystones-fabric-1.21-14.1.3.jar',
        version: '14.1.3',
        author: 'BlayTheNinth',
        enabled: false,
        description: 'أحجار تنقل سريعة قابلة للصنع للانتقال بين القرى والقلاع وعوالم الأصدقاء.',
        side: 'both',
        fileSizeMB: 1.1,
      },
    ],
    files: [
      {
        path: '/server.properties',
        name: 'server.properties',
        isDirectory: false,
        sizeBytes: 1380,
        lastModified: '2026-10-30 18:02',
        content: `server-port=25567
gamemode=survival
difficulty=hard
pvp=true
online-mode=false
motd=سيرفر فابريك المودات §b[Fabric 1.21.1 + Terralith] §aأداء خارق
max-players=16
view-distance=14
allow-flight=true
level-name=world`,
      },
      {
        path: '/fabric-server-launcher.properties',
        name: 'fabric-server-launcher.properties',
        isDirectory: false,
        sizeBytes: 120,
        lastModified: '2026-10-30 18:01',
        content: `serverJar=server.jar
fabricVersion=0.16.5
gameVersion=1.21.1`,
      },
      {
        path: '/config/voicechat/voicechat-server.properties',
        name: 'voicechat-server.properties',
        isDirectory: false,
        sizeBytes: 850,
        lastModified: '2026-10-30 18:05',
        content: `port=24454
bind_address=0.0.0.0
max_voice_distance=48.0
voice_chat_distance=48.0
codec=VOIP
mtu_size=1024`,
      },
    ],
    backups: [],
  },
  {
    id: 'web-node-02',
    name: 'خادم الويب المحلي (Local Web Server)',
    type: 'web',
    port: 8080,
    status: 'online',
    autoRestart: true,
    allocatedRamMB: 1024,
    createdAt: '2026-10-29 11:00',
    imageBanner: '/src/assets/images/web_server_datacenter_1793499577418.jpg',
    description: 'خادم ويب محلي فائق السرعة لتطوير واجهات المستخدم والمواقع الشخصية وتجربتها على أجهزة الشبكة المنزلية.',
    metrics: {
      cpuUsage: 2.1,
      memoryUsageMB: 185,
      memoryAllocatedMB: 1024,
      uptimeSeconds: 5200,
      networkInKBps: 12.4,
      networkOutKBps: 84.1,
    },
    logs: [
      {
        id: 'web-log-1',
        timestamp: '19:20:00',
        level: 'INFO',
        message: 'Node.js v20.12.0 HTTP Server initializing on port 8080...',
      },
      {
        id: 'web-log-2',
        timestamp: '19:20:01',
        level: 'INFO',
        message: 'Static directory mounted: ./public [CORS Enabled: true]',
      },
      {
        id: 'web-log-3',
        timestamp: '19:20:02',
        level: 'INFO',
        message: 'Server available at http://localhost:8080 and http://192.168.1.105:8080',
      },
      {
        id: 'web-log-4',
        timestamp: '19:21:15',
        level: 'INFO',
        message: 'GET / 200 OK - 12ms [User-Agent: Chrome/128]',
      },
      {
        id: 'web-log-5',
        timestamp: '19:21:16',
        level: 'INFO',
        message: 'GET /style.css 200 OK - 3ms',
      },
    ],
    webConfig: {
      documentRoot: '/var/www/html',
      framework: 'Static HTML',
      enableCors: true,
      htmlContent: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>موقعي المحلي | Local Web Hub</title>
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      margin: 0;
      padding: 0;
      background: #090d16;
      color: #f1f5f9;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      text-align: center;
    }
    .card {
      background: #111827;
      border: 1px solid #1f2937;
      padding: 2.5rem;
      border-radius: 1rem;
      max-width: 500px;
      margin: 1.5rem;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);
    }
    h1 {
      color: #38bdf8;
      margin-top: 0;
      font-size: 1.85rem;
    }
    p {
      color: #94a3b8;
      line-height: 1.6;
    }
    .badge {
      display: inline-block;
      background: #065f46;
      color: #34d399;
      padding: 0.25rem 0.75rem;
      border-radius: 9999px;
      font-size: 0.85rem;
      font-weight: bold;
      margin-bottom: 1rem;
    }
    button {
      background: #2563eb;
      color: white;
      border: none;
      padding: 0.6rem 1.4rem;
      border-radius: 0.5rem;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.2s;
    }
    button:hover {
      background: #1d4ed8;
    }
    #counter {
      font-size: 1.25rem;
      font-weight: bold;
      color: #fbbf24;
      margin-top: 1rem;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">يعمل محلياً على المنفذ :8080</div>
    <h1>أهلاً بك في موقعك المحلي! 🚀</h1>
    <p>هذا الموقع يعمل مباشرة عبر خادم الويب المحلي. يمكنك تعديل كود HTML وCSS في لوحة التحكم وتحديث المعاينة فوراً!</p>
    <button onclick="handleClick()">اضغط للتفاعل مع الخادم</button>
    <div id="counter">النقرات: 0</div>
  </div>

  <script>
    let count = 0;
    function handleClick() {
      count++;
      document.getElementById('counter').innerText = 'النقرات: ' + count;
    }
  </script>
</body>
</html>`,
      cssContent: `/* تم دمج الـ CSS في الـ HTML مباشرة لسهولة المعاينة */`,
      jsContent: `console.log("خادم الويب المحلي جاهز ويعمل!");`,
      routes: [
        { path: '/', method: 'GET', response: 'Index HTML Served' },
        { path: '/api/status', method: 'GET', response: '{"status":"ok","uptime":5200}' },
        { path: '/api/ping', method: 'GET', response: '{"pong":true}' },
      ],
    },
    files: [
      {
        path: '/public/index.html',
        name: 'index.html',
        isDirectory: false,
        sizeBytes: 1580,
        lastModified: '2026-10-29 11:15',
        content: `<!DOCTYPE html>\n<html lang="ar" dir="rtl">\n<head><title>Local Web</title></head>\n<body><h1>مرحباً بالعالم!</h1></body>\n</html>`,
      },
      {
        path: '/package.json',
        name: 'package.json',
        isDirectory: false,
        sizeBytes: 310,
        lastModified: '2026-10-29 11:00',
        content: `{\n  "name": "local-web-server",\n  "version": "1.0.0",\n  "main": "server.js",\n  "scripts": {\n    "start": "node server.js"\n  }\n}`,
      },
    ],
    backups: [],
  },
  {
    id: 'db-redis-03',
    name: 'خادم قاعدة بيانات وريديس (Redis In-Memory)',
    type: 'database',
    port: 6379,
    status: 'offline',
    autoRestart: false,
    allocatedRamMB: 512,
    createdAt: '2026-10-30 09:15',
    description: 'خادم تخزين مؤقت خفيف وفائق السرعة لمشاركة الجلسات وإحصائيات سيرفرات الألعاب وقوائم المتصدرين.',
    metrics: {
      cpuUsage: 0,
      memoryUsageMB: 0,
      memoryAllocatedMB: 512,
      uptimeSeconds: 0,
      networkInKBps: 0,
      networkOutKBps: 0,
    },
    logs: [
      {
        id: 'db-log-1',
        timestamp: '18:00:00',
        level: 'INFO',
        message: 'Redis server is ready on port 6379 [Standby mode]',
      },
    ],
    dbConfig: {
      dbType: 'redis',
      keys: [
        { key: 'mc:active_players', value: '3', type: 'string', ttl: 3600 },
        { key: 'mc:server_motd', value: 'سيرفر الأصدقاء المحلي', type: 'string', ttl: -1 },
        { key: 'session:ahmed', value: '{"role":"admin","ip":"192.168.1.105"}', type: 'json', ttl: 86400 },
        { key: 'web:total_hits', value: '142', type: 'integer', ttl: -1 },
      ],
    },
    files: [
      {
        path: '/redis.conf',
        name: 'redis.conf',
        isDirectory: false,
        sizeBytes: 820,
        lastModified: '2026-10-30 09:15',
        content: `port 6379\nbind 127.0.0.1 192.168.1.105\ntimeout 0\ntcp-keepalive 300\ndaemonize no\nmaxmemory 512mb\nmaxmemory-policy allkeys-lru`,
      },
    ],
    backups: [],
  },
];
