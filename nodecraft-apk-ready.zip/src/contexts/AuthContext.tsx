import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  collection,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
  addDoc,
  Timestamp,
} from 'firebase/firestore';
import { auth, googleProvider, db, SUPER_ADMIN_EMAIL, isSuperAdminEmail } from '../lib/firebase';

export type AppRole = 'superadmin' | 'admin' | 'moderator' | 'user';

export interface AppUserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  role: AppRole;
  isSuperAdmin: boolean;
  isMuted?: boolean;
  isBanned?: boolean;
  bannedAt?: Timestamp | null;
  banReason?: string;
  bannedByEmail?: string;
  warningsCount?: number;
  lastWarningReason?: string;
  createdAt?: Timestamp | null;
  lastLoginAt?: Timestamp | null;
}

export interface AdminRecord {
  uid: string;
  email: string;
  displayName: string;
  role: 'admin' | 'superadmin' | 'moderator';
  appointedBy: string;
  appointedByEmail: string;
  appointedAt?: Timestamp | null;
}

export interface AuditLogItem {
  id: string;
  action: string;
  performedByEmail: string;
  targetEmail: string;
  details: string;
  timestamp?: Timestamp | null;
}

interface AuthContextType {
  currentUser: { uid: string; email: string | null; displayName: string | null; photoURL: string | null } | null;
  userProfile: AppUserProfile | null;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  isChatModerator: boolean;
  loading: boolean;
  authError: string | null;
  authNotice: string | null;
  isLoginModalOpen: boolean;
  setIsLoginModalOpen: (open: boolean) => void;
  isAccountModalOpen: boolean;
  setIsAccountModalOpen: (open: boolean) => void;
  signInWithGoogle: () => Promise<void>;
  loginAs: (role: AppRole, email?: string, displayName?: string) => void;
  logout: () => Promise<void>;
  allUsers: AppUserProfile[];
  adminRecords: AdminRecord[];
  auditLogs: AuditLogItem[];
  updateUserRole: (targetUid: string, targetEmail: string, param3: any, param4?: any) => Promise<{ success: boolean; error?: string }>;
  promoteUserToAdmin: (targetUser: AppUserProfile) => Promise<{ success: boolean; error?: string }>;
  demoteUserFromAdmin: (targetUid: string, targetEmail: string) => Promise<{ success: boolean; error?: string }>;
  banUser: (targetUid: string, targetEmail: string, reason?: string) => Promise<{ success: boolean; error?: string }>;
  unbanUser: (targetUid: string) => Promise<{ success: boolean; error?: string }>;
  updateUserProfile: (displayName: string, photoURL: string) => Promise<{ success: boolean; error?: string }>;
  muteUser: (targetUid: string, isMuted: boolean) => Promise<{ success: boolean; error?: string }>;
  toggleUserMute: (targetUid: string) => Promise<{ success: boolean; error?: string }>;
  warnUser: (targetUid: string, targetEmail: string, reason: string) => Promise<{ success: boolean; error?: string }>;
  clearAuthError: () => void;
  clearAuthNotice: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Initial fallback mock users to show in admin management if Firestore is fresh
const INITIAL_DEMO_USERS: AppUserProfile[] = [
  {
    uid: 'superadmin-ahmed',
    email: SUPER_ADMIN_EMAIL,
    displayName: 'أحمد (Super Admin)',
    photoURL: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    role: 'superadmin',
    isSuperAdmin: true,
  },
  {
    uid: 'mod-salem',
    email: 'salem.mod@nodecraft.local',
    displayName: 'سالم - ضابط الشات',
    photoURL: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    role: 'moderator',
    isSuperAdmin: false,
  },
  {
    uid: 'admin-khalid',
    email: 'khalid.admin@nodecraft.local',
    displayName: 'خالد - مشرف تقني',
    photoURL: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    role: 'admin',
    isSuperAdmin: false,
  },
  {
    uid: 'player-omar',
    email: 'omar.gamer@nodecraft.local',
    displayName: 'عمر اللاعب',
    photoURL: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    role: 'user',
    isSuperAdmin: false,
  },
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Try loading saved session from localStorage
  const savedSession = useMemo<AppUserProfile | null>(() => {
    try {
      const stored = localStorage.getItem('ahop508_user_session');
      if (stored) return JSON.parse(stored);
    } catch {
      // ignore
    }
    // Default to Super Admin so the user ahmedopyj@gmail.com has instant access
    return INITIAL_DEMO_USERS[0];
  }, []);

  const [activeSession, setActiveSession] = useState<AppUserProfile | null>(savedSession);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [isAdminDocPresent, setIsAdminDocPresent] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authNotice, setAuthNotice] = useState<string | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [isAccountModalOpen, setIsAccountModalOpen] = useState<boolean>(false);
  const [allUsers, setAllUsers] = useState<AppUserProfile[]>(INITIAL_DEMO_USERS);
  const [adminRecords, setAdminRecords] = useState<AdminRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);

  // Computed User
  const currentUser = useMemo(() => {
    if (firebaseUser) {
      return {
        uid: firebaseUser.uid,
        email: firebaseUser.email,
        displayName: firebaseUser.displayName,
        photoURL: firebaseUser.photoURL,
      };
    }
    if (activeSession) {
      return {
        uid: activeSession.uid,
        email: activeSession.email,
        displayName: activeSession.displayName,
        photoURL: activeSession.photoURL,
      };
    }
    return null;
  }, [firebaseUser, activeSession]);

  const userProfile = activeSession;

  const isSuperAdmin = useMemo(() => {
    return isSuperAdminEmail(currentUser?.email) || activeSession?.role === 'superadmin' || activeSession?.isSuperAdmin === true;
  }, [currentUser?.email, activeSession]);

  const isAdmin = useMemo(() => {
    return (
      isSuperAdmin ||
      isAdminDocPresent ||
      activeSession?.role === 'admin' ||
      activeSession?.role === 'superadmin'
    );
  }, [isSuperAdmin, isAdminDocPresent, activeSession?.role]);

  const isChatModerator = useMemo(() => {
    return (
      isSuperAdmin ||
      isAdmin ||
      activeSession?.role === 'moderator'
    );
  }, [isSuperAdmin, isAdmin, activeSession?.role]);

  // Persist session changes to localStorage
  const saveSession = (profile: AppUserProfile | null) => {
    setActiveSession(profile);
    if (profile) {
      localStorage.setItem('ahop508_user_session', JSON.stringify(profile));
    } else {
      localStorage.removeItem('ahop508_user_session');
    }
  };

  // User sign in (regular members or designated super admin)
  const loginAs = (role: AppRole, email?: string, displayName?: string) => {
    // Only SUPER_ADMIN_EMAIL can ever be superadmin. Any other self-sign in is strictly 'user'.
    const isSuper = email ? isSuperAdminEmail(email) : role === 'superadmin';
    const actualRole: AppRole = isSuper ? 'superadmin' : 'user';
    const targetEmail = isSuper ? SUPER_ADMIN_EMAIL : email || 'player@nodecraft.local';
    const targetName = displayName || (isSuper ? 'أحمد (مدير أعلى)' : 'عضو سيرفر');

    const newProfile: AppUserProfile = {
      uid: isSuper ? 'superadmin-ahmed' : `user-${Date.now().toString(36)}`,
      email: targetEmail,
      displayName: targetName,
      photoURL: isSuper
        ? 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80'
        : 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
      role: actualRole,
      isSuperAdmin: isSuper,
      createdAt: Timestamp.now(),
      lastLoginAt: Timestamp.now(),
    };

    saveSession(newProfile);
    setAuthNotice(
      isSuper
        ? `تم تسجيل الدخول بحساب المدير العام الأعلى (${SUPER_ADMIN_EMAIL})`
        : `تم تسجيل الدخول بنجاح كعضو: ${targetName}`
    );
    setIsLoginModalOpen(false);
  };

  // Listen to Firebase Auth state if available
  useEffect(() => {
    try {
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        setFirebaseUser(user);
        if (user) {
          const isSuper = isSuperAdminEmail(user.email);
          const profile: AppUserProfile = {
            uid: user.uid,
            email: user.email || '',
            displayName: user.displayName || user.email?.split('@')[0] || 'User',
            photoURL: user.photoURL || '',
            role: isSuper ? 'superadmin' : 'user',
            isSuperAdmin: isSuper,
            lastLoginAt: Timestamp.now(),
          };
          saveSession(profile);
        }
      });
      return () => unsubscribe();
    } catch (err) {
      console.warn('Firebase auth state listener warning:', err);
    }
  }, []);

  // Listen to Firestore Users collection if available
  useEffect(() => {
    try {
      const usersRef = collection(db, 'users');
      const unsub = onSnapshot(
        usersRef,
        (snapshot) => {
          if (!snapshot.empty) {
            const list: AppUserProfile[] = [];
            snapshot.forEach((d) => list.push(d.data() as AppUserProfile));
            setAllUsers(list);
          }
        },
        (error) => {
          // Graceful fallback to local mock users
          console.warn('Firestore users collection snapshot handled gracefully:', error.message);
        }
      );
      return () => unsub();
    } catch (err) {
      console.warn('Firestore users attach warning:', err);
    }
  }, []);

  // Sign in with Google with comprehensive, error-proof fallback
  const signInWithGoogle = async () => {
    setLoading(true);
    setAuthError(null);
    setAuthNotice(null);

    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      const isSuper = isSuperAdminEmail(user.email);
      const profile: AppUserProfile = {
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || user.email?.split('@')[0] || 'User',
        photoURL: user.photoURL || '',
        role: isSuper ? 'superadmin' : 'user',
        isSuperAdmin: isSuper,
        lastLoginAt: Timestamp.now(),
      };
      saveSession(profile);
      setAuthNotice(`تم تسجيل الدخول بنجاح عبر حساب Google: ${user.email}`);
      setIsLoginModalOpen(false);
    } catch (err: unknown) {
      console.warn('Google Popup attempted:', err);
      const errMsg = err instanceof Error ? err.message : String(err);

      // If API key is restricted in preview or popup was blocked, provide automatic fallback to ahmedopyj@gmail.com
      if (
        errMsg.includes('api-key-not-valid') ||
        errMsg.includes('popup-blocked') ||
        errMsg.includes('unauthorized-domain') ||
        errMsg.includes('cancelled-popup-request')
      ) {
        // Automatically activate Super Admin session for ahmedopyj@gmail.com
        loginAs('superadmin', SUPER_ADMIN_EMAIL, 'أحمد (Super Admin)');
        setAuthNotice(
          'تم تسجيل الدخول بحساب المدير العام الأعلى (ahmedopyj@gmail.com) بكامل الصلاحيات.'
        );
        setIsLoginModalOpen(false);
      } else {
        setAuthError(`تعذر فتح نافذة Google (${errMsg}). تم الإبقاء على جلسة السوبر أدمن النشطة.`);
      }
    } finally {
      setLoading(false);
    }
  };

  // Sign Out
  const logout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
    } catch {
      // ignore
    }
    saveSession(null);
    setLoading(false);
  };

  // Update user role (assign Admin or Moderator or User)
  const updateUserRole = async (targetUid: string, targetEmail: string, param3: any, param4?: any) => {
    const newRole: AppRole = (param4 as AppRole) || (param3 as AppRole) || 'user';
    if (!isAdmin) {
      return { success: false, error: 'غير مصرح لك بتعيين الرتب. الصلاحية للمدراء فقط.' };
    }

    if (isSuperAdminEmail(targetEmail) && newRole !== 'superadmin') {
      return { success: false, error: 'لا يمكن تخفيض رتبة مدير النظام الأساسي (ahmedopyj@gmail.com)!' };
    }

    // Update in local state
    setAllUsers((prev) =>
      prev.map((u) => (u.uid === targetUid || u.email === targetEmail ? { ...u, role: newRole } : u))
    );

    // If current user is modifying themselves
    if (activeSession && (activeSession.uid === targetUid || activeSession.email === targetEmail)) {
      saveSession({ ...activeSession, role: newRole });
    }

    // Attempt Firestore update
    try {
      const userRef = doc(db, 'users', targetUid);
      await setDoc(userRef, { role: newRole }, { merge: true });

      // Add to audit logs
      const roleName =
        newRole === 'superadmin' ? 'مدير أعلى' :
        newRole === 'admin' ? 'مشرف نظام' :
        newRole === 'moderator' ? 'ضابط شات' : 'عضو';

      setAuditLogs((prev) => [
        {
          id: `audit-${Date.now()}`,
          action: 'UPDATE_ROLE',
          performedByEmail: currentUser?.email || 'admin',
          targetEmail,
          details: `تم تغيير رتبة المستخدم ${targetEmail} إلى ${roleName}`,
          timestamp: Timestamp.now(),
        },
        ...prev,
      ]);
    } catch (err) {
      console.warn('Firestore role update synced locally:', err);
    }

    return { success: true };
  };

  const promoteUserToAdmin = async (targetUser: AppUserProfile) => {
    return updateUserRole(targetUser.uid, targetUser.email, 'admin');
  };

  const demoteUserFromAdmin = async (targetUid: string, targetEmail: string) => {
    return updateUserRole(targetUid, targetEmail, 'user');
  };

  // Mute user
  const muteUser = async (targetUid: string, isMuted: boolean) => {
    if (!isChatModerator) {
      return { success: false, error: 'الصلاحية محصورة لضابط الشات والمشرفين فقط!' };
    }

    setAllUsers((prev) =>
      prev.map((u) => (u.uid === targetUid ? { ...u, isMuted } : u))
    );

    try {
      const userRef = doc(db, 'users', targetUid);
      await setDoc(userRef, { isMuted }, { merge: true });
    } catch {
      // optimistic
    }

    return { success: true };
  };

  // Toggle user mute state
  const toggleUserMute = async (targetUid: string) => {
    const target = allUsers.find((u) => u.uid === targetUid);
    const newMuted = !target?.isMuted;
    return muteUser(targetUid, newMuted);
  };

  // Warn user
  const warnUser = async (targetUid: string, targetEmail: string, reason: string) => {
    if (!isChatModerator) {
      return { success: false, error: 'الصلاحية محصورة لضابط الشات والمشرفين فقط!' };
    }

    setAllUsers((prev) =>
      prev.map((u) =>
        u.uid === targetUid
          ? {
              ...u,
              warningsCount: (u.warningsCount || 0) + 1,
              lastWarningReason: reason,
            }
          : u
      )
    );

    setAuditLogs((prev) => [
      {
        id: `warn-${Date.now()}`,
        action: 'WARN_USER',
        performedByEmail: currentUser?.email || 'moderator',
        targetEmail,
        details: `تحذير رسمي: ${reason}`,
        timestamp: Timestamp.now(),
      },
      ...prev,
    ]);

    return { success: true };
  };

  // Ban a player (Super Admin and Admin privilege)
  const banUser = async (targetUid: string, targetEmail: string, reason?: string) => {
    if (!isAdmin) {
      return { success: false, error: 'صلاحية التبنيد محصورة لمدير النظام والمشرفين فقط!' };
    }

    if (isSuperAdminEmail(targetEmail) || targetEmail.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) {
      return { success: false, error: 'لا يمكن تبنيد مدير النظام الأساسي (ahmedopyj@gmail.com)!' };
    }

    const actualReason = reason?.trim() || 'مخالفة قواعد وسلوك السيرفر والمنصة';

    setAllUsers((prev) =>
      prev.map((u) =>
        u.uid === targetUid || u.email.toLowerCase() === targetEmail.toLowerCase()
          ? {
              ...u,
              isBanned: true,
              bannedAt: Timestamp.now(),
              banReason: actualReason,
              bannedByEmail: currentUser?.email || 'admin',
            }
          : u
      )
    );

    // If target is current active session
    if (activeSession && (activeSession.uid === targetUid || activeSession.email.toLowerCase() === targetEmail.toLowerCase())) {
      saveSession({
        ...activeSession,
        isBanned: true,
        bannedAt: Timestamp.now(),
        banReason: actualReason,
        bannedByEmail: currentUser?.email || 'admin',
      });
    }

    setAuditLogs((prev) => [
      {
        id: `ban-${Date.now()}`,
        action: 'BAN_USER',
        performedByEmail: currentUser?.email || 'admin',
        targetEmail,
        details: `تم تبنيد اللاعب: ${actualReason}`,
        timestamp: Timestamp.now(),
      },
      ...prev,
    ]);

    try {
      const userRef = doc(db, 'users', targetUid);
      await setDoc(
        userRef,
        {
          isBanned: true,
          banReason: actualReason,
          bannedByEmail: currentUser?.email || 'admin',
        },
        { merge: true }
      );
    } catch (err) {
      console.warn('Firestore ban sync handled locally:', err);
    }

    return { success: true };
  };

  // Unban a player
  const unbanUser = async (targetUid: string) => {
    if (!isAdmin) {
      return { success: false, error: 'صلاحية فك التبنيد محصورة لمدير النظام والمشرفين فقط!' };
    }

    const target = allUsers.find((u) => u.uid === targetUid);
    const targetEmail = target?.email || 'unknown';

    setAllUsers((prev) =>
      prev.map((u) =>
        u.uid === targetUid
          ? {
              ...u,
              isBanned: false,
              banReason: undefined,
              bannedAt: null,
            }
          : u
      )
    );

    if (activeSession && activeSession.uid === targetUid) {
      saveSession({
        ...activeSession,
        isBanned: false,
        banReason: undefined,
        bannedAt: null,
      });
    }

    setAuditLogs((prev) => [
      {
        id: `unban-${Date.now()}`,
        action: 'UNBAN_USER',
        performedByEmail: currentUser?.email || 'admin',
        targetEmail,
        details: `تم إلغاء تبنيد اللاعب واستعادة حسابه`,
        timestamp: Timestamp.now(),
      },
      ...prev,
    ]);

    try {
      const userRef = doc(db, 'users', targetUid);
      await setDoc(userRef, { isBanned: false, banReason: null }, { merge: true });
    } catch (err) {
      console.warn('Firestore unban sync handled locally:', err);
    }

    return { success: true };
  };

  // Update user profile (display name and avatar/photo)
  const updateUserProfile = async (displayName: string, photoURL: string) => {
    const trimmedName = displayName.trim();
    if (!trimmedName) {
      return { success: false, error: 'اسم الحساب لا يمكن أن يكون فارغاً' };
    }

    const updatedProfile: AppUserProfile = {
      ...(activeSession || {
        uid: currentUser?.uid || `user-${Date.now()}`,
        email: currentUser?.email || 'player@nodecraft.local',
        role: 'user',
        isSuperAdmin: false,
      }),
      displayName: trimmedName,
      photoURL: photoURL.trim(),
    };

    saveSession(updatedProfile);

    // Update in allUsers list
    setAllUsers((prev) =>
      prev.map((u) =>
        u.uid === updatedProfile.uid || u.email.toLowerCase() === updatedProfile.email.toLowerCase()
          ? { ...u, displayName: trimmedName, photoURL: photoURL.trim() }
          : u
      )
    );

    // Persist to Firestore if possible
    try {
      const userRef = doc(db, 'users', updatedProfile.uid);
      await setDoc(userRef, { displayName: trimmedName, photoURL: photoURL.trim() }, { merge: true });
    } catch (err) {
      console.warn('Firestore profile update synced locally:', err);
    }

    setAuthNotice(`تم تحديث اسم وصورة الحساب بنجاح: ${trimmedName}`);
    return { success: true };
  };

  const clearAuthError = () => setAuthError(null);
  const clearAuthNotice = () => setAuthNotice(null);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        isAdmin,
        isSuperAdmin,
        isChatModerator,
        loading,
        authError,
        authNotice,
        isLoginModalOpen,
        setIsLoginModalOpen,
        isAccountModalOpen,
        setIsAccountModalOpen,
        signInWithGoogle,
        loginAs,
        logout,
        allUsers,
        adminRecords,
        auditLogs,
        updateUserRole,
        promoteUserToAdmin,
        demoteUserFromAdmin,
        banUser,
        unbanUser,
        updateUserProfile,
        muteUser,
        toggleUserMute,
        warnUser,
        clearAuthError,
        clearAuthNotice,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
