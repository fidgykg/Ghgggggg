import JSZip from 'jszip';
import { VirtualFile, ServerPlugin, FabricMod } from '../types/server';

export interface ZipFileInfo {
  path: string;
  name: string;
  sizeBytes: number;
  isDirectory: boolean;
}

export interface ExtractedZipResult {
  extractedFiles: VirtualFile[];
  detectedPlugins: ServerPlugin[];
  detectedMods: FabricMod[];
  serverProperties?: Record<string, string>;
  summary: {
    totalFiles: number;
    totalSizeBytes: number;
    pluginsCount: number;
    modsCount: number;
    hasWorld: boolean;
  };
  logs: string[];
}

/**
 * Inspect contents of a ZIP file without modifying server state
 */
export async function inspectZipArchive(
  zipSource: File | Blob | string
): Promise<ZipFileInfo[]> {
  const zip = new JSZip();
  let zipData: any = zipSource;

  if (typeof zipSource === 'string' && zipSource.startsWith('data:')) {
    // Convert base64 data url to ArrayBuffer
    const base64 = zipSource.split(',')[1];
    zipData = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0)).buffer;
  }

  const loaded = await zip.loadAsync(zipData);
  const filesList: ZipFileInfo[] = [];

  loaded.forEach((relativePath, entry) => {
    // Ignore OS hidden files like __MACOSX and .DS_Store
    if (relativePath.includes('__MACOSX') || relativePath.includes('.DS_Store')) {
      return;
    }
    const cleanPath = relativePath.startsWith('/') ? relativePath : `/${relativePath}`;
    filesList.push({
      path: cleanPath,
      name: entry.name.split('/').filter(Boolean).pop() || entry.name,
      sizeBytes: (entry as any)._data?.uncompressedSize || 0,
      isDirectory: entry.dir,
    });
  });

  return filesList;
}

/**
 * Extracts all files from a ZIP archive, parses them into VirtualFiles,
 * and identifies plugins, mods, and world data.
 */
export async function extractZipArchive(
  zipSource: File | Blob | string,
  targetFolder: string = ''
): Promise<ExtractedZipResult> {
  const zip = new JSZip();
  let zipData: any = zipSource;

  if (typeof zipSource === 'string' && zipSource.startsWith('data:')) {
    const base64 = zipSource.split(',')[1];
    zipData = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0)).buffer;
  }

  const loaded = await zip.loadAsync(zipData);
  const extractedFiles: VirtualFile[] = [];
  const detectedPlugins: ServerPlugin[] = [];
  const detectedMods: FabricMod[] = [];
  let serverProperties: Record<string, string> | undefined;
  const logs: string[] = [];
  let totalSizeBytes = 0;
  let hasWorld = false;

  const now = new Date().toISOString().replace('T', ' ').slice(0, 16);

  // Normalize targetFolder (e.g. '/world' or '' for root)
  const prefix = targetFolder && targetFolder !== 'ALL'
    ? (targetFolder.startsWith('/') ? targetFolder : `/${targetFolder}`).replace(/\/$/, '')
    : '';

  for (const [relativePath, entry] of Object.entries(loaded.files)) {
    // Skip OS junk files
    if (entry.dir || relativePath.includes('__MACOSX') || relativePath.includes('.DS_Store')) {
      continue;
    }

    // Determine target clean path
    let cleanRelPath = relativePath.startsWith('/') ? relativePath : `/${relativePath}`;
    let finalPath = prefix ? `${prefix}${cleanRelPath}` : cleanRelPath;
    finalPath = finalPath.replace(/\/+/g, '/');

    const fileName = entry.name.split('/').filter(Boolean).pop() || entry.name;
    const isText = Boolean(fileName.match(/\.(txt|properties|yml|yaml|json|log|conf|js|html|css|mcfunction|mcmeta|toml|md)$/i));

    let content = '';
    let sizeBytes = 0;

    if (isText) {
      content = await entry.async('string');
      sizeBytes = new Blob([content]).size;
    } else {
      // Binary file (e.g., .jar, .mca, .dat, .png)
      const base64Content = await entry.async('base64');
      content = `data:application/octet-stream;base64,${base64Content}`;
      sizeBytes = (entry as any)._data?.uncompressedSize || Math.round(base64Content.length * 0.75);
    }

    totalSizeBytes += sizeBytes;

    extractedFiles.push({
      path: finalPath,
      name: fileName,
      isDirectory: false,
      sizeBytes: sizeBytes,
      lastModified: now,
      content: content,
    });

    // Check for Minecraft World files
    if (finalPath.includes('/world/') || fileName === 'level.dat') {
      hasWorld = true;
    }

    // Check for server.properties
    if (fileName === 'server.properties') {
      const props: Record<string, string> = {};
      content.split('\n').forEach((line) => {
        const trimmed = line.trim();
        if (trimmed && !trimmed.startsWith('#') && trimmed.includes('=')) {
          const [key, ...vals] = trimmed.split('=');
          props[key.trim()] = vals.join('=').trim();
        }
      });
      serverProperties = props;
    }

    // Check for Plugins (.jar inside plugins/ or named as common plugin)
    if (fileName.endsWith('.jar') && (finalPath.includes('/plugins/') || !finalPath.includes('/mods/'))) {
      const baseName = fileName.replace('.jar', '').replace(/[-_v0-9.].*$/, '') || fileName.replace('.jar', '');
      detectedPlugins.push({
        id: `pl-zip-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        name: baseName,
        fileName: fileName,
        version: 'From Zip',
        author: 'Extracted Archive',
        description: `إضافة تم فك ضغطها وتثبيتها من سيت اب الأرشيف المضغوط (${fileName}).`,
        category: 'utility',
        enabled: true,
        fileSizeMB: Math.max(0.1, Number((sizeBytes / (1024 * 1024)).toFixed(1))),
      });
    }

    // Check for Mods (.jar inside mods/)
    if (fileName.endsWith('.jar') && finalPath.includes('/mods/')) {
      const baseName = fileName.replace('.jar', '').replace(/[-_v0-9.].*$/, '') || fileName.replace('.jar', '');
      detectedMods.push({
        id: `mod-zip-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        name: baseName,
        fileName: fileName,
        version: 'From Zip',
        author: 'Extracted Archive',
        description: `مود فابريك تم فك ضغطه من سيت اب الأرشيف (${fileName}).`,
        side: 'both',
        enabled: true,
        fileSizeMB: Math.max(0.1, Number((sizeBytes / (1024 * 1024)).toFixed(1))),
      });
    }
  }

  logs.push(
    `[ZIP Unpacker] Successfully unpacked ${extractedFiles.length} files (${(totalSizeBytes / 1024).toFixed(1)} KB) into "${prefix || '/'}"`
  );

  return {
    extractedFiles,
    detectedPlugins,
    detectedMods,
    serverProperties,
    summary: {
      totalFiles: extractedFiles.length,
      totalSizeBytes,
      pluginsCount: detectedPlugins.length,
      modsCount: detectedMods.length,
      hasWorld,
    },
    logs,
  };
}
