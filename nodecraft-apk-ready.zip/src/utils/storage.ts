import { LocalServer, LocalNetworkInfo } from '../types/server';
import { INITIAL_SERVERS } from '../data/initialServers';
import { ensureFullServerFiles } from './fileHelpers';

const STORAGE_KEY = 'nodecraft_servers_v1';
const NETWORK_STORAGE_KEY = 'nodecraft_network_v1';

export function loadSavedServers(): LocalServer[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return INITIAL_SERVERS.map((s) => ({
        ...s,
        files: ensureFullServerFiles(s),
      }));
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      // Backfill missing fields from INITIAL_SERVERS if any
      const merged: LocalServer[] = parsed.map((s: LocalServer): LocalServer => {
        const init = INITIAL_SERVERS.find((x) => x.id === s.id);
        const serverCandidate: LocalServer = {
          ...s,
          plugins: s.plugins ?? init?.plugins ?? [],
          mods: s.mods ?? init?.mods ?? [],
          files: s.files ?? init?.files ?? [],
          playitConfig: s.playitConfig ?? init?.playitConfig ?? {
            enabled: s.id === 'mc-paper-01',
            publicDomain: 'ahop508-survival.auto.playit.gg',
            publicPort: 38421,
            tunnelType: 'minecraft-java',
            status: s.id === 'mc-paper-01' ? 'connected' : 'disconnected',
            agentVersion: '0.15.26',
            assignedAddress: 'ahop508-survival.auto.playit.gg:38421',
          },
        };

        // Guarantee all world files, plugin files, and configs exist
        serverCandidate.files = ensureFullServerFiles(serverCandidate);
        return serverCandidate;
      });

      // Ensure Fabric server is present if missing
      const hasFabric = merged.some((s) => s.minecraftConfig?.serverSoftware === 'Fabric' || s.id === 'mc-fabric-04');
      if (!hasFabric) {
        const fabricInit = INITIAL_SERVERS.find((s) => s.id === 'mc-fabric-04');
        if (fabricInit) {
          merged.push({
            ...fabricInit,
            files: ensureFullServerFiles(fabricInit),
          });
        }
      }

      return merged;
    }
  } catch (e) {
    console.error('Failed to load servers from localStorage', e);
  }
  return INITIAL_SERVERS.map((s) => ({
    ...s,
    files: ensureFullServerFiles(s),
  }));
}

export function saveServers(servers: LocalServer[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(servers));
  } catch (e) {
    console.error('Failed to save servers to localStorage', e);
  }
}

export function loadNetworkInfo(): LocalNetworkInfo {
  try {
    const raw = localStorage.getItem(NETWORK_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load network info', e);
  }
  return {
    localIp: '192.168.1.105',
    subnetMask: '255.255.255.0',
    gateway: '192.168.1.1',
    hostname: 'DESKTOP-HOME-SERVER',
    macAddress: 'E4:5F:01:9A:33:C2',
  };
}

export function saveNetworkInfo(info: LocalNetworkInfo): void {
  try {
    localStorage.setItem(NETWORK_STORAGE_KEY, JSON.stringify(info));
  } catch (e) {
    console.error('Failed to save network info', e);
  }
}

/**
 * Format uptime seconds to human readable
 */
export function formatUptime(seconds: number, lang: 'ar' | 'en' = 'ar'): string {
  if (seconds <= 0) return lang === 'ar' ? 'متوقف' : 'Offline';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  if (lang === 'ar') {
    if (hrs > 0) return `${hrs}س ${mins}د`;
    if (mins > 0) return `${mins}د ${secs}ث`;
    return `${secs}ث`;
  } else {
    if (hrs > 0) return `${hrs}h ${mins}m`;
    if (mins > 0) return `${mins}m ${secs}s`;
    return `${secs}s`;
  }
}

/**
 * Minecraft Command Dispatcher (Simulated JVM console execution)
 */
export function executeMinecraftCommand(
  server: LocalServer,
  rawCmd: string
): { response: string; level: 'INFO' | 'WARN' | 'ERROR'; updatedServer?: LocalServer } {
  const cmd = rawCmd.trim().startsWith('/') ? rawCmd.trim().slice(1) : rawCmd.trim();
  const [action, ...args] = cmd.split(' ');
  const normalizedAction = action.toLowerCase();

  const now = new Date().toLocaleTimeString('en-GB');

  if (server.status !== 'online') {
    return {
      response: `Cannot execute command: server is currently ${server.status}.`,
      level: 'ERROR',
    };
  }

  // Deep clone to safely mutate
  const updated = JSON.parse(JSON.stringify(server)) as LocalServer;

  switch (normalizedAction) {
    case 'help':
      return {
        response: `--- Available Commands ---
/help - Show this manual
/tps - Show current ticks per second and memory
/say <message> - Broadcast message to all players
/op <player> - Grant server operator permissions
/deop <player> - Revoke operator permissions
/kick <player> [reason] - Disconnect player from server
/ban <player> - Ban player from server
/gamemode <survival|creative|spectator> [player] - Switch gamemode
/time set <day|night|noon> - Change world time
/weather <clear|rain|thunder> - Set world weather
/seed - Show world generation seed
/whitelist <on|off|add|list> - Manage player access
/stop - Gracefully save world and shutdown server`,
        level: 'INFO',
      };

    case 'tps':
      return {
        response: `TPS from last 1m, 5m, 15m: 20.0, 19.98, 20.0 (Memory: ${server.metrics.memoryUsageMB}MB / ${server.metrics.memoryAllocatedMB}MB)`,
        level: 'INFO',
      };

    case 'say': {
      const msg = args.join(' ');
      if (!msg) return { response: 'Usage: /say <message>', level: 'WARN' };
      return {
        response: `[Server] ${msg}`,
        level: 'INFO',
      };
    }

    case 'seed':
      return {
        response: `Seed: [${server.minecraftConfig?.seed || '84920491823901'}]`,
        level: 'INFO',
      };

    case 'time': {
      const timeVal = args[1] || args[0] || 'day';
      return {
        response: `Set the time to ${timeVal} (world ticks updated).`,
        level: 'INFO',
      };
    }

    case 'weather': {
      const type = args[0] || 'clear';
      return {
        response: `Set the weather to ${type}.`,
        level: 'INFO',
      };
    }

    case 'op': {
      const targetName = args[0];
      if (!targetName) return { response: 'Usage: /op <player>', level: 'WARN' };
      if (updated.players) {
        const p = updated.players.find((x) => x.name.toLowerCase() === targetName.toLowerCase());
        if (p) p.isOp = true;
      }
      return {
        response: `Made ${targetName} a server operator`,
        level: 'INFO',
        updatedServer: updated,
      };
    }

    case 'deop': {
      const targetName = args[0];
      if (!targetName) return { response: 'Usage: /deop <player>', level: 'WARN' };
      if (updated.players) {
        const p = updated.players.find((x) => x.name.toLowerCase() === targetName.toLowerCase());
        if (p) p.isOp = false;
      }
      return {
        response: `Revoked operator privileges for ${targetName}`,
        level: 'INFO',
        updatedServer: updated,
      };
    }

    case 'kick': {
      const targetName = args[0];
      if (!targetName) return { response: 'Usage: /kick <player> [reason]', level: 'WARN' };
      const reason = args.slice(1).join(' ') || 'Kicked by administrator';
      if (updated.players) {
        updated.players = updated.players.filter(
          (x) => x.name.toLowerCase() !== targetName.toLowerCase()
        );
      }
      return {
        response: `Kicked ${targetName}: ${reason}`,
        level: 'INFO',
        updatedServer: updated,
      };
    }

    case 'ban': {
      const targetName = args[0];
      if (!targetName) return { response: 'Usage: /ban <player> [reason]', level: 'WARN' };
      if (updated.players) {
        const p = updated.players.find((x) => x.name.toLowerCase() === targetName.toLowerCase());
        if (p) p.isBanned = true;
        updated.players = updated.players.filter(
          (x) => x.name.toLowerCase() !== targetName.toLowerCase()
        );
      }
      return {
        response: `Banned ${targetName} from the server and IP recorded.`,
        level: 'WARN',
        updatedServer: updated,
      };
    }

    case 'gamemode': {
      const mode = (args[0] || '').toLowerCase();
      const targetName = args[1];
      if (!['survival', 'creative', 'adventure', 'spectator'].includes(mode)) {
        return { response: 'Usage: /gamemode <survival|creative|adventure|spectator> [player]', level: 'WARN' };
      }
      if (targetName && updated.players) {
        const p = updated.players.find((x) => x.name.toLowerCase() === targetName.toLowerCase());
        if (p) p.gamemode = mode as any;
        return {
          response: `Set ${targetName}'s game mode to ${mode.toUpperCase()} Mode`,
          level: 'INFO',
          updatedServer: updated,
        };
      }
      return {
        response: `Default game mode updated to ${mode.toUpperCase()} Mode`,
        level: 'INFO',
      };
    }

    case 'stop': {
      updated.status = 'offline';
      updated.players = [];
      updated.metrics.cpuUsage = 0;
      updated.metrics.memoryUsageMB = 0;
      return {
        response: `[${now}] [Server thread/INFO]: Stopping the server... Saving players and world data. Closing listening port ${server.port}. Server stopped.`,
        level: 'INFO',
        updatedServer: updated,
      };
    }

    default:
      return {
        response: `Unknown command: /${cmd}. Type "/help" for available commands.`,
        level: 'WARN',
      };
  }
}

/**
 * Redis Command Dispatcher
 */
export function executeRedisCommand(
  server: LocalServer,
  rawCmd: string
): { response: string; level: 'INFO' | 'WARN' | 'ERROR'; updatedServer?: LocalServer } {
  const parts = rawCmd.trim().split(' ').filter(Boolean);
  if (parts.length === 0) return { response: '(nil)', level: 'INFO' };

  const verb = parts[0].toUpperCase();
  const updated = JSON.parse(JSON.stringify(server)) as LocalServer;
  if (!updated.dbConfig) {
    updated.dbConfig = { dbType: 'redis', keys: [] };
  }

  switch (verb) {
    case 'PING':
      return { response: 'PONG', level: 'INFO' };

    case 'SET': {
      if (parts.length < 3) return { response: 'ERR wrong number of arguments for "set" command', level: 'ERROR' };
      const key = parts[1];
      const val = parts.slice(2).join(' ');
      const existing = updated.dbConfig.keys.find((k) => k.key === key);
      if (existing) {
        existing.value = val;
      } else {
        updated.dbConfig.keys.push({ key, value: val, type: 'string', ttl: -1 });
      }
      return { response: 'OK', level: 'INFO', updatedServer: updated };
    }

    case 'GET': {
      if (parts.length < 2) return { response: 'ERR wrong number of arguments for "get" command', level: 'ERROR' };
      const key = parts[1];
      const item = updated.dbConfig.keys.find((k) => k.key === key);
      if (!item) return { response: '(nil)', level: 'INFO' };
      return { response: `"${item.value}"`, level: 'INFO' };
    }

    case 'DEL': {
      if (parts.length < 2) return { response: 'ERR wrong number of arguments for "del" command', level: 'ERROR' };
      const key = parts[1];
      const initialLen = updated.dbConfig.keys.length;
      updated.dbConfig.keys = updated.dbConfig.keys.filter((k) => k.key !== key);
      const count = initialLen - updated.dbConfig.keys.length;
      return { response: `(integer) ${count}`, level: 'INFO', updatedServer: updated };
    }

    case 'KEYS': {
      const keys = updated.dbConfig.keys.map((k, i) => `${i + 1}) "${k.key}"`).join('\n');
      return { response: keys || '(empty list or set)', level: 'INFO' };
    }

    case 'DBSIZE':
      return { response: `(integer) ${updated.dbConfig.keys.length}`, level: 'INFO' };

    case 'FLUSHALL':
      updated.dbConfig.keys = [];
      return { response: 'OK', level: 'INFO', updatedServer: updated };

    default:
      return { response: `ERR unknown command '${parts[0]}'`, level: 'ERROR' };
  }
}
