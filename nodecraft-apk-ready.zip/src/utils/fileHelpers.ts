import { LocalServer, VirtualFile, ServerPlugin, FabricMod } from '../types/server';

/**
 * Returns a complete virtual file tree for a server, ensuring all plugins, mods,
 * world files, configs, and user files are present and browsable.
 */
export function ensureFullServerFiles(server: LocalServer): VirtualFile[] {
  const existingFiles = server.files || [];
  const existingPaths = new Set(existingFiles.map((f) => f.path));
  const newFiles: VirtualFile[] = [...existingFiles];

  const now = new Date().toISOString().replace('T', ' ').slice(0, 16);

  // 1. If Minecraft server, ensure world files exist
  if (server.type === 'minecraft') {
    const seed = server.minecraftConfig?.seed || '84920491823901';
    const worldFiles: VirtualFile[] = [
      {
        path: '/world/level.dat',
        name: 'level.dat',
        isDirectory: false,
        sizeBytes: 2840,
        lastModified: now,
        content: `# Minecraft NBT Level Data
LevelName: world
RandomSeed: ${seed}
generatorName: default
GameType: ${server.minecraftConfig?.gamemode || 'survival'}
Difficulty: ${server.minecraftConfig?.difficulty || 'normal'}
SpawnX: 124
SpawnY: 68
SpawnZ: -89
Time: 48204L
DayTime: 12400L
clearWeatherTime: 60000
rainTime: 0
raining: 0
thundering: 0
version: 1.21.1`,
      },
      {
        path: '/world/session.lock',
        name: 'session.lock',
        isDirectory: false,
        sizeBytes: 8,
        lastModified: now,
        content: `1793502049182`,
      },
      {
        path: '/world/region/r.0.0.mca',
        name: 'r.0.0.mca',
        isDirectory: false,
        sizeBytes: 1048576, // 1MB chunk region
        lastModified: now,
        content: `[Anvil Region Chunk File: 1024 Chunks generated at Spawn Coordinates (0,0) to (31,31)]`,
      },
      {
        path: '/world/region/r.0.-1.mca',
        name: 'r.0.-1.mca',
        isDirectory: false,
        sizeBytes: 524288,
        lastModified: now,
        content: `[Anvil Region Chunk File: Forest & River Biome chunks]`,
      },
      {
        path: '/world/data/scoreboard.dat',
        name: 'scoreboard.dat',
        isDirectory: false,
        sizeBytes: 640,
        lastModified: now,
        content: `# Minecraft Scoreboard & Objectives
Objective: Kills [criteria: playerKillCount, displayName: "عدد القتلات"]
Objective: Balance [criteria: dummy, displayName: "الرصيد $"]
Teams: Admin [color: red], Player [color: green]`,
      },
      {
        path: '/world_nether/level.dat',
        name: 'level.dat',
        isDirectory: false,
        sizeBytes: 1420,
        lastModified: now,
        content: `# Nether Dimension NBT Level Data\nDimension: The_Nether\nGenerator: nether\nFortress_Spawn: (140, 52, -210)`,
      },
      {
        path: '/world_the_end/level.dat',
        name: 'level.dat',
        isDirectory: false,
        sizeBytes: 1210,
        lastModified: now,
        content: `# The End Dimension NBT Level Data\nDimension: The_End\nDragonKilled: 0\nGatewaysActive: 1`,
      },
      {
        path: '/server.properties',
        name: 'server.properties',
        isDirectory: false,
        sizeBytes: 820,
        lastModified: now,
        content: `server-port=${server.port}
motd=${server.minecraftConfig?.motd || 'سيرفر ماين كرافت محلي'}
pvp=${server.minecraftConfig?.pvp ? 'true' : 'false'}
difficulty=${server.minecraftConfig?.difficulty || 'normal'}
gamemode=${server.minecraftConfig?.gamemode || 'survival'}
online-mode=${server.minecraftConfig?.onlineMode ? 'true' : 'false'}
max-players=${server.minecraftConfig?.maxPlayers || 20}
view-distance=${server.minecraftConfig?.viewDistance || 10}
allow-flight=${server.minecraftConfig?.allowFlight ? 'true' : 'false'}
level-name=world`,
      },
      {
        path: '/eula.txt',
        name: 'eula.txt',
        isDirectory: false,
        sizeBytes: 20,
        lastModified: now,
        content: 'eula=true',
      },
      {
        path: '/whitelist.json',
        name: 'whitelist.json',
        isDirectory: false,
        sizeBytes: 120,
        lastModified: now,
        content: `[\n  {\n    "uuid": "4f2d9c12-3b6a-4d29-a548-81e05a819b10",\n    "name": "AhmedCraft"\n  }\n]`,
      },
      {
        path: '/ops.json',
        name: 'ops.json',
        isDirectory: false,
        sizeBytes: 180,
        lastModified: now,
        content: `[\n  {\n    "uuid": "4f2d9c12-3b6a-4d29-a548-81e05a819b10",\n    "name": "AhmedCraft",\n    "level": 4,\n    "bypassesPlayerLimit": true\n  }\n]`,
      },
      {
        path: '/logs/latest.log',
        name: 'latest.log',
        isDirectory: false,
        sizeBytes: 1400,
        lastModified: now,
        content: server.logs.map((l) => `[${l.timestamp}] [${l.level}]: ${l.message}`).join('\n') || '[Server initialized]',
      },
    ];

    worldFiles.forEach((wf) => {
      if (!existingPaths.has(wf.path)) {
        newFiles.push(wf);
        existingPaths.add(wf.path);
      }
    });

    // 2. Ensure all plugins in server.plugins exist in /plugins/ and have their config
    if (server.plugins) {
      server.plugins.forEach((pl) => {
        const jarPath = `/plugins/${pl.fileName}`;
        if (!existingPaths.has(jarPath)) {
          newFiles.push({
            path: jarPath,
            name: pl.fileName,
            isDirectory: false,
            sizeBytes: Math.floor(pl.fileSizeMB * 1024 * 1024),
            lastModified: now,
            content: `[Binary Plugin JAR: ${pl.name} v${pl.version} by ${pl.author}]`,
          });
          existingPaths.add(jarPath);
        }

        // Plugin config
        const configPath = `/plugins/${pl.name}/config.yml`;
        if (!existingPaths.has(configPath)) {
          newFiles.push({
            path: configPath,
            name: 'config.yml',
            isDirectory: false,
            sizeBytes: 940,
            lastModified: now,
            content: `# Configuration file for ${pl.name} v${pl.version}
enabled: ${pl.enabled}
locale: ar
debug-mode: false
auto-save-interval: 300
notifications: true
author: ${pl.author}`,
          });
          existingPaths.add(configPath);
        }
      });
    }

    // 3. Ensure all mods in server.mods exist in /mods/
    if (server.mods) {
      server.mods.forEach((mod) => {
        const modJarPath = `/mods/${mod.fileName}`;
        if (!existingPaths.has(modJarPath)) {
          newFiles.push({
            path: modJarPath,
            name: mod.fileName,
            isDirectory: false,
            sizeBytes: Math.floor(mod.fileSizeMB * 1024 * 1024),
            lastModified: now,
            content: `[Binary Fabric Mod JAR: ${mod.name} v${mod.version} by ${mod.author}]`,
          });
          existingPaths.add(modJarPath);
        }

        const modConfigPath = `/config/${mod.name.toLowerCase().replace(/\s+/g, '_')}.json`;
        if (!existingPaths.has(modConfigPath)) {
          newFiles.push({
            path: modConfigPath,
            name: `${mod.name.toLowerCase().replace(/\s+/g, '_')}.json`,
            isDirectory: false,
            sizeBytes: 320,
            lastModified: now,
            content: JSON.stringify(
              {
                mod_id: mod.id,
                name: mod.name,
                version: mod.version,
                enabled: mod.enabled,
                side: mod.side,
              },
              null,
              2
            ),
          });
          existingPaths.add(modConfigPath);
        }
      });
    }
  } else if (server.type === 'web') {
    // Web server files
    const webFiles: VirtualFile[] = [
      {
        path: '/public/index.html',
        name: 'index.html',
        isDirectory: false,
        sizeBytes: 1480,
        lastModified: now,
        content: server.webConfig?.htmlContent || '<html><body><h1>Hello World</h1></body></html>',
      },
      {
        path: '/public/style.css',
        name: 'style.css',
        isDirectory: false,
        sizeBytes: 420,
        lastModified: now,
        content: server.webConfig?.cssContent || 'body { background: #0b0f19; color: white; }',
      },
      {
        path: '/server.js',
        name: 'server.js',
        isDirectory: false,
        sizeBytes: 680,
        lastModified: now,
        content: `const express = require('express');\nconst app = express();\nconst PORT = ${server.port};\napp.use(express.static('public'));\napp.listen(PORT, () => console.log('Listening on ' + PORT));`,
      },
      {
        path: '/package.json',
        name: 'package.json',
        isDirectory: false,
        sizeBytes: 240,
        lastModified: now,
        content: `{\n  "name": "${server.name.toLowerCase().replace(/[^a-z0-9]/g, '')}",\n  "version": "1.0.0",\n  "main": "server.js"\n}`,
      },
    ];

    webFiles.forEach((wf) => {
      if (!existingPaths.has(wf.path)) {
        newFiles.push(wf);
        existingPaths.add(wf.path);
      }
    });
  }

  return newFiles;
}

/**
 * Ready-made Server Setups (ستابات وقوالب جاهزة بنقرة واحدة)
 */
export interface ReadySetup {
  id: string;
  name: string;
  nameEn: string;
  category: 'minecraft' | 'fabric' | 'web' | 'pvp';
  badge: string;
  icon: string;
  description: string;
  descriptionEn: string;
  ramMB: number;
  software: string;
  plugins?: Omit<ServerPlugin, 'id'>[];
  mods?: Omit<FabricMod, 'id'>[];
  filesCount: number;
}

export const READY_SETUPS: ReadySetup[] = [
  {
    id: 'setup-smp-complete',
    name: 'سيت اب سيرفر سرفايفل أصدقاء متكامل (SMP Essentials)',
    nameEn: 'Ultimate Survival SMP Pack',
    category: 'minecraft',
    badge: 'الأكثر طلباً ⭐',
    icon: '🏰',
    software: 'PaperMC 1.21.1',
    ramMB: 4096,
    description: 'سيرفر سرفايفل جاهز مع قلعة مبنية، جسر GeyserMC لدخول لاعبي الجوال والكونسول، أوامر السرفايفل EssentialsX، WorldEdit، ونظام رتب وحماية الأراضي.',
    descriptionEn: 'Full survival SMP with pre-built castle world, GeyserMC bedrock crossplay, EssentialsX, WorldEdit, and LuckPerms.',
    filesCount: 18,
    plugins: [
      {
        name: 'WorldEdit',
        fileName: 'WorldEdit-7.3.0.jar',
        version: '7.3.0',
        author: 'EngineHub',
        enabled: true,
        description: 'أقوى أداة لتشكيل وبناء العوالم.',
        category: 'world',
        fileSizeMB: 4.8,
      },
      {
        name: 'EssentialsX',
        fileName: 'EssentialsX-2.20.1.jar',
        version: '2.20.1',
        author: 'EssentialsX Team',
        enabled: true,
        description: 'أوامر السرفايفل: /home, /sethome, /tpa, /spawn.',
        category: 'admin',
        fileSizeMB: 3.2,
      },
      {
        name: 'Geyser-Spigot',
        fileName: 'Geyser-Spigot-2.4.0.jar',
        version: '2.4.0',
        author: 'GeyserMC',
        enabled: true,
        description: 'جسر لعب مشترك للاعبي الجوال والبيدروك.',
        category: 'utility',
        fileSizeMB: 18.5,
      },
      {
        name: 'LuckPerms',
        fileName: 'LuckPerms-5.4.102.jar',
        version: '5.4.102',
        author: 'Luck',
        enabled: true,
        description: 'إدارة رتب اللاعبين والمشرفين.',
        category: 'protection',
        fileSizeMB: 2.1,
      },
      {
        name: 'ClearLag',
        fileName: 'Clearlag-3.2.2.jar',
        version: '3.2.2',
        author: 'bob7l',
        enabled: true,
        description: 'تنظيف المخلفات ورفع الـ TPS.',
        category: 'utility',
        fileSizeMB: 0.6,
      },
    ],
  },
  {
    id: 'setup-fabric-performance',
    name: 'سيت اب فابريك الأداء الخارق وتيراليث (Fabric Super Boost)',
    nameEn: 'Fabric Ultimate Performance & Terralith',
    category: 'fabric',
    badge: 'أداء خارق ⚡',
    icon: '🚀',
    software: 'Fabric 1.21.1',
    ramMB: 6144,
    description: 'سيرفر فابريك مودات مع مودات تسريع الفيزياء Lithium و FerriteCore لتقليل الرام 40%، عوالم Terralith الساحرة بـ 85+ بيوم جديد، وشات صوتي تقاربي 3D Simple Voice Chat.',
    descriptionEn: 'Fabric 1.21 with Lithium physics optimizations, FerriteCore memory reduction, Terralith biomes, and Simple Voice Chat.',
    filesCount: 16,
    mods: [
      {
        name: 'Fabric API',
        fileName: 'fabric-api-0.100.1+1.21.jar',
        version: '0.100.1',
        author: 'FabricMC',
        enabled: true,
        description: 'المكتبة الأساسية لمودات فابريك.',
        side: 'both',
        fileSizeMB: 2.4,
      },
      {
        name: 'Lithium',
        fileName: 'lithium-fabric-0.12.7.jar',
        version: '0.12.7',
        author: 'CaffeineMC',
        enabled: true,
        description: 'تسريع الأداء وحسابات الفيزياء.',
        side: 'server',
        fileSizeMB: 0.8,
      },
      {
        name: 'FerriteCore',
        fileName: 'ferritecore-6.0.3-fabric.jar',
        version: '6.0.3',
        author: 'malte0811',
        enabled: true,
        description: 'تقليص استهلاك الرام بنسبة 40%.',
        side: 'both',
        fileSizeMB: 0.3,
      },
      {
        name: 'Simple Voice Chat',
        fileName: 'voicechat-fabric-1.21-2.5.15.jar',
        version: '2.5.15',
        author: 'henkelmax',
        enabled: true,
        description: 'شات صوتي تقاربي داخل اللعبة.',
        side: 'both',
        fileSizeMB: 5.6,
      },
      {
        name: 'Terralith',
        fileName: 'Terralith_1.21_v2.5.4.jar',
        version: '2.5.4',
        author: 'Stardust Labs',
        enabled: true,
        description: 'إضافة 85+ منطقة حيوية وجبال ضخمة.',
        side: 'both',
        fileSizeMB: 8.2,
      },
    ],
  },
  {
    id: 'setup-anti-grief',
    name: 'سيت اب الأمان والحماية التامة ضد التخريب (Hardened Anti-Grief)',
    nameEn: 'Hardened Anti-Grief & Protection Pack',
    category: 'minecraft',
    badge: 'حماية 100% 🛡️',
    icon: '🔒',
    software: 'PaperMC 1.21.1',
    ramMB: 4096,
    description: 'سيت اب احترافي مخصص للسيرفرات العامة: CoreProtect لاسترجاع أي بلوكة مخربة بأمر واحد (/co rollback)، و GriefPrevention لحماية أراضي اللاعبين بمجرفة الذهب.',
    descriptionEn: 'Anti-grief protection with CoreProtect block logging rollback and GriefPrevention land claims.',
    filesCount: 14,
    plugins: [
      {
        name: 'CoreProtect',
        fileName: 'CoreProtect-22.4.jar',
        version: '22.4',
        author: 'Intelli',
        enabled: true,
        description: 'تسجيل واسترجاع أي تخريب بالبلوكات واللوت.',
        category: 'protection',
        fileSizeMB: 2.8,
      },
      {
        name: 'GriefPrevention',
        fileName: 'GriefPrevention-16.18.2.jar',
        version: '16.18.2',
        author: 'RoboMWM',
        enabled: true,
        description: 'حماية الأراضي والمنازل بسهولة بالمجرفة الذهبية.',
        category: 'protection',
        fileSizeMB: 1.5,
      },
      {
        name: 'LuckPerms',
        fileName: 'LuckPerms-5.4.102.jar',
        version: '5.4.102',
        author: 'Luck',
        enabled: true,
        description: 'إدارة رتب المشرفين واللاعبين.',
        category: 'protection',
        fileSizeMB: 2.1,
      },
    ],
  },
  {
    id: 'setup-web-portal',
    name: 'سيت اب متجر وبوابة ويب لسيرفر ماين كرافت (Server Web Store)',
    nameEn: 'Minecraft Server Web Store & Portal',
    category: 'web',
    badge: 'موقع ويب 🌐',
    icon: '🛒',
    software: 'Node.js / Express',
    ramMB: 1024,
    description: 'صفحة موقع متكاملة لسيرفرك: متجر شراء رتب افتراضية (VIP, MVP)، عداد اللاعبين المتصلين أونلاين، صفحة قوانين السيرفر، وزر نسخ الآي بي.',
    descriptionEn: 'Complete web portal for your server with rank store, live online players counter, and server rules.',
    filesCount: 6,
  },
];
