export type ServerType = 'minecraft' | 'web' | 'database' | 'game';

export type ServerStatus = 'online' | 'offline' | 'starting' | 'stopping' | 'error';

export interface ServerPlayer {
  id: string;
  name: string;
  uuid: string;
  ping: number; // ms
  health: number; // 0 to 20
  isOp: boolean;
  isBanned?: boolean;
  joinedAt: string;
  gamemode: 'survival' | 'creative' | 'adventure' | 'spectator';
}

export interface ServerLog {
  id: string;
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'SYSTEM';
  message: string;
}

export interface ServerMetrics {
  cpuUsage: number; // percentage 0-100
  memoryUsageMB: number; // in MB
  memoryAllocatedMB: number;
  tps?: number; // 0-20 for Minecraft
  uptimeSeconds: number;
  networkInKBps: number;
  networkOutKBps: number;
}

export interface MinecraftConfig {
  motd: string;
  maxPlayers: number;
  gamemode: 'survival' | 'creative' | 'adventure';
  difficulty: 'peaceful' | 'easy' | 'normal' | 'hard';
  pvp: boolean;
  hardcore: boolean;
  viewDistance: number;
  onlineMode: boolean;
  allowFlight: boolean;
  spawnProtection: number;
  seed: string;
  serverSoftware: 'PaperMC' | 'Spigot' | 'Purpur' | 'Fabric' | 'Forge' | 'Vanilla' | 'Bedrock';
  version: string;
}

export interface WebServerConfig {
  documentRoot: string;
  htmlContent: string;
  cssContent: string;
  jsContent: string;
  enableCors: boolean;
  framework: 'Static HTML' | 'Express.js' | 'Next.js Preview' | 'Python Flask';
  routes: Array<{ path: string; method: 'GET' | 'POST'; response: string }>;
}

export interface DatabaseConfig {
  dbType: 'redis' | 'sqlite' | 'postgres-sim';
  keys: Array<{ key: string; value: string; type: string; ttl: number }>;
}

export interface BackupSnapshot {
  id: string;
  name: string;
  createdAt: string;
  sizeMB: number;
  serverType: ServerType;
  description: string;
}

export interface ServerPlugin {
  id: string;
  name: string;
  fileName: string;
  version: string;
  author: string;
  enabled: boolean;
  description: string;
  category: 'admin' | 'world' | 'economy' | 'protection' | 'utility';
  fileSizeMB: number;
}

export interface FabricMod {
  id: string;
  name: string;
  fileName: string;
  version: string;
  author: string;
  enabled: boolean;
  description: string;
  side: 'server' | 'both' | 'client';
  fileSizeMB: number;
}

export interface VirtualFile {
  path: string; // e.g. "/server.properties" or "/config/paper-global.yml"
  name: string;
  isDirectory: boolean;
  sizeBytes: number;
  lastModified: string;
  content?: string; // Text content for editor
}

export interface PlayitTunnelConfig {
  enabled: boolean;
  publicDomain: string; // e.g. "ahmed-craft.auto.playit.gg"
  publicPort: number; // e.g. 38421
  tunnelType: 'minecraft-java' | 'minecraft-bedrock' | 'tcp' | 'udp' | 'http';
  status: 'connected' | 'disconnected' | 'connecting';
  agentVersion: string;
  assignedAddress: string; // e.g. "ahmed-craft.auto.playit.gg:38421"
}

export interface LocalServer {
  id: string;
  name: string;
  type: ServerType;
  port: number;
  status: ServerStatus;
  autoRestart: boolean;
  allocatedRamMB: number;
  createdAt: string;
  imageBanner?: string;
  description: string;
  metrics: ServerMetrics;
  logs: ServerLog[];
  players?: ServerPlayer[];
  minecraftConfig?: MinecraftConfig;
  webConfig?: WebServerConfig;
  dbConfig?: DatabaseConfig;
  plugins?: ServerPlugin[];
  mods?: FabricMod[];
  files?: VirtualFile[];
  playitConfig?: PlayitTunnelConfig;
  backups: BackupSnapshot[];
}

export interface LocalNetworkInfo {
  localIp: string;
  subnetMask: string;
  gateway: string;
  hostname: string;
  macAddress: string;
}
