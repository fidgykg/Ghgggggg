export type UserRole = 'superadmin' | 'admin' | 'moderator' | 'user';

export interface ChatMessage {
  id: string;
  text: string;
  authorUid: string;
  authorEmail: string;
  authorName: string;
  authorPhoto?: string;
  authorRole: UserRole;
  isDeleted?: boolean;
  deletedBy?: string;
  deletedByEmail?: string;
  isPinned?: boolean;
  createdAt: number; // epoch ms or timestamp
}

export type SuggestionStatus = 'pending' | 'in_progress' | 'completed' | 'rejected';
export type SuggestionCategory = 'server' | 'performance' | 'mods_plugins' | 'feature' | 'general';

export interface Suggestion {
  id: string;
  title: string;
  description: string;
  category: SuggestionCategory;
  authorUid: string;
  authorEmail: string;
  authorName: string;
  authorPhoto?: string;
  status: SuggestionStatus;
  adminResponse?: string;
  respondedByEmail?: string;
  respondedAt?: number | null;
  votesCount: number;
  votedUsers: string[]; // UIDs of users who voted
  createdAt: number;
  updatedAt: number;
}
