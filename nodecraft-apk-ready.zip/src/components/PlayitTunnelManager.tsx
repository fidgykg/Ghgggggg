import React, { useState } from 'react';
import { Globe2, Copy, Check, Radio, ExternalLink, ShieldCheck, RefreshCw, Terminal, Sparkles, AlertCircle } from 'lucide-react';
import { LocalServer, PlayitTunnelConfig } from '../types/server';
import { Language, I18N } from '../utils/i18n';

interface PlayitTunnelManagerProps {
  server: LocalServer;
  onUpdateServer: (updated: LocalServer) => void;
  lang: Language;
}

export const PlayitTunnelManager: React.FC<PlayitTunnelManagerProps> = ({
  server,
  onUpdateServer,
  lang,
}) => {
  const t = I18N[lang];
  const [copied, setCopied] = useState(false);
  const [subdomainInput, setSubdomainInput] = useState(
    server.playitConfig?.publicDomain.replace('.auto.playit.gg', '') || 'ahop508-server'
  );
  const [isEditingDomain, setIsEditingDomain] = useState(false);
  const [testingPing, setTestingPing] = useState(false);
  const [pingResult, setPingResult] = useState<number | null>(null);

  const playit = server.playitConfig || {
    enabled: true,
    publicDomain: 'ahop508-survival.auto.playit.gg',
    publicPort: 38421,
    tunnelType: 'minecraft-java',
    status: 'connected',
    agentVersion: '0.15.26',
    assignedAddress: 'ahop508-survival.auto.playit.gg:38421',
  };

  const handleToggleTunnel = () => {
    const nextEnabled = !playit.enabled;
    const time = new Date().toLocaleTimeString('en-GB');

    const updatedConfig: PlayitTunnelConfig = {
      ...playit,
      enabled: nextEnabled,
      status: nextEnabled ? 'connected' : 'disconnected',
    };

    onUpdateServer({
      ...server,
      playitConfig: updatedConfig,
      logs: [
        ...server.logs,
        {
          id: `playit-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: nextEnabled
            ? `[playit.gg] Tunnel agent connected. Public IP: ${updatedConfig.assignedAddress}`
            : `[playit.gg] Tunnel agent stopped. Public IP disabled.`,
        },
      ],
    });
  };

  const handleCopyPublicAddress = () => {
    navigator.clipboard.writeText(playit.assignedAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveSubdomain = () => {
    const cleanSub = subdomainInput.trim().toLowerCase().replace(/[^a-z0-9-]/g, '') || 'local-server';
    const newDomain = `${cleanSub}.auto.playit.gg`;
    const newAddress = `${newDomain}:${playit.publicPort}`;
    const time = new Date().toLocaleTimeString('en-GB');

    const updatedConfig: PlayitTunnelConfig = {
      ...playit,
      publicDomain: newDomain,
      assignedAddress: newAddress,
    };

    onUpdateServer({
      ...server,
      playitConfig: updatedConfig,
      logs: [
        ...server.logs,
        {
          id: `playit-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: `[playit.gg] Updated tunnel public domain: ${newAddress}`,
        },
      ],
    });

    setIsEditingDomain(false);
  };

  const handleTestTunnelPing = () => {
    setTestingPing(true);
    setPingResult(null);
    setTimeout(() => {
      setTestingPing(false);
      setPingResult(Math.floor(Math.random() * 18) + 12); // ~12-30ms
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Flagship playit.gg Banner */}
      <div className="bg-gradient-to-r from-neutral-900 via-neutral-900 to-indigo-950/40 border border-neutral-800 rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shrink-0">
              <Globe2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white tracking-tight">
                  {lang === 'ar' ? 'الآي بي العام عبر playit.gg (لعب خارجي دون بورت)' : 'playit.gg Global IP Tunnel'}
                </h3>
                <span
                  className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${
                    playit.enabled && playit.status === 'connected'
                      ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/60'
                      : 'bg-neutral-950 text-neutral-500 border border-neutral-800'
                  }`}
                >
                  {playit.enabled && playit.status === 'connected' ? 'ONLINE // TUNNEL READY' : 'OFFLINE'}
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-1 max-w-xl leading-relaxed">
                {lang === 'ar'
                  ? 'يتيح لك playit.gg مشاركة السيرفر مع أصدقائك في أي مكان في العالم مجاناً برابط مباشر دون الحاجة لفتح أي بورت في راوتر الإنترنت (Zero Port Forwarding).'
                  : 'playit.gg assigns a free global IP & domain to play with friends worldwide without port forwarding.'}
              </p>
            </div>
          </div>

          {/* Master Toggle */}
          <button
            onClick={handleToggleTunnel}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all shrink-0 ${
              playit.enabled
                ? 'bg-emerald-400 hover:bg-emerald-300 text-neutral-950 shadow-sm shadow-emerald-950'
                : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
            }`}
          >
            {playit.enabled
              ? lang === 'ar'
                ? 'نفق playit.gg مفعّل ✓'
                : 'Tunnel Enabled ✓'
              : lang === 'ar'
              ? 'تفعيل نفق playit.gg'
              : 'Enable playit.gg Tunnel'}
          </button>
        </div>
      </div>

      {/* Public IP Share Card */}
      {playit.enabled && (
        <div className="bg-neutral-950 border border-indigo-500/30 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span className="font-semibold text-white">
              {lang === 'ar' ? 'العنوان العام المخصص لأصدقائك في اللعبة (Public Join IP):' : 'Public Join Address:'}
            </span>
            <span className="font-mono text-indigo-400">playit Agent v{playit.agentVersion}</span>
          </div>

          {/* Copyable IP Box */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-neutral-900 p-3.5 rounded-lg border border-neutral-800">
            <div className="font-mono text-base font-bold text-emerald-400 select-all truncate">
              {playit.assignedAddress}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleTestTunnelPing}
                disabled={testingPing}
                className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-xs font-mono transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${testingPing ? 'animate-spin' : ''}`} />
                <span>
                  {testingPing
                    ? lang === 'ar'
                      ? 'فحص...'
                      : 'Testing...'
                    : pingResult !== null
                    ? `${pingResult}ms`
                    : lang === 'ar'
                    ? 'فحص البينغ'
                    : 'Ping Test'}
                </span>
              </button>

              <button
                onClick={handleCopyPublicAddress}
                className="px-4 py-1.5 rounded bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold text-xs transition-colors flex items-center gap-1.5 shadow-sm"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? (lang === 'ar' ? 'تم النسخ!' : 'Copied!') : (lang === 'ar' ? 'نسخ الآي بي' : 'Copy IP')}</span>
              </button>
            </div>
          </div>

          {/* How to join instructions */}
          <div className="bg-neutral-900/50 p-4 rounded-lg border border-neutral-800/80 text-xs text-neutral-300 space-y-2">
            <div className="font-semibold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{lang === 'ar' ? 'كيف يدخل أصدقاؤك بالسيرفر؟' : 'How friends join using playit.gg:'}</span>
            </div>
            <ol className="list-decimal ps-4 space-y-1 text-neutral-400 text-xs leading-relaxed">
              <li>أرسل لأصدقائك العنوان أعلاه: <code className="text-emerald-400 font-mono select-all">{playit.assignedAddress}</code></li>
              <li>يفتح صديقك لعبة ماين كرافت ويذهب إلى <strong>Multiplayer</strong> ثم <strong>Direct Connection</strong>.</li>
              <li>يلصق العنوان ويضغط <strong>Join Server</strong> وسيدخل فوراً حتى لو كان في دولة أخرى!</li>
            </ol>
          </div>

          {/* Custom Subdomain Editor */}
          <div className="pt-2 border-t border-neutral-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="text-neutral-400">
              <span>{lang === 'ar' ? 'الدومين المخصص:' : 'Custom Domain:'} </span>
              <span className="font-mono text-white font-bold">{playit.publicDomain}</span>
            </div>

            {isEditingDomain ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={subdomainInput}
                  onChange={(e) => setSubdomainInput(e.target.value)}
                  className="bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                  placeholder="اسم-السيرفر"
                />
                <span className="font-mono text-neutral-500">.auto.playit.gg</span>
                <button
                  onClick={handleSaveSubdomain}
                  className="px-3 py-1 bg-indigo-500 hover:bg-indigo-400 text-white font-bold rounded text-xs"
                >
                  حفظ
                </button>
                <button
                  onClick={() => setIsEditingDomain(false)}
                  className="px-2 py-1 text-neutral-400 hover:text-white text-xs"
                >
                  إلغاء
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsEditingDomain(true)}
                className="text-indigo-400 hover:text-indigo-300 font-semibold underline text-xs"
              >
                {lang === 'ar' ? 'تخصيص اسم الدومين' : 'Customize Domain Name'}
              </button>
            )}
          </div>
        </div>
      )}

      {/* playit.gg Agent Setup Guide */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 space-y-3">
        <h4 className="text-sm font-bold text-white flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span>{lang === 'ar' ? 'تشغيل تطبيق playit.gg محلياً على جهازك' : 'Local playit.gg CLI & Program Runner'}</span>
        </h4>
        <p className="text-xs text-neutral-400 leading-relaxed">
          {lang === 'ar'
            ? 'إذا أردت تشغيل البرنامج الأصلي playit.gg على جهاز الكمبيوتر لتثبيت النفق الحقيقي:'
            : 'To run the official playit program on your machine for permanent tunneling:'}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
          <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <div className="text-neutral-500 mb-1"># نظام Windows (تحميل البرنامج المباشر):</div>
            <code className="text-cyan-300">playit-win64.exe --secret [YOUR_SECRET]</code>
          </div>

          <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
            <div className="text-neutral-500 mb-1"># نظام Linux / Ubuntu / Docker:</div>
            <code className="text-cyan-300">curl -SsL https://playit-cloud.github.io/ppa/key.gpg | gpg --dearmor</code>
          </div>
        </div>
      </div>
    </div>
  );
};
