import React from 'react';
import { Play, Square, RotateCw, Users, Terminal, Globe, Database, Gamepad2, ArrowUpRight, Copy, Check } from 'lucide-react';
import { LocalServer } from '../types/server';
import { Language, I18N } from '../utils/i18n';
import { formatUptime } from '../utils/storage';

interface ServerCardProps {
  server: LocalServer;
  isSelected: boolean;
  onSelect: () => void;
  onStart: (id: string) => void;
  onStop: (id: string) => void;
  onRestart: (id: string) => void;
  lang: Language;
  localIp: string;
}

export const ServerCard: React.FC<ServerCardProps> = ({
  server,
  isSelected,
  onSelect,
  onStart,
  onStop,
  onRestart,
  lang,
  localIp,
}) => {
  const t = I18N[lang];
  const [copied, setCopied] = React.useState(false);

  const fullAddress = `${localIp}:${server.port}`;

  const copyAddress = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(fullAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const getStatusColor = () => {
    switch (server.status) {
      case 'online':
        return 'text-emerald-400';
      case 'starting':
        return 'text-amber-400';
      case 'stopping':
        return 'text-orange-400';
      default:
        return 'text-neutral-400';
    }
  };

  const getTypeIcon = () => {
    switch (server.type) {
      case 'minecraft':
        return <Gamepad2 className="w-4 h-4 text-emerald-400" />;
      case 'web':
        return <Globe className="w-4 h-4 text-cyan-400" />;
      case 'database':
        return <Database className="w-4 h-4 text-purple-400" />;
      default:
        return <Gamepad2 className="w-4 h-4 text-amber-400" />;
    }
  };

  const getTypeLabel = () => {
    switch (server.type) {
      case 'minecraft':
        return `${t.typeMinecraft} ${server.minecraftConfig?.serverSoftware || ''} ${server.minecraftConfig?.version || ''}`;
      case 'web':
        return `${t.typeWeb} · ${server.webConfig?.framework || 'Static'}`;
      case 'database':
        return `${t.typeDatabase} · Redis`;
      default:
        return t.typeGame;
    }
  };

  return (
    <div
      onClick={onSelect}
      className={`group relative rounded-xl border transition-all duration-200 cursor-pointer overflow-hidden ${
        isSelected
          ? 'bg-neutral-900 border-emerald-500/80 shadow-lg shadow-emerald-950/20 ring-1 ring-emerald-500/50'
          : 'bg-neutral-900/60 hover:bg-neutral-900 border-neutral-800 hover:border-neutral-700'
      }`}
    >
      {/* Visual Header / Banner if available */}
      {server.imageBanner && (
        <div className="relative h-28 w-full overflow-hidden bg-neutral-950">
          <img
            src={server.imageBanner}
            alt={server.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-neutral-900/60 to-transparent" />
          {server.minecraftConfig?.version && (
            <div className="absolute top-2.5 start-2.5">
              <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded backdrop-blur-md bg-neutral-950/85 border border-neutral-800/80 text-cyan-400 shadow-sm">
                {server.minecraftConfig.serverSoftware} {server.minecraftConfig.version}
              </span>
            </div>
          )}
          <div className="absolute top-2.5 end-2.5">
            <span
              className={`text-xs font-mono font-medium px-2 py-0.5 rounded backdrop-blur-md bg-neutral-950/80 border border-neutral-800 ${getStatusColor()}`}
            >
              {server.status === 'online'
                ? t.statusOnline
                : server.status === 'starting'
                ? t.statusStarting
                : server.status === 'stopping'
                ? t.statusStopping
                : t.statusOffline}
            </span>
          </div>
        </div>
      )}

      <div className="p-4">
        {/* Type & Metadata line (zero-pill discipline) */}
        <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
          <div className="flex items-center gap-1.5 truncate">
            {getTypeIcon()}
            <span className="truncate">{getTypeLabel()}</span>
          </div>
          {!server.imageBanner && (
            <span className={`font-mono text-xs font-medium ${getStatusColor()}`}>
              {server.status === 'online' ? t.statusOnline : t.statusOffline}
            </span>
          )}
        </div>

        {/* Server Name */}
        <h3 className="text-base font-semibold text-white group-hover:text-emerald-400 transition-colors line-clamp-1 mb-1">
          {server.name}
        </h3>

        {/* MOTD / Description */}
        <p className="text-xs text-neutral-400 line-clamp-1 mb-3">
          {server.minecraftConfig?.motd || server.description}
        </p>

        {/* Connection Port & playit.gg Info */}
        <div className="space-y-1.5 mb-3">
          <div className="flex items-center justify-between bg-neutral-950/80 border border-neutral-800/80 rounded-lg px-2.5 py-1.5 text-xs">
            <div className="flex items-center gap-2 font-mono text-neutral-300 tabular-nums truncate">
              <span className="text-neutral-400">LAN:</span>
              <span className="font-semibold text-emerald-400">:{server.port}</span>
              <span className="text-neutral-400 hidden sm:inline">({fullAddress})</span>
            </div>
            <button
              onClick={copyAddress}
              title={t.copyAddress}
              className="p-1 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          {server.playitConfig?.enabled && (
            <div className="flex items-center justify-between bg-indigo-950/30 border border-indigo-800/40 rounded-lg px-2.5 py-1 text-xs">
              <div className="flex items-center gap-1.5 font-mono text-indigo-300 text-[11px] truncate">
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 shrink-0" />
                <span className="font-bold text-indigo-400">playit:</span>
                <span className="truncate">{server.playitConfig.assignedAddress}</span>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  navigator.clipboard.writeText(server.playitConfig!.assignedAddress);
                }}
                title={lang === 'ar' ? 'نسخ عنوان playit.gg' : 'Copy playit.gg IP'}
                className="p-1 text-indigo-400 hover:text-white rounded hover:bg-indigo-900/50 transition-colors"
              >
                <Copy className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>

        {/* Telemetry Stats (Monospace & Tabular figures) */}
        <div className="grid grid-cols-3 gap-2 text-xs font-mono text-neutral-300 border-t border-neutral-800/60 pt-3 mb-3">
          <div>
            <div className="text-[10px] text-neutral-400">RAM</div>
            <div className="font-medium tabular-nums">
              {server.status === 'online' ? `${server.metrics.memoryUsageMB}MB` : '0MB'}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-neutral-400">CPU</div>
            <div className="font-medium tabular-nums">
              {server.status === 'online' ? `${server.metrics.cpuUsage}%` : '0%'}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-neutral-400">
              {server.type === 'minecraft' ? 'TPS' : server.type === 'web' ? 'UPTIME' : 'KEYS'}
            </div>
            <div className="font-medium text-emerald-400 tabular-nums">
              {server.type === 'minecraft'
                ? server.status === 'online'
                  ? `${server.metrics.tps || 20.0}`
                  : '-'
                : server.type === 'web'
                ? formatUptime(server.metrics.uptimeSeconds, lang)
                : `${server.dbConfig?.keys.length || 0}`}
            </div>
          </div>
        </div>

        {/* Action Controls & Players info */}
        <div className="flex items-center justify-between pt-1">
          {server.type === 'minecraft' ? (
            <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono truncate">
              <div className="flex items-center gap-1 shrink-0">
                <Users className="w-3.5 h-3.5 text-neutral-400" />
                <span>{server.players?.length || 0}/{server.minecraftConfig?.maxPlayers || 20}</span>
              </div>
              {server.mods && server.mods.length > 0 && (
                <span className="text-[11px] text-cyan-400 truncate">
                  · {server.mods.length} {lang === 'ar' ? 'مودات' : 'mods'}
                </span>
              )}
              {server.plugins && server.plugins.length > 0 && (
                <span className="text-[11px] text-emerald-400 truncate">
                  · {server.plugins.length} {lang === 'ar' ? 'إضافات' : 'plugins'}
                </span>
              )}
            </div>
          ) : (
            <div className="text-xs text-neutral-400 font-mono">
              {server.status === 'online' ? formatUptime(server.metrics.uptimeSeconds, lang) : t.statusOffline}
            </div>
          )}

          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            {server.status === 'online' ? (
              <>
                <button
                  onClick={() => onRestart(server.id)}
                  title={t.restart}
                  className="p-1.5 rounded-md text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => onStop(server.id)}
                  title={t.stop}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium text-red-400 bg-red-950/30 hover:bg-red-900/50 border border-red-800/40 transition-colors"
                >
                  <Square className="w-3 h-3 fill-current" />
                  <span>{t.stop}</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => onStart(server.id)}
                disabled={server.status === 'starting'}
                className="flex items-center gap-1 px-3 py-1 rounded-md text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 transition-colors shadow-sm"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>{t.start}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
