import React, { useState } from 'react';
import { X, Gamepad2, Globe, Database, Cpu, HardDrive, CheckCircle2, AlertTriangle, Download } from 'lucide-react';
import { LocalServer, ServerType } from '../types/server';
import { Language, I18N } from '../utils/i18n';
import { SoftwareVersionSelector } from './SoftwareVersionSelector';
import { SoftwareVersionInfo, getSoftwareMeta } from '../data/softwareVersions';

interface NewServerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateServer: (server: LocalServer) => void;
  existingServers: LocalServer[];
  lang: Language;
}

export const NewServerModal: React.FC<NewServerModalProps> = ({
  isOpen,
  onClose,
  onCreateServer,
  existingServers,
  lang,
}) => {
  const t = I18N[lang];
  const isAr = lang === 'ar';

  const [serverType, setServerType] = useState<ServerType>('minecraft');
  const [name, setName] = useState('');
  const [port, setPort] = useState(25566);
  const [ram, setRam] = useState(4096);
  const [motd, setMotd] = useState('سيرفر جديد على الشبكة المحلية §e[1.21.4]');
  const [software, setSoftware] = useState<string>('PaperMC');
  const [version, setVersion] = useState<string>('1.21.4');
  const [versionInfo, setVersionInfo] = useState<SoftwareVersionInfo | null>(null);

  if (!isOpen) return null;

  // Check port conflict
  const isPortConflict = existingServers.some((s) => s.port === Number(port));

  // Change default ports and MOTD when type changes
  const handleTypeSelect = (type: ServerType) => {
    setServerType(type);
    if (type === 'minecraft') {
      const nextMcPort = 25565 + existingServers.filter((s) => s.type === 'minecraft').length;
      setPort(nextMcPort);
      setRam(4096);
      setName('سيرفر ماين كرافت جديد');
      setMotd('سيرفر ماين كرافت سرفايفل محلي §a[1.21.4]');
      setSoftware('PaperMC');
      setVersion('1.21.4');
    } else if (type === 'web') {
      const nextWebPort = 8080 + existingServers.filter((s) => s.type === 'web').length;
      setPort(nextWebPort);
      setRam(1024);
      setName('موقع ويب تجريبي محلي');
      setMotd('خادم ويب محلي فائق السرعة');
      setSoftware('Static HTML');
      setVersion('1.26.2');
    } else if (type === 'database') {
      const nextDbPort = 6379 + existingServers.filter((s) => s.type === 'database').length;
      setPort(nextDbPort);
      setRam(512);
      setName('خادم كاش محلي (Redis)');
      setMotd('In-Memory Data Store');
      setSoftware('redis');
      setVersion('7.4.2');
    }
  };

  const handleSoftwareChange = (newSw: string) => {
    setSoftware(newSw);
    const meta = getSoftwareMeta(serverType, newSw);
    if (meta && meta.versions.length > 0) {
      const defaultVer = meta.versions.find((v) => v.tag === 'recommended') || meta.versions[0];
      setVersion(defaultVer.version);
      setVersionInfo(defaultVer);
      setMotd((prev) =>
        prev.includes('[')
          ? prev.replace(/\[.*?\]/, `[${defaultVer.version}]`)
          : `${prev} §a[${defaultVer.version}]`
      );
    }
  };

  const handleVersionChange = (newVer: string, info: SoftwareVersionInfo) => {
    setVersion(newVer);
    setVersionInfo(info);
    setMotd((prev) =>
      prev.includes('[')
        ? prev.replace(/\[.*?\]/, `[${newVer}]`)
        : `${prev} §a[${newVer}]`
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newId = `${serverType}-${Date.now().toString(36)}`;
    const now = new Date().toLocaleTimeString('en-GB');

    const meta = getSoftwareMeta(serverType, software);
    const currentVerInfo =
      versionInfo ||
      meta?.versions.find((v) => v.version === version) ||
      meta?.versions[0];

    const binaryFileName = currentVerInfo?.fileName || `${software.toLowerCase()}-${version}.jar`;
    const binaryFileSize = currentVerInfo ? Math.round(currentVerInfo.fileSizeMB * 1024 * 1024) : 45000000;

    const newServer: LocalServer = {
      id: newId,
      name: name.trim(),
      type: serverType,
      port: Number(port),
      status: 'offline',
      autoRestart: false,
      allocatedRamMB: Number(ram),
      createdAt: new Date().toISOString().slice(0, 10),
      description: motd,
      metrics: {
        cpuUsage: 0,
        memoryUsageMB: 0,
        memoryAllocatedMB: Number(ram),
        tps: serverType === 'minecraft' ? 20.0 : undefined,
        uptimeSeconds: 0,
        networkInKBps: 0,
        networkOutKBps: 0,
      },
      logs: [
        {
          id: `log-${Date.now()}-1`,
          timestamp: now,
          level: 'INFO',
          message: `Server "${name.trim()}" created successfully with software: ${software} ${version}.`,
        },
        {
          id: `log-${Date.now()}-2`,
          timestamp: now,
          level: 'INFO',
          message: `Ready to start on port ${port}. Binary file: ${binaryFileName}.`,
        },
      ],
      backups: [],
    };

    if (serverType === 'minecraft') {
      newServer.players = [];
      newServer.minecraftConfig = {
        motd: motd,
        maxPlayers: 20,
        gamemode: 'survival',
        difficulty: 'normal',
        pvp: true,
        hardcore: false,
        viewDistance: 10,
        onlineMode: false,
        allowFlight: false,
        spawnProtection: 16,
        seed: Math.floor(Math.random() * 10000000000).toString(),
        serverSoftware: software as any,
        version: version,
      };
      newServer.imageBanner = '/src/assets/images/minecraft_server_hero_1793499576781.jpg';

      if (software === 'Fabric') {
        newServer.mods = [
          {
            id: `mod-${Date.now()}-1`,
            name: 'Fabric API',
            fileName: `fabric-api-0.100.1+${version}.jar`,
            version: '0.100.1',
            author: 'FabricMC',
            enabled: true,
            description: 'المكتبة الأساسية لمودات فابريك.',
            side: 'both',
            fileSizeMB: 2.4,
          },
          {
            id: `mod-${Date.now()}-2`,
            name: 'Lithium',
            fileName: 'lithium-fabric-0.12.7.jar',
            version: '0.12.7',
            author: 'CaffeineMC',
            enabled: true,
            description: 'تسريع الأداء والفيزياء.',
            side: 'server',
            fileSizeMB: 0.8,
          },
        ];
      } else if (software === 'Forge') {
        newServer.mods = [
          {
            id: `mod-${Date.now()}-1`,
            name: 'Create',
            fileName: `create-forge-${version}.jar`,
            version: '0.5.1',
            author: 'Simi',
            enabled: true,
            description: 'مود الآلات والمحركات والمصانع العملاقة.',
            side: 'both',
            fileSizeMB: 18.5,
          },
        ];
      } else {
        newServer.plugins = [
          {
            id: `pl-${Date.now()}-1`,
            name: 'WorldEdit',
            fileName: 'WorldEdit-7.3.0.jar',
            version: '7.3.0',
            author: 'EngineHub',
            enabled: true,
            description: 'أداة تشكيل وبناء العوالم.',
            category: 'world',
            fileSizeMB: 4.8,
          },
        ];
      }

      newServer.files = [
        {
          path: `/${binaryFileName}`,
          name: binaryFileName,
          isDirectory: false,
          sizeBytes: binaryFileSize,
          lastModified: new Date().toISOString().slice(0, 10),
          content: `[Binary server payload: ${software} ${version}]`,
        },
        {
          path: '/server.properties',
          name: 'server.properties',
          isDirectory: false,
          sizeBytes: 420,
          lastModified: new Date().toISOString().slice(0, 10),
          content: `server-port=${port}\nmotd=${motd}\npvp=true\nonline-mode=false\ngamemode=survival\ndifficulty=normal\nmax-players=20\nlevel-name=world`,
        },
        {
          path: '/eula.txt',
          name: 'eula.txt',
          isDirectory: false,
          sizeBytes: 15,
          lastModified: new Date().toISOString().slice(0, 10),
          content: 'eula=true',
        },
      ];
    } else if (serverType === 'web') {
      newServer.webConfig = {
        documentRoot: '/var/www/html',
        framework: software === 'Express.js' ? 'Express.js' : software === 'Python Flask' ? 'Python Flask' : 'Static HTML',
        enableCors: true,
        htmlContent: `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>${name}</title>
  <style>
    body { font-family: system-ui, sans-serif; background: #0b0f19; color: #fff; padding: 3rem; text-align: center; }
    h1 { color: #34d399; }
  </style>
</head>
<body>
  <h1>${name}</h1>
  <p>يعمل بنجاح على المنفذ :${port} محلياً!</p>
  <p>النظام: ${software} (الإصدار: ${version})</p>
</body>
</html>`,
        cssContent: '',
        jsContent: 'console.log("Ready");',
        routes: [{ path: '/', method: 'GET', response: 'Index HTML Served' }],
      };
      newServer.imageBanner = '/src/assets/images/web_server_datacenter_1793499577418.jpg';
    } else if (serverType === 'database') {
      newServer.dbConfig = {
        dbType: 'redis',
        keys: [{ key: 'app:status', value: 'online', type: 'string', ttl: -1 }],
      };
    }

    onCreateServer(newServer);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between">
          <h3 className="text-base font-bold text-white tracking-tight">{t.newServerBtn}</h3>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* Server Category Selector */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-2">
              {isAr ? 'نوع السيرفر المطلوب:' : 'Select Server Type:'}
            </label>
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => handleTypeSelect('minecraft')}
                className={`p-3 rounded-lg border text-start transition-all ${
                  serverType === 'minecraft'
                    ? 'bg-emerald-950/40 border-emerald-500 text-white'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <Gamepad2 className="w-5 h-5 text-emerald-400 mb-2" />
                <div className="text-xs font-bold">{t.typeMinecraft}</div>
                <div className="text-[10px] text-neutral-400">Java & Bedrock</div>
              </button>

              <button
                type="button"
                onClick={() => handleTypeSelect('web')}
                className={`p-3 rounded-lg border text-start transition-all ${
                  serverType === 'web'
                    ? 'bg-cyan-950/40 border-cyan-500 text-white'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <Globe className="w-5 h-5 text-cyan-400 mb-2" />
                <div className="text-xs font-bold">{t.typeWeb}</div>
                <div className="text-[10px] text-neutral-400">HTML / Node.js</div>
              </button>

              <button
                type="button"
                onClick={() => handleTypeSelect('database')}
                className={`p-3 rounded-lg border text-start transition-all ${
                  serverType === 'database'
                    ? 'bg-purple-950/40 border-purple-500 text-white'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <Database className="w-5 h-5 text-purple-400 mb-2" />
                <div className="text-xs font-bold">{t.typeDatabase}</div>
                <div className="text-[10px] text-neutral-400">Redis / Key-Value</div>
              </button>
            </div>
          </div>

          {/* Software & Version Selection (Dynamic per selected system) */}
          <SoftwareVersionSelector
            category={serverType}
            selectedSoftware={software}
            onSoftwareChange={handleSoftwareChange}
            selectedVersion={version}
            onVersionChange={handleVersionChange}
            lang={lang}
          />

          {/* Name & MOTD */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                {isAr ? 'اسم السيرفر:' : 'Server Name:'}
              </label>
              <input
                type="text"
                required
                placeholder={isAr ? 'مثال: سيرفر الأصدقاء' : 'e.g. Friends Survival'}
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                {isAr ? 'رسالة السيرفر (MOTD):' : 'Server MOTD:'}
              </label>
              <input
                type="text"
                value={motd}
                onChange={(e) => setMotd(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Port & RAM */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                {t.port} (Network Port):
              </label>
              <input
                type="number"
                required
                value={port}
                onChange={(e) => setPort(Number(e.target.value))}
                className={`w-full bg-neutral-950 border rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none ${
                  isPortConflict ? 'border-amber-500' : 'border-neutral-800 focus:border-emerald-500'
                }`}
              />
              {isPortConflict && (
                <div className="flex items-center gap-1 text-[11px] text-amber-400 mt-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{t.portConflictWarning}</span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                {t.allocatedRam} (RAM):
              </label>
              <select
                value={ram}
                onChange={(e) => setRam(Number(e.target.value))}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
              >
                <option value={1024}>1024 MB (1 GB)</option>
                <option value={2048}>2048 MB (2 GB)</option>
                <option value={4096}>4096 MB (4 GB) - موصى به</option>
                <option value={8192}>8192 MB (8 GB)</option>
                <option value={16384}>16384 MB (16 GB)</option>
              </select>
            </div>
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-between pt-3 border-t border-neutral-800">
            <div className="text-xs font-mono text-neutral-400 flex items-center gap-1.5">
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>
                {software} <span className="text-emerald-400 font-bold">{version}</span>
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-xs font-medium text-neutral-400 hover:text-white transition-colors"
              >
                {t.cancel}
              </button>
              <button
                type="submit"
                disabled={isPortConflict}
                className="px-5 py-2 rounded-lg text-xs font-bold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 disabled:opacity-50 transition-colors shadow-sm"
              >
                {isAr ? 'تنزيل النظام وتثبيت السيرفر' : 'Download & Create Server'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
