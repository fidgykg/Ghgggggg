import React, { useState, useRef, useEffect } from 'react';
import {
  Server,
  Plus,
  Crown,
  ShieldCheck,
  Shield,
  LogOut,
  ChevronDown,
  User,
  MessageSquare,
  Lightbulb,
  Sparkles,
  Users,
} from 'lucide-react';
import { Language, I18N } from '../utils/i18n';
import { useAuth } from '../contexts/AuthContext';
import { SUPER_ADMIN_EMAIL } from '../lib/firebase';
import { maskEmail } from '../utils/privacy';

interface HeaderProps {
  currentTab: 'servers' | 'ports' | 'network' | 'snapshots' | 'chat' | 'suggestions';
  onTabChange: (tab: 'servers' | 'ports' | 'network' | 'snapshots' | 'chat' | 'suggestions') => void;
  onOpenNewServer: () => void;
  onOpenAdminPanel: () => void;
  onOpenLoginModal: () => void;
  lang: Language;
  onToggleLang: () => void;
  localIp: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  onOpenNewServer,
  onOpenAdminPanel,
  onOpenLoginModal,
  lang,
  onToggleLang,
  localIp,
}) => {
  const t = I18N[lang];
  const {
    currentUser,
    userProfile,
    isAdmin,
    isSuperAdmin,
    isChatModerator,
    logout,
    loading: authLoading,
    setIsAccountModalOpen,
  } = useAuth();

  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-neutral-950/95 backdrop-blur-md border-b border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-3 h-16">
          
          {/* Zone 1: Logo & LAN info */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Server className="w-5 h-5" />
            </div>
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                onTabChange('servers');
              }}
              className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 hover:text-emerald-400 transition-colors"
            >
              {t.brand}
            </a>
            <span className="hidden lg:inline-block text-xs font-mono text-neutral-400 border-s border-neutral-800 ps-3">
              LAN: {localIp}
            </span>
          </div>

          {/* Zone 2: Navigation Links (Including Chat & Suggestions) */}
          <nav className="hidden md:flex items-center gap-4 lg:gap-6 text-sm font-medium text-neutral-400">
            <button
              onClick={() => onTabChange('servers')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
                currentTab === 'servers'
                  ? 'text-white border-b-2 border-emerald-500 font-semibold'
                  : 'hover:text-neutral-200'
              }`}
            >
              {t.navServers}
            </button>
            <button
              onClick={() => onTabChange('ports')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
                currentTab === 'ports'
                  ? 'text-white border-b-2 border-emerald-500 font-semibold'
                  : 'hover:text-neutral-200'
              }`}
            >
              {t.navPorts}
            </button>
            <button
              onClick={() => onTabChange('network')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
                currentTab === 'network'
                  ? 'text-white border-b-2 border-emerald-500 font-semibold'
                  : 'hover:text-neutral-200'
              }`}
            >
              {t.navNetwork}
            </button>
            <button
              onClick={() => onTabChange('snapshots')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 ${
                currentTab === 'snapshots'
                  ? 'text-white border-b-2 border-emerald-500 font-semibold'
                  : 'hover:text-neutral-200'
              }`}
            >
              {t.navSnapshots}
            </button>

            {/* Chat & Chat Moderator Tab */}
            <button
              onClick={() => onTabChange('chat')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 flex items-center gap-1.5 ${
                currentTab === 'chat'
                  ? 'text-sky-400 border-b-2 border-sky-500 font-semibold'
                  : 'hover:text-sky-300'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
              <span>{t.navChat}</span>
              {isChatModerator && (
                <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
              )}
            </button>

            {/* Suggestions Tab */}
            <button
              onClick={() => onTabChange('suggestions')}
              className={`whitespace-nowrap shrink-0 transition-colors py-1 flex items-center gap-1.5 ${
                currentTab === 'suggestions'
                  ? 'text-amber-400 border-b-2 border-amber-500 font-semibold'
                  : 'hover:text-amber-300'
              }`}
            >
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.navSuggestions}</span>
            </button>
          </nav>

          {/* Zone 3: Actions + User Account / Rank Switcher */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Language toggle */}
            <button
              onClick={onToggleLang}
              className="text-xs px-2.5 py-1.5 rounded border border-neutral-800 text-neutral-300 hover:text-white hover:border-neutral-700 transition-colors font-medium whitespace-nowrap"
              title="تغيير اللغة / Switch Language"
            >
              {lang === 'ar' ? 'English' : 'عربي'}
            </button>

            {/* Admin Panel button (visible when logged in as admin or superadmin) */}
            {isAdmin && (
              <button
                onClick={onOpenAdminPanel}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:border-amber-400 transition-all shadow-sm"
                title={lang === 'ar' ? 'فتح لوحة الإدارة' : 'Open Admin Panel'}
              >
                <Crown className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">
                  {lang === 'ar' ? 'لوحة الإدارة' : 'Admin Panel'}
                </span>
              </button>
            )}

            {/* New Server Button */}
            <button
              onClick={onOpenNewServer}
              className="flex items-center gap-1.5 px-3 sm:px-4 py-1.5 sm:py-2 text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm shadow-emerald-950"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">{t.newServerBtn}</span>
              <span className="sm:hidden">{lang === 'ar' ? 'سيرفر' : 'New'}</span>
            </button>

            {/* Authentication & Rank Switcher */}
            {(!currentUser && !userProfile) ? (
              <button
                disabled={authLoading}
                onClick={onOpenLoginModal}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-lg transition-all shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">
                  {lang === 'ar' ? 'تسجيل الدخول' : 'Sign In'}
                </span>
                <span className="sm:hidden">{lang === 'ar' ? 'دخول' : 'Login'}</span>
              </button>
            ) : (
              <div className="relative" ref={menuRef}>
                <button
                  onClick={() => setIsUserMenuOpen((prev) => !prev)}
                  className="flex items-center gap-2 p-1 pe-2 rounded-lg bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-colors"
                >
                  {(userProfile?.photoURL || currentUser?.photoURL) ? (
                    <img
                      src={userProfile?.photoURL || currentUser?.photoURL || ''}
                      alt={userProfile?.displayName || currentUser?.displayName || 'User'}
                      className="w-7 h-7 rounded-full object-cover border border-neutral-700"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center">
                      {((userProfile?.displayName || currentUser?.displayName || userProfile?.email || currentUser?.email || 'U')[0]).toUpperCase()}
                    </div>
                  )}

                  <div className="hidden sm:flex flex-col items-start leading-none">
                    <span className="text-xs font-semibold text-white max-w-[100px] truncate">
                      {userProfile?.displayName || currentUser?.displayName || (userProfile?.email || currentUser?.email || '').split('@')[0]}
                    </span>
                    <span className="text-[10px] text-neutral-400">
                      {isSuperAdmin ? (
                        <span className="text-amber-400 font-semibold flex items-center gap-0.5">
                          <Crown className="w-2.5 h-2.5" /> مدير أعلى
                        </span>
                      ) : userProfile?.role === 'moderator' ? (
                        <span className="text-sky-400 font-semibold flex items-center gap-0.5">
                          <Shield className="w-2.5 h-2.5" /> ضابط شات
                        </span>
                      ) : isAdmin ? (
                        <span className="text-emerald-400 font-medium flex items-center gap-0.5">
                          <ShieldCheck className="w-2.5 h-2.5" /> مشرف
                        </span>
                      ) : (
                        'عضو'
                      )}
                    </span>
                  </div>

                  <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
                </button>

                {/* Dropdown Menu */}
                {isUserMenuOpen && (
                  <div className="absolute end-0 mt-2 w-64 bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-4 py-2 border-b border-neutral-800/80">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-white truncate">
                          {userProfile?.displayName || currentUser?.displayName || 'User'}
                        </span>
                        {isSuperAdmin ? (
                          <span className="text-[10px] font-bold text-amber-300 bg-amber-500/20 border border-amber-500/30 px-1.5 py-0.5 rounded">
                            SUPER ADMIN
                          </span>
                        ) : userProfile?.role === 'moderator' ? (
                          <span className="text-[10px] font-bold text-sky-300 bg-sky-500/20 border border-sky-500/30 px-1.5 py-0.5 rounded">
                            ضابط شات
                          </span>
                        ) : isAdmin ? (
                          <span className="text-[10px] font-bold text-emerald-300 bg-emerald-500/20 border border-emerald-500/30 px-1.5 py-0.5 rounded">
                            ADMIN
                          </span>
                        ) : (
                          <span className="text-[10px] text-neutral-400 bg-neutral-800 px-1.5 py-0.5 rounded">
                            MEMBER
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-neutral-400 truncate mt-0.5 font-mono">
                        {maskEmail(userProfile?.email || currentUser?.email)}
                      </p>
                    </div>

                    {/* Account Settings Option */}
                    <div className="p-1 border-b border-neutral-800/80">
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          setIsAccountModalOpen(true);
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/10 rounded-lg transition-colors text-start"
                      >
                        <User className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{lang === 'ar' ? 'إعدادات الحساب وتغيير الصورة والاسم' : 'Account & Profile Settings'}</span>
                      </button>
                    </div>

                    {isAdmin && (
                      <div className="p-1 border-b border-neutral-800/80">
                        <button
                          onClick={() => {
                            setIsUserMenuOpen(false);
                            onOpenAdminPanel();
                          }}
                          className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-amber-300 hover:bg-amber-500/10 rounded-lg transition-colors text-start"
                        >
                          <Crown className="w-4 h-4 text-amber-400 shrink-0" />
                          <span>{lang === 'ar' ? 'لوحة تحكم المشرفين والمدراء' : 'Admin & Roles Control'}</span>
                        </button>
                      </div>
                    )}

                    <div className="p-1">
                      <button
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          logout();
                        }}
                        className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors text-start"
                      >
                        <LogOut className="w-4 h-4 shrink-0" />
                        <span>{lang === 'ar' ? 'تسجيل الخروج' : 'Sign Out'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

        </div>
      </div>
    </header>
  );
};
