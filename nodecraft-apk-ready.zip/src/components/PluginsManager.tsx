import React, { useState } from 'react';
import { Package, Plus, ToggleLeft, ToggleRight, Trash2, Download, Search, Check, Sparkles, ExternalLink } from 'lucide-react';
import { LocalServer, ServerPlugin } from '../types/server';
import { Language, I18N } from '../utils/i18n';
import { ensureFullServerFiles } from '../utils/fileHelpers';

interface PluginsManagerProps {
  server: LocalServer;
  onUpdateServer: (updated: LocalServer) => void;
  lang: Language;
}

const POPULAR_CATALOG: Omit<ServerPlugin, 'id' | 'enabled'>[] = [
  {
    name: 'WorldEdit',
    fileName: 'WorldEdit-7.3.0.jar',
    version: '7.3.0',
    author: 'EngineHub',
    description: 'أقوى أداة لتشكيل وبناء العوالم بالفرشاة وتعديل الكتل في ثوانٍ.',
    category: 'world',
    fileSizeMB: 4.8,
  },
  {
    name: 'EssentialsX',
    fileName: 'EssentialsX-2.20.1.jar',
    version: '2.20.1',
    author: 'EssentialsX Team',
    description: 'حزمة أوامر سرفايفل الشاملة: /home و /sethome و /tpa و /spawn والاقتصاد.',
    category: 'admin',
    fileSizeMB: 3.2,
  },
  {
    name: 'Geyser-Spigot',
    fileName: 'Geyser-Spigot-2.4.0.jar',
    version: '2.4.0',
    author: 'GeyserMC',
    description: 'جسر لعب مشترك بين الجافا والبيدروك يتيح لأصدقائك بالهاتف والكونسول الدخول للسيرفر.',
    category: 'utility',
    fileSizeMB: 18.5,
  },
  {
    name: 'LuckPerms',
    fileName: 'LuckPerms-5.4.102.jar',
    version: '5.4.102',
    author: 'Luck',
    description: 'نظام إدارة الرتب والصلاحيات الأكثر كفاءة وسرعة لسيرفرات ماين كرافت.',
    category: 'protection',
    fileSizeMB: 2.1,
  },
  {
    name: 'Vault',
    fileName: 'Vault-1.7.3.jar',
    version: '1.7.3',
    author: 'MilkBowl',
    description: 'المكتبة القياسية للربط بين إضافات الاقتصاد والرتب والشات.',
    category: 'economy',
    fileSizeMB: 0.4,
  },
  {
    name: 'ClearLag',
    fileName: 'Clearlag-3.2.2.jar',
    version: '3.2.2',
    author: 'bob7l',
    description: 'تنظيف المخلفات والأدوات المرمية لتقليل استهلاك الرام ورفع الـ TPS.',
    category: 'utility',
    fileSizeMB: 0.6,
  },
  {
    name: 'Multiverse-Core',
    fileName: 'Multiverse-Core-4.3.1.jar',
    version: '4.3.1',
    author: 'Multiverse Team',
    description: 'إنشاء وإدارة عوالم متعددة (عالم بناء، عالم سرفايفل، عالم الموارد) بسيرفر واحد.',
    category: 'world',
    fileSizeMB: 1.8,
  },
  {
    name: 'Chunky',
    fileName: 'Chunky-1.3.92.jar',
    version: '1.3.92',
    author: 'pop4959',
    description: 'توليد مسبق للـ Chunks لتقليل التقطيع تماماً عند استكشاف اللاعبين لخريطة جديدة.',
    category: 'utility',
    fileSizeMB: 0.9,
  },
];

export const PluginsManager: React.FC<PluginsManagerProps> = ({
  server,
  onUpdateServer,
  lang,
}) => {
  const t = I18N[lang];
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customDesc, setCustomDesc] = useState('');
  const [customVersion, setCustomVersion] = useState('1.0.0');

  const installedPlugins = server.plugins || [];

  const handleTogglePlugin = (pluginId: string) => {
    const time = new Date().toLocaleTimeString('en-GB');
    const target = installedPlugins.find((p) => p.id === pluginId);
    if (!target) return;

    const nextState = !target.enabled;
    const updatedPlugins = installedPlugins.map((p) =>
      p.id === pluginId ? { ...p, enabled: nextState } : p
    );

    const actionText = nextState ? 'Enabled' : 'Disabled';
    const logMessage = `[Plugins] ${actionText} plugin ${target.name} v${target.version} (${target.fileName})`;

    const updated: LocalServer = {
      ...server,
      plugins: updatedPlugins,
      logs: [
        ...server.logs,
        {
          id: `pl-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: logMessage,
        },
      ],
    };
    updated.files = ensureFullServerFiles(updated);
    onUpdateServer(updated);
  };

  const handleUninstallPlugin = (pluginId: string) => {
    const time = new Date().toLocaleTimeString('en-GB');
    const target = installedPlugins.find((p) => p.id === pluginId);
    if (!target) return;

    const updatedPlugins = installedPlugins.filter((p) => p.id !== pluginId);
    // Also remove the plugin jar and its folder from virtual files
    const remainingFiles = (server.files || []).filter(
      (f) =>
        f.path !== `/plugins/${target.fileName}` &&
        !f.path.startsWith(`/plugins/${target.name}/`)
    );

    const updated: LocalServer = {
      ...server,
      plugins: updatedPlugins,
      files: remainingFiles,
      logs: [
        ...server.logs,
        {
          id: `pl-log-${Date.now()}`,
          timestamp: time,
          level: 'WARN',
          message: `[Plugins] Uninstalled ${target.name} (${target.fileName}).`,
        },
      ],
    };
    updated.files = ensureFullServerFiles(updated);
    onUpdateServer(updated);
  };

  const handleInstallFromCatalog = (item: (typeof POPULAR_CATALOG)[0]) => {
    const time = new Date().toLocaleTimeString('en-GB');
    const newPlugin: ServerPlugin = {
      ...item,
      id: `pl-${Date.now()}`,
      enabled: true,
    };

    const updated: LocalServer = {
      ...server,
      plugins: [...installedPlugins, newPlugin],
      logs: [
        ...server.logs,
        {
          id: `pl-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: `[Plugins] Downloaded and installed ${item.name} v${item.version} into /plugins/${item.fileName}`,
        },
      ],
    };
    updated.files = ensureFullServerFiles(updated);
    onUpdateServer(updated);
  };

  const handleAddCustomPlugin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;

    const time = new Date().toLocaleTimeString('en-GB');
    const sanitizedFileName = `${customName.trim().replace(/\s+/g, '')}-${customVersion}.jar`;

    const newPlugin: ServerPlugin = {
      id: `pl-custom-${Date.now()}`,
      name: customName.trim(),
      fileName: sanitizedFileName,
      version: customVersion,
      author: 'Custom / Local',
      enabled: true,
      description: customDesc.trim() || 'إضافة مخصصة تم إدراجها محلياً.',
      category: 'utility',
      fileSizeMB: 1.2,
    };

    const updated: LocalServer = {
      ...server,
      plugins: [...installedPlugins, newPlugin],
      logs: [
        ...server.logs,
        {
          id: `pl-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: `[Plugins] Added custom plugin: ${newPlugin.fileName}`,
        },
      ],
    };
    updated.files = ensureFullServerFiles(updated);
    onUpdateServer(updated);

    setCustomName('');
    setCustomDesc('');
    setShowAddModal(false);
  };

  const filteredCatalog = POPULAR_CATALOG.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Package className="w-5 h-5 text-emerald-400" />
            <span>{t.plugins}</span>
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">{t.pluginsDesc}</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold text-xs transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'ar' ? 'إضافة بلوجن مخصص (.jar)' : 'Add Custom Plugin'}</span>
          </button>
        </div>
      </div>

      {/* Installed Plugins Section */}
      <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden">
        <div className="p-3.5 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-white">
              {lang === 'ar' ? 'البلوجنات المثبتة حالياً في مجلد /plugins/' : 'Installed Plugins in /plugins/'}
            </span>
            <span className="text-xs font-mono text-emerald-400">
              ({installedPlugins.length})
            </span>
          </div>
          <span className="text-xs font-mono text-neutral-400">
            {installedPlugins.filter((p) => p.enabled).length} {lang === 'ar' ? 'مفعل' : 'Active'}
          </span>
        </div>

        {installedPlugins.length === 0 ? (
          <div className="py-10 text-center text-neutral-500 italic text-xs">
            {lang === 'ar'
              ? 'لا توجد إضافات مثبتة حتى الآن. يمكنك اختيار إضافات من القائمة بالأسفل للتثبيت بنقرة واحدة.'
              : 'No plugins installed yet. Pick from the catalog below to install in 1-click.'}
          </div>
        ) : (
          <div className="divide-y divide-neutral-800/80">
            {installedPlugins.map((pl) => (
              <div
                key={pl.id}
                className="p-3.5 hover:bg-neutral-900/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 font-mono text-xs font-bold ${
                      pl.enabled
                        ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/50'
                        : 'bg-neutral-900 text-neutral-500 border border-neutral-800'
                    }`}
                  >
                    JAR
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-white text-sm">{pl.name}</span>
                      <span className="font-mono text-neutral-400 text-[11px]">v{pl.version}</span>
                      <span className="text-neutral-500 text-[11px]">بواسطة {pl.author}</span>
                      <span className="text-emerald-400/80 font-mono text-[11px]">{pl.fileSizeMB} MB</span>
                    </div>
                    <p className="text-neutral-400 text-xs mt-0.5 line-clamp-1">{pl.description}</p>
                    <div className="text-[11px] font-mono text-neutral-500 mt-1">
                      /plugins/{pl.fileName}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 justify-end shrink-0">
                  <button
                    onClick={() => handleTogglePlugin(pl.id)}
                    className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                      pl.enabled
                        ? 'bg-emerald-950/40 text-emerald-300 border border-emerald-800/60 hover:bg-emerald-900/40'
                        : 'bg-neutral-900 text-neutral-400 border border-neutral-800 hover:text-white'
                    }`}
                  >
                    {pl.enabled ? (
                      <>
                        <ToggleRight className="w-4 h-4 text-emerald-400" />
                        <span>{lang === 'ar' ? 'مفعل' : 'Enabled'}</span>
                      </>
                    ) : (
                      <>
                        <ToggleLeft className="w-4 h-4 text-neutral-500" />
                        <span>{lang === 'ar' ? 'معطل' : 'Disabled'}</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => handleUninstallPlugin(pl.id)}
                    title={lang === 'ar' ? 'إلغاء التثبيت وحذف الملف' : 'Uninstall'}
                    className="p-1.5 text-neutral-500 hover:text-red-400 rounded hover:bg-neutral-800 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Catalog of Popular Plugins (1-click install) */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <h4 className="text-sm font-bold text-white">
              {lang === 'ar' ? 'متجر البلوجنات الشائعة (تثبيت فوري بنقرة واحدة)' : 'Popular Plugins Catalog (1-Click Install)'}
            </h4>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute start-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={lang === 'ar' ? 'بحث في البلوجنات...' : 'Search plugins...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg py-1.5 ps-8 pe-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredCatalog.map((cat) => {
            const isInstalled = installedPlugins.some(
              (p) => p.name.toLowerCase() === cat.name.toLowerCase()
            );

            return (
              <div
                key={cat.name}
                className="bg-neutral-950 border border-neutral-800/80 rounded-lg p-3.5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-white text-sm">{cat.name}</span>
                    <span className="text-[11px] font-mono text-neutral-500">{cat.fileSizeMB} MB</span>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed line-clamp-2 mb-3">
                    {cat.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-neutral-800/60 text-xs">
                  <span className="text-[11px] font-mono text-neutral-500">v{cat.version} · {cat.author}</span>

                  {isInstalled ? (
                    <span className="flex items-center gap-1 text-emerald-400 font-semibold font-mono text-xs">
                      <Check className="w-3.5 h-3.5" />
                      <span>{lang === 'ar' ? 'مثبت' : 'Installed'}</span>
                    </span>
                  ) : (
                    <button
                      onClick={() => handleInstallFromCatalog(cat)}
                      className="flex items-center gap-1 px-3 py-1 rounded bg-neutral-800 hover:bg-emerald-500 hover:text-neutral-950 text-white font-medium transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{lang === 'ar' ? 'تثبيت' : 'Install'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Custom Plugin Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <h4 className="text-base font-bold text-white">
              {lang === 'ar' ? 'إضافة بلوجن مخصص إلى السيرفر' : 'Add Custom Plugin (.jar)'}
            </h4>

            <form onSubmit={handleAddCustomPlugin} className="space-y-3">
              <div>
                <label className="text-xs text-neutral-400 block mb-1">اسم البلوجن:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: CustomEconomy"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400 block mb-1">الإصدار (Version):</label>
                <input
                  type="text"
                  value={customVersion}
                  onChange={(e) => setCustomVersion(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400 block mb-1">الوصف:</label>
                <input
                  type="text"
                  placeholder="وصف مختصر لمهمة البلوجن..."
                  value={customDesc}
                  onChange={(e) => setCustomDesc(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="flex gap-2 justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-emerald-400 text-neutral-950 font-bold text-xs"
                >
                  {lang === 'ar' ? 'إضافة وتثبيت' : 'Install Plugin'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
