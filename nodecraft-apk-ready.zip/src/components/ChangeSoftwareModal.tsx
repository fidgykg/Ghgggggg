import React, { useState } from 'react';
import {
  X,
  Download,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  HardDrive,
  Cpu,
  Layers,
  ArrowRight,
  ShieldCheck,
} from 'lucide-react';
import { LocalServer } from '../types/server';
import { Language } from '../utils/i18n';
import {
  SoftwareVersionInfo,
  getSoftwareMeta,
  MINECRAFT_SOFTWARES,
} from '../data/softwareVersions';
import { SoftwareVersionSelector } from './SoftwareVersionSelector';

interface ChangeSoftwareModalProps {
  isOpen: boolean;
  onClose: () => void;
  server: LocalServer;
  onUpdateServer: (updated: LocalServer) => void;
  lang: Language;
}

export const ChangeSoftwareModal: React.FC<ChangeSoftwareModalProps> = ({
  isOpen,
  onClose,
  server,
  onUpdateServer,
  lang,
}) => {
  const isAr = lang === 'ar';

  const initialSoftware =
    server.minecraftConfig?.serverSoftware ||
    (server.type === 'minecraft' ? 'PaperMC' : server.type === 'web' ? 'Static HTML' : 'redis');

  const initialVersion =
    server.minecraftConfig?.version ||
    (server.type === 'minecraft' ? '1.21.4' : server.type === 'web' ? 'v22.14.0' : '7.4.2');

  const [selectedSoftware, setSelectedSoftware] = useState<string>(initialSoftware);
  const [selectedVersion, setSelectedVersion] = useState<string>(initialVersion);
  const [versionInfo, setVersionInfo] = useState<SoftwareVersionInfo | null>(null);

  // Download & Installation simulated states
  const [isInstalling, setIsInstalling] = useState(false);
  const [installProgress, setInstallProgress] = useState(0);
  const [installStageText, setInstallStageText] = useState('');
  const [isCompleted, setIsCompleted] = useState(false);

  if (!isOpen) return null;

  const currentSoftwareMeta = getSoftwareMeta(server.type, selectedSoftware);
  const activeVer =
    versionInfo ||
    currentSoftwareMeta?.versions.find((v) => v.version === selectedVersion) ||
    currentSoftwareMeta?.versions[0];

  const handleStartInstallation = () => {
    if (!activeVer) return;

    setIsInstalling(true);
    setInstallProgress(10);
    setInstallStageText(
      isAr
        ? `جاري الاتصال بمستودع التنزيل الرسمي لـ ${selectedSoftware}...`
        : `Connecting to official repository for ${selectedSoftware}...`
    );

    setTimeout(() => {
      setInstallProgress(40);
      setInstallStageText(
        isAr
          ? `جاري تنزيل ${activeVer.fileName} (${activeVer.fileSizeMB} MB)...`
          : `Downloading ${activeVer.fileName} (${activeVer.fileSizeMB} MB)...`
      );
    }, 700);

    setTimeout(() => {
      setInstallProgress(75);
      setInstallStageText(
        isAr
          ? `التحقق من سلامة البصمة الرقمية والتوافقية (SHA-256)...`
          : `Verifying binary checksum (SHA-256)...`
      );
    }, 1500);

    setTimeout(() => {
      setInstallProgress(95);
      setInstallStageText(
        isAr
          ? `تجهيز ملفات التشغيل وتحديث server.properties إلى ${selectedVersion}...`
          : `Updating server configuration files to ${selectedVersion}...`
      );
    }, 2200);

    setTimeout(() => {
      setInstallProgress(100);
      setIsInstalling(false);
      setIsCompleted(true);

      const time = new Date().toLocaleTimeString('en-GB');

      // Update server state
      const updatedFiles = [...(server.files || [])];

      // Add or replace main server jar
      const jarPath = `/${activeVer.fileName}`;
      const existingJarIndex = updatedFiles.findIndex(
        (f) => f.name.endsWith('.jar') || f.name.endsWith('.zip')
      );

      const newJarFile = {
        path: jarPath,
        name: activeVer.fileName,
        isDirectory: false,
        sizeBytes: Math.round(activeVer.fileSizeMB * 1024 * 1024),
        lastModified: new Date().toISOString().slice(0, 10),
        content: `[Binary server payload: ${selectedSoftware} ${selectedVersion} build]`,
      };

      if (existingJarIndex >= 0) {
        updatedFiles[existingJarIndex] = newJarFile;
      } else {
        updatedFiles.unshift(newJarFile);
      }

      const updated: LocalServer = {
        ...server,
        minecraftConfig: server.minecraftConfig
          ? {
              ...server.minecraftConfig,
              serverSoftware: selectedSoftware as any,
              version: selectedVersion,
              motd: server.minecraftConfig.motd.includes('[')
                ? server.minecraftConfig.motd.replace(/\[.*?\]/, `[${selectedVersion}]`)
                : `${server.minecraftConfig.motd} §e[${selectedVersion}]`,
            }
          : undefined,
        files: updatedFiles,
        logs: [
          ...server.logs,
          {
            id: `sys-sw-${Date.now()}`,
            timestamp: time,
            level: 'INFO',
            message: `[System] Server software changed to ${selectedSoftware} ${selectedVersion} (${activeVer.fileName} downloaded & installed).`,
          },
        ],
      };

      // If switched to Fabric and no mods exist, create standard Fabric API
      if (selectedSoftware === 'Fabric' && (!server.mods || server.mods.length === 0)) {
        updated.mods = [
          {
            id: `mod-${Date.now()}-1`,
            name: 'Fabric API',
            fileName: `fabric-api-${selectedVersion}.jar`,
            version: '0.100.1',
            author: 'FabricMC',
            enabled: true,
            description: 'المكتبة الأساسية لمودات فابريك.',
            side: 'both',
            fileSizeMB: 2.4,
          },
        ];
      }

      onUpdateServer(updated);
    }, 2800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-emerald-400" />
              <span>
                {isAr ? 'تغيير وتنزيل نظام السيرفر والإصدار' : 'Change & Download Server Software Version'}
              </span>
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              {isAr
                ? `السيرفر الحالي: ${server.name} · النظام الحالي: ${server.minecraftConfig?.serverSoftware || 'PaperMC'} ${server.minecraftConfig?.version || '1.21.1'}`
                : `Current Server: ${server.name} (${server.minecraftConfig?.serverSoftware || 'PaperMC'} ${server.minecraftConfig?.version || '1.21.1'})`}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {isCompleted ? (
            <div className="py-8 text-center space-y-4">
              <div className="w-14 h-14 bg-emerald-950/60 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto text-emerald-400">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-white">
                  {isAr ? 'تم تنزيل وتثبيت النظام بنجاح!' : 'Software & Version Installed Successfully!'}
                </h4>
                <p className="text-xs text-neutral-300 mt-1 max-w-md mx-auto">
                  {isAr
                    ? `أصبح السيرفر الآن يعمل بنظام ${selectedSoftware} برقم الإصدار ${selectedVersion}. تم إعداد ملف التشغيل ${activeVer?.fileName} تلقائياً.`
                    : `Server is now configured with ${selectedSoftware} ${selectedVersion}. Startup binary ${activeVer?.fileName} is ready.`}
                </p>
              </div>

              <div className="flex justify-center pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold text-xs transition-colors"
                >
                  {isAr ? 'تم، العودة إلى لوحة التحكم' : 'Done, Return to Dashboard'}
                </button>
              </div>
            </div>
          ) : isInstalling ? (
            <div className="py-12 space-y-5 text-center">
              <div className="flex justify-center">
                <RefreshCw className="w-8 h-8 text-emerald-400 animate-spin" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">
                  {isAr ? 'جاري تنزيل وتثبيت النظام الجديد...' : 'Downloading & Installing Software...'}
                </h4>
                <p className="text-xs text-neutral-400 mt-1 font-mono">{installStageText}</p>
              </div>

              {/* Progress Bar */}
              <div className="w-full max-w-md mx-auto bg-neutral-950 border border-neutral-800 rounded-full h-3 overflow-hidden p-0.5">
                <div
                  className="bg-emerald-400 h-full rounded-full transition-all duration-300"
                  style={{ width: `${installProgress}%` }}
                />
              </div>
              <span className="text-xs font-mono text-emerald-400">{installProgress}%</span>
            </div>
          ) : (
            <>
              {/* Notice */}
              <div className="bg-amber-950/20 border border-amber-800/40 rounded-lg p-3 text-xs text-amber-300/90 flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>
                  {isAr
                    ? 'تغيير النظام سيقوم بتنزيل ملف الـ JAR المناسب للإصدار المختار وربطه بملف server.properties مع الحفاظ على عوالمك وبياناتك المحفوظة.'
                    : 'Changing the server software will download the appropriate binary and adjust configuration while preserving your world data.'}
                </span>
              </div>

              {/* Interactive Software & Version Selector */}
              <SoftwareVersionSelector
                category={server.type === 'minecraft' ? 'minecraft' : server.type === 'web' ? 'web' : 'database'}
                selectedSoftware={selectedSoftware}
                onSoftwareChange={(sw) => setSelectedSoftware(sw)}
                selectedVersion={selectedVersion}
                onVersionChange={(ver, info) => {
                  setSelectedVersion(ver);
                  setVersionInfo(info);
                }}
                lang={lang}
              />
            </>
          )}
        </div>

        {/* Footer */}
        {!isInstalling && !isCompleted && (
          <div className="px-6 py-4 border-t border-neutral-800 flex items-center justify-between bg-neutral-950/40">
            <div className="text-xs font-mono text-neutral-400">
              {isAr ? 'الإصدار المختار:' : 'Target:'}{' '}
              <span className="text-emerald-400 font-bold">
                {selectedSoftware} {selectedVersion}
              </span>{' '}
              ({activeVer?.fileSizeMB} MB)
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg text-xs font-medium text-neutral-400 hover:text-white transition-colors"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleStartInstallation}
                className="flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-bold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 transition-colors shadow-sm"
              >
                <Download className="w-3.5 h-3.5" />
                <span>
                  {isAr
                    ? `تنزيل وتثبيت إصدار ${selectedVersion}`
                    : `Download & Install ${selectedVersion}`}
                </span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
