import React, { useState, useRef, useEffect } from 'react';
import {
  Folder,
  FileText,
  FileCode,
  Package,
  Plus,
  Save,
  Trash2,
  Download,
  Upload,
  X,
  Check,
  Search,
  ExternalLink,
  Code2,
  FolderOpen,
  ArrowRight,
  Sparkles,
  Layers,
  ChevronRight,
  Globe,
  Compass,
  Archive,
  Loader2,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { LocalServer, VirtualFile, ServerPlugin, FabricMod } from '../types/server';
import { Language, I18N } from '../utils/i18n';
import { READY_SETUPS, ReadySetup, ensureFullServerFiles } from '../utils/fileHelpers';
import {
  inspectZipArchive,
  extractZipArchive,
  ZipFileInfo,
  ExtractedZipResult,
} from '../utils/zipHelpers';

interface FileManagerProps {
  server: LocalServer;
  onUpdateServer: (updated: LocalServer) => void;
  lang: Language;
}

export const FileManager: React.FC<FileManagerProps> = ({
  server,
  onUpdateServer,
  lang,
}) => {
  const t = I18N[lang];
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFile, setActiveFile] = useState<VirtualFile | null>(null);
  const [fileContentDraft, setFileContentDraft] = useState('');
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [showSetupsModal, setShowSetupsModal] = useState(false);
  const [newFilePath, setNewFilePath] = useState('');
  const [newFileContent, setNewFileContent] = useState('');
  const [selectedFolderFilter, setSelectedFolderFilter] = useState<string>('ALL'); // 'ALL', '/world', '/plugins', '/mods', '/config', '/logs'
  const [fileToDelete, setFileToDelete] = useState<string | null>(null);
  
  // ZIP Setup Upload & Extraction States
  const fileUploadInputRef = useRef<HTMLInputElement>(null);
  const zipUploadInputRef = useRef<HTMLInputElement>(null);
  const [isExtractingZip, setIsExtractingZip] = useState(false);
  const [extractError, setExtractError] = useState<string | null>(null);
  const [pendingZipExtract, setPendingZipExtract] = useState<{
    source: File | string;
    name: string;
    sizeBytes: number;
    targetFolder: string;
    previewFiles: ZipFileInfo[];
  } | null>(null);
  const [zipExtractSuccess, setZipExtractSuccess] = useState<ExtractedZipResult | null>(null);
  const [activeZipPreview, setActiveZipPreview] = useState<ZipFileInfo[]>([]);
  const [isLoadingZipPreview, setIsLoadingZipPreview] = useState(false);

  // Guarantee files are always populated with world files & plugins
  const files = ensureFullServerFiles(server);

  // Load preview of inner files when viewing a .zip file
  useEffect(() => {
    if (activeFile && activeFile.name.toLowerCase().endsWith('.zip') && activeFile.content) {
      setIsLoadingZipPreview(true);
      inspectZipArchive(activeFile.content)
        .then((entries) => {
          setActiveZipPreview(entries);
        })
        .catch((err) => {
          console.error('Failed to preview zip contents:', err);
          setActiveZipPreview([]);
        })
        .finally(() => {
          setIsLoadingZipPreview(false);
        });
    } else {
      setActiveZipPreview([]);
    }
  }, [activeFile?.path, activeFile?.content]);

  const handleOpenFile = (file: VirtualFile) => {
    setActiveFile(file);
    setFileContentDraft(file.content || '');
    setSaveSuccess(false);
  };

  const handleCloseEditor = () => {
    setActiveFile(null);
    setFileContentDraft('');
    setSaveSuccess(false);
  };

  const handleSaveFile = () => {
    if (!activeFile) return;

    const time = new Date().toLocaleTimeString('en-GB');
    const updatedFiles = files.map((f) => {
      if (f.path === activeFile.path) {
        return {
          ...f,
          content: fileContentDraft,
          sizeBytes: new Blob([fileContentDraft]).size,
          lastModified: new Date().toISOString().replace('T', ' ').slice(0, 16),
        };
      }
      return f;
    });

    onUpdateServer({
      ...server,
      files: updatedFiles,
      logs: [
        ...server.logs,
        {
          id: `file-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: `[File System] Saved changes to file "${activeFile.path}" (${new Blob([fileContentDraft]).size} bytes).`,
        },
      ],
    });

    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleDeleteFile = (path: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFileToDelete(path);
  };

  const handleConfirmDelete = () => {
    if (!fileToDelete) return;
    const path = fileToDelete;
    const time = new Date().toLocaleTimeString('en-GB');
    const updatedFiles = files.filter((f) => f.path !== path);

    onUpdateServer({
      ...server,
      files: updatedFiles,
      logs: [
        ...server.logs,
        {
          id: `file-log-${Date.now()}`,
          timestamp: time,
          level: 'WARN',
          message: `[File System] Deleted file: ${path}`,
        },
      ],
    });

    if (activeFile?.path === path) {
      handleCloseEditor();
    }
    setFileToDelete(null);
  };

  // Execute extraction of ZIP archive into server state
  const handleExecuteZipExtraction = async (
    zipSource: File | string,
    targetFolder: string,
    zipName: string
  ) => {
    setIsExtractingZip(true);
    setExtractError(null);

    try {
      const result = await extractZipArchive(zipSource, targetFolder);

      // Merge extracted files with existing virtual files
      const currentFiles = [...files];
      const newPathsSet = new Set(result.extractedFiles.map((f) => f.path));
      const remainingFiles = currentFiles.filter((f) => !newPathsSet.has(f.path));
      const mergedFiles = [...remainingFiles, ...result.extractedFiles];

      // Merge detected plugins
      const existingPluginFiles = new Set((server.plugins || []).map((p) => p.fileName));
      const newPluginsToAdd = result.detectedPlugins.filter((p) => !existingPluginFiles.has(p.fileName));
      const mergedPlugins = [...(server.plugins || []), ...newPluginsToAdd];

      // Merge detected mods
      const existingModFiles = new Set((server.mods || []).map((m) => m.fileName));
      const newModsToAdd = result.detectedMods.filter((m) => !existingModFiles.has(m.fileName));
      const mergedMods = [...(server.mods || []), ...newModsToAdd];

      const time = new Date().toLocaleTimeString('en-GB');

      const updatedServer: LocalServer = {
        ...server,
        files: mergedFiles,
        plugins: mergedPlugins,
        mods: mergedMods,
        logs: [
          ...server.logs,
          {
            id: `zip-log-${Date.now()}`,
            timestamp: time,
            level: 'INFO',
            message: `[ZIP Extractor] Successfully unzipped "${zipName}" into "${targetFolder || '/'}" (${result.extractedFiles.length} files extracted, ${result.detectedPlugins.length} plugins, ${result.detectedMods.length} mods).`,
          },
        ],
      };

      // Sync Minecraft properties if present
      if (result.serverProperties && updatedServer.type === 'minecraft') {
        if (result.serverProperties['level-seed'] && updatedServer.minecraftConfig) {
          updatedServer.minecraftConfig = {
            ...updatedServer.minecraftConfig,
            seed: result.serverProperties['level-seed'],
          };
        }
        if (result.serverProperties['server-port']) {
          const portNum = parseInt(result.serverProperties['server-port'], 10);
          if (!isNaN(portNum)) {
            updatedServer.port = portNum;
          }
        }
      }

      updatedServer.files = ensureFullServerFiles(updatedServer);
      onUpdateServer(updatedServer);
      setZipExtractSuccess(result);
      setPendingZipExtract(null);

      // Refresh active file if currently viewing an extracted file
      if (activeFile) {
        const matchingFile = updatedServer.files.find((f) => f.path === activeFile.path);
        if (matchingFile) {
          setActiveFile(matchingFile);
          setFileContentDraft(matchingFile.content || '');
        }
      }
    } catch (err: any) {
      console.error('ZIP extraction error:', err);
      setExtractError(err?.message || (lang === 'ar' ? 'فشل فك ضغط الأرشيف.' : 'Failed to extract zip archive.'));
    } finally {
      setIsExtractingZip(false);
    }
  };

  // Trigger unzip for a .zip file already stored in server virtual files
  const handleTriggerUnzipExisting = async (file: VirtualFile) => {
    if (!file.content) return;
    try {
      setIsExtractingZip(true);
      const preview = await inspectZipArchive(file.content);
      let suggestedFolder = selectedFolderFilter !== 'ALL' ? selectedFolderFilter : '';
      if (preview.some((p) => p.path.includes('/world/'))) {
        suggestedFolder = '';
      } else if (preview.every((p) => p.name.endsWith('.jar'))) {
        suggestedFolder = '/plugins';
      }

      setPendingZipExtract({
        source: file.content,
        name: file.name,
        sizeBytes: file.sizeBytes,
        targetFolder: suggestedFolder,
        previewFiles: preview,
      });
    } catch (err) {
      alert(lang === 'ar' ? 'تعذر قراءة محتويات الأرشيف.' : 'Could not read archive.');
    } finally {
      setIsExtractingZip(false);
    }
  };

  // Handle file selected from dedicated ZIP upload input
  const handleZipUploadChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsExtractingZip(true);
      const preview = await inspectZipArchive(file);
      let suggested = '';
      if (preview.some((p) => p.path.includes('/world/'))) {
        suggested = '';
      } else if (preview.every((p) => p.name.endsWith('.jar'))) {
        suggested = '/plugins';
      }

      setPendingZipExtract({
        source: file,
        name: file.name,
        sizeBytes: file.size,
        targetFolder: suggested,
        previewFiles: preview,
      });
    } catch (err: any) {
      alert(lang === 'ar' ? 'الملف المضغوط تالف أو غير صالح.' : 'Corrupt or invalid zip archive.');
    } finally {
      setIsExtractingZip(false);
      if (zipUploadInputRef.current) {
        zipUploadInputRef.current.value = '';
      }
    }
  };

  const handleDownloadFile = (file: VirtualFile, e: React.MouseEvent) => {
    e.stopPropagation();
    const blob = new Blob([file.content || ''], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Upload local file from user's computer
  const handleUploadFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isZip = file.name.toLowerCase().endsWith('.zip');

    const reader = new FileReader();
    reader.onload = () => {
      const content = typeof reader.result === 'string' ? reader.result : '[Binary file uploaded]';
      const folderPrefix = selectedFolderFilter !== 'ALL' ? selectedFolderFilter : '';
      const targetPath = `${folderPrefix}/${file.name}`.replace(/\/+/g, '/');

      const newFile: VirtualFile = {
        path: targetPath,
        name: file.name,
        isDirectory: false,
        sizeBytes: file.size,
        lastModified: new Date().toISOString().replace('T', ' ').slice(0, 16),
        content: content,
      };

      const time = new Date().toLocaleTimeString('en-GB');
      const updatedFiles = [...files.filter((f) => f.path !== targetPath), newFile];

      onUpdateServer({
        ...server,
        files: updatedFiles,
        logs: [
          ...server.logs,
          {
            id: `upload-log-${Date.now()}`,
            timestamp: time,
            level: 'INFO',
            message: `[File System] Uploaded file from device: ${targetPath} (${file.size} bytes).`,
          },
        ],
      });

      handleOpenFile(newFile);

      // If it's a ZIP archive, inspect it and open the unzipping prompt directly
      if (isZip) {
        inspectZipArchive(file)
          .then((preview) => {
            let suggested = selectedFolderFilter !== 'ALL' ? selectedFolderFilter : '';
            if (preview.some((p) => p.path.includes('/world/'))) {
              suggested = '';
            } else if (preview.every((p) => p.name.endsWith('.jar'))) {
              suggested = '/plugins';
            }
            setPendingZipExtract({
              source: file,
              name: file.name,
              sizeBytes: file.size,
              targetFolder: suggested,
              previewFiles: preview,
            });
          })
          .catch((err) => {
            console.warn('Could not inspect zip immediately:', err);
          });
      }
    };

    if (file.name.match(/\.(txt|properties|yml|yaml|json|log|conf|js|html|css|mcfunction|mcmeta|toml|md)$/i)) {
      reader.readAsText(file);
    } else {
      reader.readAsDataURL(file);
    }

    // Reset input
    if (fileUploadInputRef.current) {
      fileUploadInputRef.current.value = '';
    }
  };

  const handleCreateNewFile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFilePath.trim()) return;

    const cleanPath = newFilePath.trim().startsWith('/') ? newFilePath.trim() : `/${newFilePath.trim()}`;
    const name = cleanPath.split('/').pop() || cleanPath;

    const newFile: VirtualFile = {
      path: cleanPath,
      name: name,
      isDirectory: false,
      sizeBytes: new Blob([newFileContent]).size,
      lastModified: new Date().toISOString().replace('T', ' ').slice(0, 16),
      content: newFileContent,
    };

    const time = new Date().toLocaleTimeString('en-GB');

    onUpdateServer({
      ...server,
      files: [...files, newFile],
      logs: [
        ...server.logs,
        {
          id: `file-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: `[File System] Created new file: ${cleanPath}`,
        },
      ],
    });

    setNewFilePath('');
    setNewFileContent('');
    setShowNewFileModal(false);
    handleOpenFile(newFile);
  };

  // 1-Click Apply Ready Setup
  const handleApplySetup = (setup: ReadySetup) => {
    const time = new Date().toLocaleTimeString('en-GB');
    let updatedPlugins = server.plugins || [];
    let updatedMods = server.mods || [];

    if (setup.plugins) {
      const convertedPlugins: ServerPlugin[] = setup.plugins.map((p, idx) => ({
        ...p,
        id: `setup-pl-${Date.now()}-${idx}`,
      }));
      updatedPlugins = convertedPlugins;
    }

    if (setup.mods) {
      const convertedMods: FabricMod[] = setup.mods.map((m, idx) => ({
        ...m,
        id: `setup-mod-${Date.now()}-${idx}`,
      }));
      updatedMods = convertedMods;
    }

    const updatedServer: LocalServer = {
      ...server,
      plugins: updatedPlugins,
      mods: updatedMods,
      allocatedRamMB: Math.max(server.allocatedRamMB, setup.ramMB),
      logs: [
        ...server.logs,
        {
          id: `setup-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: `[Server Setup] Applied ready-made preset: "${setup.name}". Installed ${setup.plugins?.length || setup.mods?.length || 0} packages and world files.`,
        },
      ],
    };

    // Re-generate complete virtual files
    updatedServer.files = ensureFullServerFiles(updatedServer);

    onUpdateServer(updatedServer);
    setShowSetupsModal(false);
  };

  const getFileIcon = (fileName: string) => {
    if (fileName.endsWith('.zip')) {
      return <Archive className="w-4 h-4 text-amber-400" />;
    }
    if (fileName.endsWith('.properties') || fileName.endsWith('.conf')) {
      return <FileCode className="w-4 h-4 text-emerald-400" />;
    }
    if (fileName.endsWith('.json') || fileName.endsWith('.yml') || fileName.endsWith('.yaml')) {
      return <FileCode className="w-4 h-4 text-cyan-400" />;
    }
    if (fileName.endsWith('.log') || fileName.endsWith('.txt')) {
      return <FileText className="w-4 h-4 text-amber-400" />;
    }
    if (fileName.endsWith('.jar')) {
      return <Package className="w-4 h-4 text-purple-400" />;
    }
    if (fileName.endsWith('.dat') || fileName.endsWith('.mca') || fileName.endsWith('.lock')) {
      return <Compass className="w-4 h-4 text-emerald-500" />;
    }
    return <FileText className="w-4 h-4 text-neutral-400" />;
  };

  // Folder filtering
  const filteredFiles = files.filter((f) => {
    const matchesSearch =
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.path.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (selectedFolderFilter === 'ALL') return true;
    return f.path.startsWith(selectedFolderFilter);
  });

  return (
    <div className="space-y-5">
      {/* Top Banner & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 rounded-xl p-5">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-emerald-400" />
            <span>{lang === 'ar' ? 'مدير الملفات ومجلدات السيرفر' : 'Server File Manager'}</span>
          </h3>
          <p className="text-xs text-neutral-400 mt-0.5">
            {lang === 'ar'
              ? 'تصفح وفتح وتعديل ملفات العالم (World)، البلوجنات (Plugins)، المودات (Mods)، ورفع وفك ضغط أرشيفات ZIP.'
              : 'Browse, edit World, Plugins, Mods, and upload & extract ZIP setups.'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Ready Setups Button */}
          <button
            onClick={() => setShowSetupsModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 hover:text-white border border-indigo-800/50 text-xs font-bold transition-colors shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span>{lang === 'ar' ? '📦 ستابات جاهزة' : 'Ready Setups'}</span>
          </button>

          {/* Upload & Extract ZIP Setup Button */}
          <button
            onClick={() => zipUploadInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs transition-colors shadow-sm"
          >
            <Archive className="w-4 h-4" />
            <span>{lang === 'ar' ? 'رفع سيت اب (.zip) وفك الضغط' : 'Upload & Unzip (.zip)'}</span>
          </button>
          <input
            type="file"
            ref={zipUploadInputRef}
            accept=".zip,application/zip"
            onChange={handleZipUploadChange}
            className="hidden"
          />

          {/* Upload File Button */}
          <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold cursor-pointer transition-colors border border-neutral-700">
            <Upload className="w-4 h-4 text-cyan-400" />
            <span>{lang === 'ar' ? 'رفع ملف' : 'Upload File'}</span>
            <input
              type="file"
              ref={fileUploadInputRef}
              onChange={handleUploadFile}
              className="hidden"
            />
          </label>

          {/* New File Button */}
          <button
            onClick={() => setShowNewFileModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold text-xs transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>{t.createFile}</span>
          </button>
        </div>
      </div>

      {/* Folder Category Quick Bar (world, plugins, mods, config, logs) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-neutral-500 text-xs shrink-0">{lang === 'ar' ? 'المجلدات:' : 'Folders:'}</span>
        {[
          { id: 'ALL', label: lang === 'ar' ? 'كل الملفات' : 'All Files', icon: <Folder className="w-3.5 h-3.5" /> },
          { id: '/world', label: lang === 'ar' ? '🌍 ملفات العالم (/world)' : 'World Files', icon: <Compass className="w-3.5 h-3.5 text-emerald-400" /> },
          { id: '/plugins', label: lang === 'ar' ? '🧩 البلوجنات (/plugins)' : 'Plugins', icon: <Package className="w-3.5 h-3.5 text-purple-400" /> },
          { id: '/mods', label: lang === 'ar' ? '🧵 المودات (/mods)' : 'Mods', icon: <Layers className="w-3.5 h-3.5 text-cyan-400" /> },
          { id: '/config', label: lang === 'ar' ? '⚙️ الإعدادات (/config)' : 'Config', icon: <FileCode className="w-3.5 h-3.5 text-amber-400" /> },
          { id: '/logs', label: lang === 'ar' ? '📜 السجلات (/logs)' : 'Logs', icon: <FileText className="w-3.5 h-3.5 text-neutral-400" /> },
        ].map((folder) => (
          <button
            key={folder.id}
            onClick={() => setSelectedFolderFilter(folder.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
              selectedFolderFilter === folder.id
                ? 'bg-neutral-800 text-white font-bold border border-neutral-700 shadow-sm'
                : 'bg-neutral-950/80 text-neutral-400 hover:text-white border border-neutral-800'
            }`}
          >
            {folder.icon}
            <span>{folder.label}</span>
          </button>
        ))}
      </div>

      {/* Main Grid: File List + Live Editor */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 min-h-[480px]">
        {/* Left Column: File Explorer (5 cols on lg) */}
        <div className={`${activeFile ? 'lg:col-span-5' : 'lg:col-span-12'} bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden flex flex-col`}>
          <div className="p-3 border-b border-neutral-800 bg-neutral-900/60 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-white">
                {selectedFolderFilter === 'ALL'
                  ? lang === 'ar' ? 'جميع ملفات السيرفر' : 'All Server Files'
                  : selectedFolderFilter}
              </span>
              <span className="text-xs font-mono text-emerald-400">({filteredFiles.length})</span>
            </div>

            <div className="relative w-44">
              <Search className="w-3.5 h-3.5 text-neutral-500 absolute start-2 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder={lang === 'ar' ? 'بحث في الملفات...' : 'Filter files...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded px-2 ps-7 py-1 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="divide-y divide-neutral-800/60 overflow-y-auto flex-1 max-h-[520px]">
            {filteredFiles.length === 0 ? (
              <div className="py-12 text-center text-neutral-500 italic text-xs">
                {lang === 'ar' ? 'لا توجد ملفات في هذا المسار حالياً.' : 'No files found in this path.'}
              </div>
            ) : (
              filteredFiles.map((f) => (
                <div
                  key={f.path}
                  onClick={() => handleOpenFile(f)}
                  className={`p-3 cursor-pointer transition-colors flex items-center justify-between gap-2 text-xs ${
                    activeFile?.path === f.path
                      ? 'bg-emerald-950/40 text-emerald-300 font-medium border-s-2 border-emerald-400'
                      : 'hover:bg-neutral-900/60 text-neutral-300'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    {getFileIcon(f.name)}
                    <div className="truncate">
                      <div className="font-mono text-xs font-medium text-white truncate flex items-center gap-1.5">
                        <span>{f.name}</span>
                        {f.name.toLowerCase().endsWith('.zip') && (
                          <span className="text-[10px] text-amber-400 font-sans px-1 rounded bg-amber-950/60 border border-amber-800/40 font-bold">
                            ZIP سيت اب
                          </span>
                        )}
                        {f.path.startsWith('/world') && (
                          <span className="text-[10px] text-emerald-400 font-sans px-1 rounded bg-emerald-950/60 border border-emerald-800/40">
                            عالم
                          </span>
                        )}
                        {f.path.startsWith('/plugins') && (
                          <span className="text-[10px] text-purple-400 font-sans px-1 rounded bg-purple-950/60 border border-purple-800/40">
                            بلوجن
                          </span>
                        )}
                        {f.path.startsWith('/mods') && (
                          <span className="text-[10px] text-cyan-400 font-sans px-1 rounded bg-cyan-950/60 border border-cyan-800/40">
                            مود
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-neutral-500 font-mono truncate">{f.path}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0" onClick={(e) => e.stopPropagation()}>
                    <span className="text-[11px] text-neutral-500 font-mono me-1 tabular-nums">
                      {(f.sizeBytes / 1024).toFixed(1)} KB
                    </span>
                    {f.name.toLowerCase().endsWith('.zip') && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleTriggerUnzipExisting(f);
                        }}
                        title={lang === 'ar' ? 'فك ضغط الأرشيف في السيرفر' : 'Extract archive into server'}
                        className="px-2 py-0.5 rounded bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-neutral-950 border border-amber-500/40 text-[10px] font-bold transition-all flex items-center gap-1 shadow-sm"
                      >
                        <Archive className="w-3 h-3" />
                        <span>{lang === 'ar' ? 'فك الضغط' : 'Unzip'}</span>
                      </button>
                    )}
                    <button
                      onClick={(e) => handleDownloadFile(f, e)}
                      title={lang === 'ar' ? 'تنزيل الملف' : 'Download file'}
                      className="p-1 rounded text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => handleDeleteFile(f.path, e)}
                      title={lang === 'ar' ? 'حذف الملف' : 'Delete file'}
                      className="p-1 rounded text-neutral-400 hover:text-red-400 hover:bg-neutral-800 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: In-App File Opener / Editor (7 cols on lg) */}
        {activeFile ? (
          <div className="lg:col-span-7 bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden flex flex-col min-h-[480px]">
            {/* Editor Top Bar */}
            <div className="p-3 border-b border-neutral-800 bg-neutral-900/80 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 truncate">
                {activeFile.name.toLowerCase().endsWith('.zip') ? (
                  <Archive className="w-4 h-4 text-amber-400 shrink-0" />
                ) : (
                  <Code2 className="w-4 h-4 text-emerald-400 shrink-0" />
                )}
                <span className="font-mono text-xs font-bold text-white truncate">
                  {activeFile.path}
                </span>
                <span className="text-[11px] text-neutral-500 font-mono hidden sm:inline">
                  (عدلت: {activeFile.lastModified})
                </span>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {activeFile.name.toLowerCase().endsWith('.zip') ? (
                  <button
                    onClick={() =>
                      handleExecuteZipExtraction(
                        activeFile.content || '',
                        selectedFolderFilter === 'ALL' ? '' : selectedFolderFilter,
                        activeFile.name
                      )
                    }
                    disabled={isExtractingZip}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold transition-all shadow-sm disabled:opacity-50"
                  >
                    {isExtractingZip ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Archive className="w-3.5 h-3.5" />
                    )}
                    <span>
                      {isExtractingZip
                        ? lang === 'ar'
                          ? 'جارٍ فك الضغط...'
                          : 'Extracting...'
                        : lang === 'ar'
                        ? 'فك الضغط وتثبيت السيت اب'
                        : 'Extract Setup'}
                    </span>
                  </button>
                ) : (
                  <button
                    onClick={handleSaveFile}
                    className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-bold transition-all ${
                      saveSuccess
                        ? 'bg-emerald-500 text-neutral-950'
                        : 'bg-emerald-400 hover:bg-emerald-300 text-neutral-950 shadow-sm'
                    }`}
                  >
                    {saveSuccess ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
                    <span>{saveSuccess ? t.fileSavedSuccess : t.saveFile}</span>
                  </button>
                )}

                <button
                  onClick={handleCloseEditor}
                  className="p-1 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 transition-colors"
                  title="إغلاق المحرر"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Special World Level Info Card if opening /world/level.dat */}
            {activeFile.path === '/world/level.dat' && (
              <div className="bg-emerald-950/20 border-b border-emerald-800/40 p-3 flex items-center justify-between text-xs font-mono">
                <div className="flex items-center gap-2 text-emerald-300">
                  <Compass className="w-4 h-4" />
                  <span>عالم ماين كرافت: Seed [ {server.minecraftConfig?.seed || '84920491823901'} ]</span>
                </div>
                <span className="text-neutral-400 text-[11px]">Spawn: (124, 68, -89)</span>
              </div>
            )}

            {/* Content Display: ZIP Inspector OR Code Editor */}
            {activeFile.name.toLowerCase().endsWith('.zip') ? (
              <div className="flex-1 p-4 flex flex-col bg-neutral-950 overflow-y-auto space-y-4">
                {/* Archive Overview Card */}
                <div className="bg-gradient-to-r from-amber-950/30 to-neutral-900 border border-amber-500/30 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                      <Archive className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <span>{activeFile.name}</span>
                        <span className="text-[10px] bg-amber-950/80 border border-amber-800 text-amber-300 px-1.5 py-0.5 rounded font-mono font-bold">
                          أرشيف مضغوط ZIP
                        </span>
                      </h4>
                      <div className="flex items-center gap-3 text-xs text-neutral-400 mt-1 font-mono">
                        <span>الحجم: {(activeFile.sizeBytes / 1024).toFixed(1)} KB</span>
                        <span>·</span>
                        <span>الملفات المكتشفة بالداخل: {activeZipPreview.length}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() =>
                      handleExecuteZipExtraction(
                        activeFile.content || '',
                        selectedFolderFilter === 'ALL' ? '' : selectedFolderFilter,
                        activeFile.name
                      )
                    }
                    disabled={isExtractingZip}
                    className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs transition-all shadow-sm flex items-center gap-2 justify-center shrink-0 disabled:opacity-50"
                  >
                    {isExtractingZip ? <Loader2 className="w-4 h-4 animate-spin" /> : <Archive className="w-4 h-4" />}
                    <span>
                      {isExtractingZip
                        ? lang === 'ar'
                          ? 'جارٍ فك الضغط والتثبيت...'
                          : 'Extracting...'
                        : lang === 'ar'
                        ? 'فك الضغط في السيرفر الآن'
                        : 'Unpack Setup Now'}
                    </span>
                  </button>
                </div>

                {/* Internal Files Table */}
                <div className="bg-neutral-900/50 border border-neutral-800 rounded-xl p-4 space-y-3 flex-1 flex flex-col">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white flex items-center gap-1.5">
                      <FolderOpen className="w-4 h-4 text-emerald-400" />
                      <span>{lang === 'ar' ? 'الملفات المضمنة في هذا الأرشيف:' : 'Files compressed inside:'}</span>
                    </span>
                    <span className="text-xs font-mono text-neutral-400">
                      {activeZipPreview.length} {lang === 'ar' ? 'عنصر' : 'items'}
                    </span>
                  </div>

                  {isLoadingZipPreview ? (
                    <div className="py-12 flex flex-col items-center justify-center gap-2 text-neutral-400 text-xs">
                      <Loader2 className="w-5 h-5 animate-spin text-amber-400" />
                      <span>{lang === 'ar' ? 'جارٍ قراءة وفحص ملفات الأرشيف...' : 'Inspecting zip archive...'}</span>
                    </div>
                  ) : activeZipPreview.length === 0 ? (
                    <div className="py-8 text-center text-xs text-neutral-500 italic">
                      {lang === 'ar' ? 'لم يتم العثور على ملفات أو الأرشيف فارغ.' : 'Archive is empty.'}
                    </div>
                  ) : (
                    <div className="divide-y divide-neutral-800/60 max-h-[340px] overflow-y-auto rounded-lg border border-neutral-800/60 bg-neutral-950/60">
                      {activeZipPreview.map((item, idx) => (
                        <div key={idx} className="p-2.5 flex items-center justify-between gap-3 text-xs">
                          <div className="flex items-center gap-2 font-mono truncate">
                            {getFileIcon(item.name)}
                            <span className="text-neutral-200 truncate">{item.path}</span>
                            {item.path.includes('/world') && (
                              <span className="text-[9px] px-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/50">
                                عالم
                              </span>
                            )}
                            {item.name.endsWith('.jar') && item.path.includes('/plugins') && (
                              <span className="text-[9px] px-1 rounded bg-purple-950 text-purple-400 border border-purple-800/50">
                                بلوجن
                              </span>
                            )}
                            {item.name.endsWith('.jar') && item.path.includes('/mods') && (
                              <span className="text-[9px] px-1 rounded bg-cyan-950 text-cyan-400 border border-cyan-800/50">
                                مود
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] font-mono text-neutral-500 shrink-0 tabular-nums">
                            {(item.sizeBytes / 1024).toFixed(1)} KB
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              /* Regular Text Editor */
              <div className="flex-1 p-3 flex flex-col bg-neutral-950 font-mono text-xs">
                <textarea
                  value={fileContentDraft}
                  onChange={(e) => setFileContentDraft(e.target.value)}
                  className="w-full flex-1 min-h-[380px] bg-neutral-900/60 text-neutral-200 border border-neutral-800 rounded-lg p-3 font-mono text-xs leading-relaxed focus:outline-none focus:border-emerald-500/80 resize-none selection:bg-emerald-500/30"
                  spellCheck={false}
                />
                <div className="flex items-center justify-between text-[11px] text-neutral-500 font-mono mt-2 pt-1 border-t border-neutral-800/50">
                  <span>
                    {fileContentDraft.split('\n').length} أسطر · {fileContentDraft.length} حرف
                  </span>
                  <span>UTF-8 · LF</span>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="hidden lg:flex lg:col-span-7 bg-neutral-950/40 border border-neutral-800/80 rounded-xl items-center justify-center p-8 text-center flex-col">
            <Folder className="w-12 h-12 text-neutral-700 mb-3" />
            <div className="text-sm font-semibold text-neutral-300 mb-1">
              {lang === 'ar' ? 'اختر ملفاً من القائمة لفتحه واستعراضه فوراً' : 'Select a file to open and preview'}
            </div>
            <p className="text-xs text-neutral-500 max-w-sm leading-relaxed">
              {lang === 'ar'
                ? 'يمكنك فتح وتعديل ملفات العالم (/world)، ملفات البلوجنات والمودات، و server.properties، أو رفع ملفاتك مباشرة.'
                : 'Instantly view and modify world files, plugins, mods, and properties.'}
            </p>
          </div>
        )}
      </div>

      {/* Ready Setups Modal */}
      {showSetupsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-2xl p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div>
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-indigo-400" />
                  <span>{lang === 'ar' ? 'ستابات وقوالب السيرفرات الجاهزة' : 'Ready-Made Server Setups'}</span>
                </h4>
                <p className="text-xs text-neutral-400 mt-0.5">
                  {lang === 'ar'
                    ? 'اختر باقة كاملة لتثبيت الإضافات، المودات، ملفات العالم، والتكوينات بنقرة واحدة.'
                    : 'Install pre-configured modpacks, plugins, and world packs in 1-click.'}
                </p>
              </div>
              <button
                onClick={() => setShowSetupsModal(false)}
                className="text-neutral-400 hover:text-white p-1 rounded hover:bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Custom ZIP Setup Upload Card */}
            <div className="bg-gradient-to-r from-amber-950/30 via-neutral-900 to-indigo-950/30 border border-amber-500/40 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                  <Archive className="w-5 h-5" />
                </div>
                <div>
                  <h5 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>{lang === 'ar' ? 'رفع سيت اب مخصص بصيغة (.zip)' : 'Upload Custom (.zip) Setup'}</span>
                    <span className="text-[10px] bg-emerald-950/80 border border-emerald-800 text-emerald-300 px-1.5 py-0.5 rounded font-mono font-bold">
                      {lang === 'ar' ? 'فك ضغط تلقائي' : 'Auto Unzip'}
                    </span>
                  </h5>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {lang === 'ar'
                      ? 'ارفع ملف مضغوط يحتوي على سيرفر جاهز، عالم مخصص، أو حزمة إضافات ومودات وسيقوم النظام بفك ضغطه وتهيئته فوراً.'
                      : 'Upload any ZIP containing a world save, plugins bundle, or full server setup.'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowSetupsModal(false);
                  zipUploadInputRef.current?.click();
                }}
                className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs shrink-0 transition-colors shadow-sm flex items-center gap-1.5 justify-center"
              >
                <Upload className="w-4 h-4" />
                <span>{lang === 'ar' ? 'اختيار ملف ZIP من جهازك' : 'Choose ZIP File'}</span>
              </button>
            </div>

            <div className="space-y-3">
              {READY_SETUPS.map((setup) => (
                <div
                  key={setup.id}
                  className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-neutral-700 transition-colors"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-lg">{setup.icon}</span>
                      <span className="font-bold text-white text-sm">
                        {lang === 'ar' ? setup.name : setup.nameEn}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-950/60 border border-indigo-800/50 text-indigo-300">
                        {setup.badge}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-400 leading-relaxed max-w-lg">
                      {lang === 'ar' ? setup.description : setup.descriptionEn}
                    </p>
                    <div className="text-[11px] font-mono text-neutral-500 pt-1 flex items-center gap-2">
                      <span>{setup.software}</span>
                      <span>·</span>
                      <span>RAM: {setup.ramMB} MB</span>
                      <span>·</span>
                      <span>{setup.filesCount} {lang === 'ar' ? 'ملفات متضمنة' : 'files included'}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleApplySetup(setup)}
                    className="px-4 py-2 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold text-xs shrink-0 transition-colors shadow-sm"
                  >
                    {lang === 'ar' ? 'تثبيت وتطبيق السيت اب' : 'Apply Setup'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* New File Creation Modal */}
      {showNewFileModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <h4 className="text-base font-bold text-white">
              {lang === 'ar' ? 'إنشاء ملف جديد في السيرفر' : 'Create New Server File'}
            </h4>

            <form onSubmit={handleCreateNewFile} className="space-y-3">
              <div>
                <label className="text-xs text-neutral-400 block mb-1">{t.newFileName}:</label>
                <input
                  type="text"
                  required
                  placeholder="/config/rules.txt أو /world/custom.dat"
                  value={newFilePath}
                  onChange={(e) => setNewFilePath(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400 block mb-1">المحتوى الأولي للملف:</label>
                <textarea
                  rows={4}
                  placeholder="# محتوى الملف..."
                  value={newFileContent}
                  onChange={(e) => setNewFileContent(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex gap-2 justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewFileModal(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-emerald-400 text-neutral-950 font-bold text-xs"
                >
                  {lang === 'ar' ? 'إنشاء وفتح' : 'Create & Open'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Pending ZIP Extraction Confirmation Modal */}
      {pendingZipExtract && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-neutral-900 border border-amber-500/40 rounded-xl w-full max-w-xl p-5 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                  <Archive className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>{lang === 'ar' ? 'فك ضغط وتثبيت سيت اب (.zip)' : 'Extract & Install (.zip) Setup'}</span>
                    <span className="text-[10px] bg-amber-950/80 border border-amber-800 text-amber-300 px-1.5 py-0.5 rounded font-mono font-bold">
                      {pendingZipExtract.name}
                    </span>
                  </h4>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {lang === 'ar'
                      ? 'حدد مسار الاستخراج ثم اضغط على زر التثبيت لتطبيق كافة الملفات والبلوجنات والمودات تلقائياً.'
                      : 'Choose extraction destination folder and confirm installation.'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setPendingZipExtract(null)}
                className="text-neutral-400 hover:text-white p-1 rounded hover:bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {extractError && (
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-800/50 flex items-center gap-2 text-xs text-red-300">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{extractError}</span>
              </div>
            )}

            {/* Destination folder selection */}
            <div className="space-y-1.5">
              <label className="text-xs text-neutral-300 font-semibold block">
                {lang === 'ar' ? 'مسار استخراج وفك ضغط الملفات:' : 'Extraction Target Folder:'}
              </label>
              <select
                value={pendingZipExtract.targetFolder}
                onChange={(e) =>
                  setPendingZipExtract({
                    ...pendingZipExtract,
                    targetFolder: e.target.value,
                  })
                }
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
              >
                <option value="">{lang === 'ar' ? '/ (الجذر - موصى به للستابات الكاملة والملفات العامة)' : '/ (Root - Full Server Setup)'}</option>
                <option value="/world">{lang === 'ar' ? '/world (مجلد العالم وحفظات السيرفر)' : '/world (Minecraft World Save)'}</option>
                <option value="/plugins">{lang === 'ar' ? '/plugins (مجلد الإضافات والبلوجنات)' : '/plugins (Server Plugins)'}</option>
                <option value="/mods">{lang === 'ar' ? '/mods (مجلد مودات فابريك)' : '/mods (Fabric Mods)'}</option>
                <option value="/config">{lang === 'ar' ? '/config (ملفات الإعدادات والتكوين)' : '/config (Configurations)'}</option>
              </select>
            </div>

            {/* Archive files preview */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-neutral-300">
                <span>{lang === 'ar' ? 'الملفات المكتشفة داخل الأرشيف:' : 'Files detected in archive:'}</span>
                <span className="font-mono text-neutral-400">
                  {pendingZipExtract.previewFiles?.length || 0} {lang === 'ar' ? 'ملف' : 'files'} (
                  {((pendingZipExtract.sizeBytes || 0) / 1024).toFixed(1)} KB)
                </span>
              </div>

              <div className="divide-y divide-neutral-800/60 max-h-48 overflow-y-auto rounded-lg border border-neutral-800/80 bg-neutral-950/70 p-2 font-mono text-xs">
                {pendingZipExtract.previewFiles?.map((file, idx) => (
                  <div key={idx} className="py-1.5 px-2 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 truncate">
                      {getFileIcon(file.name)}
                      <span className="text-neutral-200 truncate">{file.path}</span>
                    </div>
                    <span className="text-[11px] text-neutral-500 shrink-0 tabular-nums">
                      {(file.sizeBytes / 1024).toFixed(1)} KB
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-neutral-800">
              <button
                type="button"
                onClick={() => setPendingZipExtract(null)}
                className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white transition-colors"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                disabled={isExtractingZip}
                onClick={() =>
                  handleExecuteZipExtraction(
                    pendingZipExtract.source,
                    pendingZipExtract.targetFolder,
                    pendingZipExtract.name
                  )
                }
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs transition-colors shadow-sm disabled:opacity-50"
              >
                {isExtractingZip ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Archive className="w-4 h-4" />
                )}
                <span>
                  {isExtractingZip
                    ? lang === 'ar'
                      ? 'جارٍ فك الضغط والتثبيت...'
                      : 'Extracting...'
                    : lang === 'ar'
                    ? 'فك الضغط وتثبيت السيت اب'
                    : 'Confirm Extract & Install'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Extraction Success Modal */}
      {zipExtractSuccess && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-neutral-900 border border-emerald-500/40 rounded-xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">
                  {lang === 'ar' ? 'تم فك الضغط وتثبيت السيت اب بنجاح!' : 'Setup Unzipped Successfully!'}
                </h4>
                <p className="text-xs text-neutral-400 mt-0.5">
                  {lang === 'ar'
                    ? 'تم دمج كافة الملفات في نظام السيرفر وتفعيل الإضافات والمودات المكتشفة.'
                    : 'All files merged into server filesystem and packages activated.'}
                </p>
              </div>
            </div>

            {/* Extraction stats */}
            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="p-2.5 rounded-lg bg-neutral-950 border border-neutral-800">
                <div className="text-neutral-500 text-[10px]">{lang === 'ar' ? 'الملفات المستخرجة' : 'Extracted Files'}</div>
                <div className="text-white font-bold text-sm mt-0.5">{zipExtractSuccess.summary.totalFiles}</div>
              </div>
              <div className="p-2.5 rounded-lg bg-neutral-950 border border-neutral-800">
                <div className="text-neutral-500 text-[10px]">{lang === 'ar' ? 'الحجم الإجمالي' : 'Total Size'}</div>
                <div className="text-emerald-400 font-bold text-sm mt-0.5">
                  {(zipExtractSuccess.summary.totalSizeBytes / 1024).toFixed(1)} KB
                </div>
              </div>
              {zipExtractSuccess.summary.pluginsCount > 0 && (
                <div className="p-2.5 rounded-lg bg-purple-950/40 border border-purple-800/50">
                  <div className="text-purple-300 text-[10px]">{lang === 'ar' ? 'بلوجنات مفعلة' : 'Plugins Added'}</div>
                  <div className="text-white font-bold text-sm mt-0.5">{zipExtractSuccess.summary.pluginsCount}</div>
                </div>
              )}
              {zipExtractSuccess.summary.modsCount > 0 && (
                <div className="p-2.5 rounded-lg bg-cyan-950/40 border border-cyan-800/50">
                  <div className="text-cyan-300 text-[10px]">{lang === 'ar' ? 'مودات فابريك' : 'Mods Added'}</div>
                  <div className="text-white font-bold text-sm mt-0.5">{zipExtractSuccess.summary.modsCount}</div>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setZipExtractSuccess(null)}
                className="px-4 py-2 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold text-xs transition-colors shadow-sm"
              >
                {lang === 'ar' ? 'تصفح ملفات السيرفر الآن' : 'Browse Server Files'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {fileToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-neutral-900 border border-red-500/30 rounded-xl w-full max-w-sm p-5 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-red-950/60 border border-red-800/50 flex items-center justify-center text-red-400 shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">
                  {lang === 'ar' ? 'تأكيد حذف الملف' : 'Confirm File Deletion'}
                </h4>
                <p className="text-xs text-neutral-400 font-mono break-all mt-0.5">
                  {fileToDelete}
                </p>
              </div>
            </div>

            <p className="text-xs text-neutral-300">
              {lang === 'ar'
                ? 'هل أنت متأكد من رغبتك في حذف هذا الملف نهائياً من السيرفر؟ لا يمكن التراجع عن هذا الإجراء.'
                : 'Are you sure you want to permanently delete this file from the server? This action cannot be undone.'}
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setFileToDelete(null)}
                className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white transition-colors"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs transition-colors shadow-sm"
              >
                {lang === 'ar' ? 'نعم، احذف الملف' : 'Delete File'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
