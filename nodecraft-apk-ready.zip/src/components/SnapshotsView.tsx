import React from 'react';
import { Archive, Download, RotateCcw, HardDrive } from 'lucide-react';
import { LocalServer } from '../types/server';
import { Language, I18N } from '../utils/i18n';

interface SnapshotsViewProps {
  servers: LocalServer[];
  onRestoreSnapshot: (serverId: string, snapshotName: string) => void;
  lang: Language;
}

export const SnapshotsView: React.FC<SnapshotsViewProps> = ({
  servers,
  onRestoreSnapshot,
  lang,
}) => {
  const t = I18N[lang];

  // Flatten all snapshots
  const allSnapshots = servers.flatMap((s) =>
    s.backups.map((bak) => ({
      ...bak,
      serverId: s.id,
      serverName: s.name,
    }))
  );

  const totalSizeMB = allSnapshots.reduce((acc, curr) => acc + curr.sizeMB, 0);

  const handleDownloadSnapshot = (snap: any) => {
    const data = JSON.stringify(snap, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${snap.name.replace(/\s+/g, '_')}_backup.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white mb-1">
            {lang === 'ar' ? 'أرشيف النسخ الاحتياطية ونقاط الاستعادة' : 'System Snapshots & Backups'}
          </h2>
          <p className="text-xs text-neutral-400">
            {lang === 'ar'
              ? 'إدارة نقاط الاستعادة المحفوظة محلياً لجميع سيرفرات ماين كرافت ومواقع الويب'
              : 'Safely restore or export local server snapshots and world states'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 bg-blue-950/60 px-3 py-1.5 rounded-lg border border-blue-800/60 font-mono text-xs text-blue-300">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            <span>Google Drive: ahmedopyj@gmail.com</span>
          </div>

          <div className="flex items-center gap-3 bg-neutral-950 px-4 py-2 rounded-lg border border-neutral-800 font-mono text-xs">
            <HardDrive className="w-4 h-4 text-emerald-400" />
            <span className="text-neutral-400">إجمالي الحجم:</span>
            <span className="font-bold text-white tabular-nums">{totalSizeMB} MB</span>
          </div>
        </div>
      </div>

      <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white">
            {lang === 'ar' ? 'النسخ المحفوظة على هذا الجهاز' : 'Saved Snapshots on Machine'}
          </h3>
          <span className="text-xs font-mono text-neutral-400">
            {allSnapshots.length} {lang === 'ar' ? 'نسخة' : 'snapshots'}
          </span>
        </div>

        {allSnapshots.length === 0 ? (
          <div className="py-12 text-center text-neutral-500 italic text-sm">
            {lang === 'ar' ? 'لا توجد نسخ احتياطية مسجلة بعد.' : 'No snapshots recorded yet.'}
          </div>
        ) : (
          <div className="divide-y divide-neutral-800">
            {allSnapshots.map((snap) => (
              <div
                key={snap.id}
                className="p-4 hover:bg-neutral-950/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-950/40 border border-emerald-800/40 flex items-center justify-center text-emerald-400 shrink-0">
                    <Archive className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="font-semibold text-white text-sm">{snap.name}</div>
                    <div className="flex items-center gap-2 text-neutral-400 font-mono text-[11px] mt-0.5">
                      <span className="text-emerald-400">{snap.serverName}</span>
                      <span>·</span>
                      <span>{snap.createdAt}</span>
                      <span>·</span>
                      <span>{snap.sizeMB} MB</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDownloadSnapshot(snap)}
                    className="p-2 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors"
                    title="تنزيل ملف النسخة"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onRestoreSnapshot(snap.serverId, snap.name)}
                    className="px-3 py-1.5 rounded bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold transition-colors"
                  >
                    {t.restoreBackup}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
