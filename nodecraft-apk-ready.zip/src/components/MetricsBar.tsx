import React from 'react';
import { Server, Activity, HardDrive, Cpu, Radio } from 'lucide-react';
import { LocalServer } from '../types/server';
import { Language, I18N } from '../utils/i18n';

interface MetricsBarProps {
  servers: LocalServer[];
  lang: Language;
}

export const MetricsBar: React.FC<MetricsBarProps> = ({ servers, lang }) => {
  const t = I18N[lang];

  const total = servers.length;
  const running = servers.filter((s) => s.status === 'online').length;
  const totalAllocatedRam = servers.reduce((acc, s) => acc + s.allocatedRamMB, 0);
  const currentRamUsage = servers.reduce(
    (acc, s) => acc + (s.status === 'online' ? s.metrics.memoryUsageMB : 0),
    0
  );
  const avgCpu = running > 0
    ? (
        servers
          .filter((s) => s.status === 'online')
          .reduce((acc, s) => acc + s.metrics.cpuUsage, 0) / running
      ).toFixed(1)
    : '0.0';

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      {/* Total & Active Servers */}
      <div className="bg-neutral-900/70 border border-neutral-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <div className="text-xs text-neutral-400 font-medium mb-1">{t.runningServers}</div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">{running}</span>
            <span className="text-xs text-neutral-400">/ {total} {t.totalServers}</span>
          </div>
        </div>
        <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
          <Server className="w-5 h-5" />
        </div>
      </div>

      {/* RAM Allocation */}
      <div className="bg-neutral-900/70 border border-neutral-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <div className="text-xs text-neutral-400 font-medium mb-1">{t.ramUsage}</div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">
              {(currentRamUsage / 1024).toFixed(1)} GB
            </span>
            <span className="text-xs text-neutral-400">
              / {(totalAllocatedRam / 1024).toFixed(1)} GB
            </span>
          </div>
        </div>
        <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
          <HardDrive className="w-5 h-5" />
        </div>
      </div>

      {/* CPU Load */}
      <div className="bg-neutral-900/70 border border-neutral-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <div className="text-xs text-neutral-400 font-medium mb-1">{t.totalCpu}</div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white tabular-nums">{avgCpu}%</span>
            <span className="text-xs text-neutral-400">
              {running > 0 ? (lang === 'ar' ? 'أداء مستقر' : 'Optimal') : (lang === 'ar' ? 'في الانتظار' : 'Idle')}
            </span>
          </div>
        </div>
        <div className="w-10 h-10 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
          <Cpu className="w-5 h-5" />
        </div>
      </div>

      {/* Network / Listening Ports */}
      <div className="bg-neutral-900/70 border border-neutral-800 rounded-xl p-4 flex items-center justify-between">
        <div>
          <div className="text-xs text-neutral-400 font-medium mb-1">{t.port}</div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
              {running}
            </span>
            <span className="text-xs text-neutral-400">
              {lang === 'ar' ? 'منافذ نشطة محلياً' : 'Active Local Ports'}
            </span>
          </div>
        </div>
        <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
          <Radio className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
};
