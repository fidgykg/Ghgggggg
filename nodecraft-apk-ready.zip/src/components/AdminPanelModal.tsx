import React, { useState } from 'react';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  UserCheck,
  UserX,
  Users,
  Crown,
  Search,
  Activity,
  AlertTriangle,
  Play,
  Square,
  RotateCw,
  Clock,
  Sparkles,
  X,
  CheckCircle2,
  Lock,
  Volume2,
  Database,
  Info,
  Ban,
  EyeOff,
} from 'lucide-react';
import { useAuth, AppUserProfile } from '../contexts/AuthContext';
import { SUPER_ADMIN_EMAIL } from '../lib/firebase';
import { Language } from '../utils/i18n';
import { LocalServer } from '../types/server';
import { maskEmail } from '../utils/privacy';

interface AdminPanelModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  servers: LocalServer[];
  onStartAllServers: () => void;
  onStopAllServers: () => void;
  onRestartAllServers: () => void;
  adminNotice: string;
  onUpdateAdminNotice: (notice: string) => void;
}

export const AdminPanelModal: React.FC<AdminPanelModalProps> = ({
  isOpen,
  onClose,
  lang,
  servers,
  onStartAllServers,
  onStopAllServers,
  onRestartAllServers,
  adminNotice,
  onUpdateAdminNotice,
}) => {
  const {
    currentUser,
    userProfile,
    isAdmin,
    isSuperAdmin,
    allUsers,
    adminRecords,
    auditLogs,
    updateUserRole,
    promoteUserToAdmin,
    demoteUserFromAdmin,
    banUser,
    unbanUser,
    toggleUserMute,
    warnUser,
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'users' | 'control' | 'audit'>('users');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState<'all' | 'admin' | 'moderator' | 'user' | 'banned'>('all');
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [noticeDraft, setNoticeDraft] = useState(adminNotice);
  const [banModalTarget, setBanModalTarget] = useState<AppUserProfile | null>(null);
  const [banReasonInput, setBanReasonInput] = useState('مخالفة شروط وقواعد المنصة والسيرفر');

  if (!isOpen) return null;

  const handleSetRole = async (user: AppUserProfile, newRole: 'admin' | 'moderator' | 'user') => {
    setActionLoading(user.uid);
    setActionSuccess(null);
    setActionError(null);
    const res = await updateUserRole(user.uid, user.email, user.displayName || user.email.split('@')[0], newRole);
    setActionLoading(null);
    if (res.success) {
      const roleName = newRole === 'admin' ? 'مشرف' : newRole === 'moderator' ? 'ضابط شات' : 'عضو عادي';
      setActionSuccess(
        lang === 'ar'
          ? `تم تحديث رتبة ${user.displayName || user.email} إلى [${roleName}] بنجاح!`
          : `Successfully updated rank of ${user.displayName || user.email} to [${newRole}]!`
      );
    } else {
      setActionError(res.error || 'Failed to update user rank');
    }
  };

  const handleDemote = async (uid: string, email: string) => {
    if (email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) {
      setActionError(
        lang === 'ar'
          ? 'لا يمكن سحب صلاحية مدير النظام الأساسي!'
          : 'Cannot revoke Super Admin privileges!'
      );
      return;
    }
    setActionLoading(uid);
    setActionSuccess(null);
    setActionError(null);
    const res = await demoteUserFromAdmin(uid, email);
    setActionLoading(null);
    if (res.success) {
      setActionSuccess(
        lang === 'ar'
          ? `تم سحب صلاحية المشرف من ${email}`
          : `Successfully revoked admin privileges from ${email}`
      );
    } else {
      setActionError(res.error || 'Failed to revoke admin privileges');
    }
  };

  const handleConfirmBan = async () => {
    if (!banModalTarget) return;
    setActionLoading(banModalTarget.uid);
    setActionError(null);
    setActionSuccess(null);
    const res = await banUser(banModalTarget.uid, banModalTarget.email, banReasonInput);
    setActionLoading(null);
    if (res.success) {
      setActionSuccess(
        lang === 'ar'
          ? `تم تبنيد اللاعب [${banModalTarget.displayName}] بنجاح وحظره من المنصة والشات!`
          : `Player [${banModalTarget.displayName}] has been successfully banned!`
      );
      setBanModalTarget(null);
    } else {
      setActionError(res.error || 'Failed to ban player');
    }
  };

  const handleUnbanPlayer = async (targetUser: AppUserProfile) => {
    setActionLoading(targetUser.uid);
    setActionError(null);
    setActionSuccess(null);
    const res = await unbanUser(targetUser.uid);
    setActionLoading(null);
    if (res.success) {
      setActionSuccess(
        lang === 'ar'
          ? `تم إلغاء تبنيد اللاعب [${targetUser.displayName}] واستعادة حسابه بنجاح!`
          : `Player [${targetUser.displayName}] has been unbanned successfully!`
      );
    } else {
      setActionError(res.error || 'Failed to unban player');
    }
  };

  const handleSaveNotice = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateAdminNotice(noticeDraft);
    setActionSuccess(
      lang === 'ar' ? 'تم تحديث الإشعار الإداري العام' : 'Global admin broadcast updated'
    );
  };

  // Filtered users list
  const filteredUsers = allUsers.filter((u) => {
    const matchesSearch =
      (u.email || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (u.displayName || '').toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (filterRole === 'banned') {
      return Boolean(u.isBanned);
    }
    if (filterRole === 'admin') {
      return u.role === 'admin' || u.role === 'superadmin' || u.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();
    }
    if (filterRole === 'moderator') {
      return u.role === 'moderator';
    }
    if (filterRole === 'user') {
      return u.role !== 'admin' && u.role !== 'superadmin' && u.role !== 'moderator' && u.email.toLowerCase() !== SUPER_ADMIN_EMAIL.toLowerCase();
    }
    return true;
  });

  const totalAdminsCount = allUsers.filter(
    (u) => u.role === 'admin' || u.role === 'superadmin' || u.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()
  ).length;

  const totalModsCount = allUsers.filter((u) => u.role === 'moderator').length;
  const totalBannedCount = allUsers.filter((u) => Boolean(u.isBanned)).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-neutral-900 border border-neutral-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-emerald-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">
                  {lang === 'ar' ? 'لوحة تحكم إدارة النظام' : 'System Admin Control Center'}
                </h2>
                <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/20 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  {isSuperAdmin ? (lang === 'ar' ? 'المدير العام (Super Admin)' : 'Super Admin') : (lang === 'ar' ? 'مشرف (Admin)' : 'Admin')}
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                {lang === 'ar'
                  ? `الحساب النشط: ${currentUser?.email} (المدير الأساسي: ${SUPER_ADMIN_EMAIL})`
                  : `Active: ${currentUser?.email} (Designated Super Admin: ${SUPER_ADMIN_EMAIL})`}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Notifications inside modal */}
        {actionSuccess && (
          <div className="px-6 py-2.5 bg-emerald-500/10 border-b border-emerald-500/20 text-emerald-400 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{actionSuccess}</span>
            </div>
            <button onClick={() => setActionSuccess(null)} className="hover:text-white">✕</button>
          </div>
        )}

        {actionError && (
          <div className="px-6 py-2.5 bg-rose-500/10 border-b border-rose-500/20 text-rose-400 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{actionError}</span>
            </div>
            <button onClick={() => setActionError(null)} className="hover:text-white">✕</button>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 px-6 border-b border-neutral-800 bg-neutral-950/40">
          <button
            onClick={() => setActiveTab('users')}
            className={`flex items-center gap-2 py-3 px-4 text-xs font-medium border-b-2 transition-all ${
              activeTab === 'users'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>{lang === 'ar' ? 'إدارة المستخدمين والمشرفين' : 'Users & Admins Management'}</span>
            <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-neutral-800 text-neutral-300">
              {allUsers.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('control')}
            className={`flex items-center gap-2 py-3 px-4 text-xs font-medium border-b-2 transition-all ${
              activeTab === 'control'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>{lang === 'ar' ? 'التحكم الإداري بالسيرفرات' : 'System Server Master Control'}</span>
          </button>

          <button
            onClick={() => setActiveTab('audit')}
            className={`flex items-center gap-2 py-3 px-4 text-xs font-medium border-b-2 transition-all ${
              activeTab === 'audit'
                ? 'border-emerald-500 text-emerald-400 font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>{lang === 'ar' ? 'سجل العمليات الإدارية' : 'Audit Trail Logs'}</span>
            <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-neutral-800 text-neutral-300">
              {auditLogs.length}
            </span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* TAB 1: USERS & ADMINS MANAGEMENT */}
          {activeTab === 'users' && (
            <div className="space-y-5">
              {/* Stat summary cards */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div className="p-4 rounded-xl bg-neutral-800/40 border border-neutral-700/60">
                  <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                    <span>{lang === 'ar' ? 'المدير العام الأعلى' : 'Super Admin'}</span>
                    <Crown className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="text-sm font-bold text-amber-300 font-mono truncate" title={SUPER_ADMIN_EMAIL}>
                    {maskEmail(SUPER_ADMIN_EMAIL)}
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    {lang === 'ar' ? 'صلاحيات مطلقة غير قابلة للإلغاء' : 'Full irrevocable root privileges'}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-neutral-800/40 border border-neutral-700/60">
                  <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                    <span>{lang === 'ar' ? 'المشرفين (Admins)' : 'Appointed Admins'}</span>
                    <Shield className="w-4 h-4 text-purple-400" />
                  </div>
                  <div className="text-xl font-bold text-white">
                    {totalAdminsCount}
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    {lang === 'ar' ? 'صلاحيات إدارة كاملة' : 'Full management role'}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-neutral-800/40 border border-neutral-700/60">
                  <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                    <span>{lang === 'ar' ? 'ضباط الشات' : 'Chat Moderators'}</span>
                    <ShieldCheck className="w-4 h-4 text-sky-400" />
                  </div>
                  <div className="text-xl font-bold text-white">
                    {totalModsCount}
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    {lang === 'ar' ? 'مراقبة الشات والكتم' : 'Chat control'}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-neutral-800/40 border border-rose-500/20 bg-rose-500/5">
                  <div className="flex items-center justify-between text-xs text-rose-300 mb-1">
                    <span>{lang === 'ar' ? 'المحظورين (Banned)' : 'Banned Players'}</span>
                    <Ban className="w-4 h-4 text-rose-400" />
                  </div>
                  <div className="text-xl font-bold text-rose-400">
                    {totalBannedCount}
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    {lang === 'ar' ? 'ممنوعين من الشات والسيرفر' : 'Restricted from platform'}
                  </div>
                </div>
              </div>

              {/* Instructions banner */}
              <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-start gap-2.5">
                <Info className="w-4 h-4 shrink-0 mt-0.5" />
                <p>
                  {lang === 'ar'
                    ? `بصفتك مدير النظام (${maskEmail(currentUser?.email)})، يمكنك تعيين الرتب لأي عضو: مشرف كامل (Admin) أو ضابط شات أو تبنيد أي لاعب مخالف وحظر دخوله واستعادة الحسابات المحظورة.`
                    : `As an administrator (${maskEmail(currentUser?.email)}), you can manage ranks, ban infringing players, and restore banned accounts.`}
                </p>
              </div>

              {/* Filters & Search */}
              <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
                <div className="relative w-full sm:w-72">
                  <Search className="absolute start-3 top-2.5 w-4 h-4 text-neutral-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder={lang === 'ar' ? 'بحث بالبريد أو الاسم...' : 'Search by email or name...'}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded-lg ps-9 pe-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="flex items-center gap-1.5 flex-wrap self-end sm:self-auto">
                  <button
                    onClick={() => setFilterRole('all')}
                    className={`px-3 py-1.5 text-xs rounded-lg transition-colors ${
                      filterRole === 'all'
                        ? 'bg-neutral-800 text-white font-medium'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {lang === 'ar' ? 'الكل' : 'All'} ({allUsers.length})
                  </button>
                  <button
                    onClick={() => setFilterRole('admin')}
                    className={`px-3 py-1.5 text-xs rounded-lg transition-colors ${
                      filterRole === 'admin'
                        ? 'bg-neutral-800 text-purple-400 font-medium'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {lang === 'ar' ? 'المشرفين' : 'Admins'} ({totalAdminsCount})
                  </button>
                  <button
                    onClick={() => setFilterRole('moderator')}
                    className={`px-3 py-1.5 text-xs rounded-lg transition-colors ${
                      filterRole === 'moderator'
                        ? 'bg-neutral-800 text-sky-400 font-medium'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {lang === 'ar' ? 'ضباط الشات' : 'Chat Mods'} ({totalModsCount})
                  </button>
                  <button
                    onClick={() => setFilterRole('user')}
                    className={`px-3 py-1.5 text-xs rounded-lg transition-colors ${
                      filterRole === 'user'
                        ? 'bg-neutral-800 text-emerald-400 font-medium'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    {lang === 'ar' ? 'الأعضاء' : 'Members'}
                  </button>
                  <button
                    onClick={() => setFilterRole('banned')}
                    className={`px-3 py-1.5 text-xs rounded-lg transition-colors flex items-center gap-1.5 ${
                      filterRole === 'banned'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30 font-medium'
                        : 'text-neutral-400 hover:text-rose-300'
                    }`}
                  >
                    <Ban className="w-3.5 h-3.5 text-rose-400" />
                    <span>{lang === 'ar' ? 'المحظورين' : 'Banned'}</span>
                    <span>({totalBannedCount})</span>
                  </button>
                </div>
              </div>

              {/* Users Table / List */}
              <div className="border border-neutral-800 rounded-xl overflow-hidden bg-neutral-950/60">
                {filteredUsers.length === 0 ? (
                  <div className="p-8 text-center text-neutral-400 text-xs">
                    <Users className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    {lang === 'ar'
                      ? 'لا يوجد مستخدمين يطابقون معايير البحث أو التصفية الحالية.'
                      : 'No users matching search or filter criteria.'}
                  </div>
                ) : (
                  <div className="divide-y divide-neutral-800/80">
                    {filteredUsers.map((u) => {
                      const isTargetSuper = u.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();
                      const isTargetAdmin = isTargetSuper || u.role === 'admin' || u.role === 'superadmin';
                      const isTargetMod = u.role === 'moderator';
                      const isSelf = u.uid === currentUser?.uid;

                      return (
                        <div
                          key={u.uid}
                          className="p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:bg-neutral-900/60 transition-colors"
                        >
                          {/* User info */}
                          <div className="flex items-center gap-3 min-w-0">
                            {u.photoURL ? (
                              <img
                                src={u.photoURL}
                                alt={u.displayName || u.email}
                                className="w-10 h-10 rounded-full border border-neutral-700 shrink-0 object-cover"
                              />
                            ) : (
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 border ${
                                isTargetSuper
                                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                                  : isTargetAdmin
                                  ? 'bg-purple-500/20 text-purple-400 border-purple-500/30'
                                  : isTargetMod
                                  ? 'bg-sky-500/20 text-sky-400 border-sky-500/30'
                                  : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                              }`}>
                                {(u.displayName || u.email || 'U')[0].toUpperCase()}
                              </div>
                            )}

                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-xs font-semibold text-white truncate">
                                  {u.displayName || u.email.split('@')[0]}
                                </span>
                                {isSelf && (
                                  <span className="text-[10px] px-1.5 py-0.2 bg-neutral-800 text-neutral-300 rounded">
                                    {lang === 'ar' ? 'أنت' : 'You'}
                                  </span>
                                )}
                                {u.isBanned && (
                                  <span className="text-[10px] px-1.5 py-0.2 bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded font-bold flex items-center gap-1">
                                    <Ban className="w-2.5 h-2.5 text-rose-400" />
                                    {lang === 'ar' ? 'مبند' : 'Banned'}: {u.banReason || 'مخالفة'}
                                  </span>
                                )}
                                {u.isMuted && !u.isBanned && (
                                  <span className="text-[10px] px-1.5 py-0.2 bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded">
                                    {lang === 'ar' ? 'مكتوم' : 'Muted'}
                                  </span>
                                )}
                                {(u.warningsCount || 0) > 0 && (
                                  <span className="text-[10px] px-1.5 py-0.2 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded">
                                    {u.warningsCount} {lang === 'ar' ? 'إنذارات' : 'warnings'}
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-neutral-400 truncate font-mono">
                                {maskEmail(u.email)}
                              </div>
                              <div className="text-[10px] text-neutral-400 font-mono">
                                UID: {u.uid.slice(0, 10)}...
                              </div>
                            </div>
                          </div>

                          {/* Role Badge and Action Buttons */}
                          <div className="flex items-center gap-2 flex-wrap shrink-0 self-end md:self-auto">
                            {/* Role Badge */}
                            {isTargetSuper ? (
                              <span className="px-2.5 py-1 rounded-md text-xs font-medium bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
                                <Crown className="w-3.5 h-3.5 text-amber-400" />
                                {lang === 'ar' ? 'المدير العام (Super Admin)' : 'Super Admin'}
                              </span>
                            ) : isTargetAdmin ? (
                              <span className="px-2.5 py-1 rounded-md text-xs font-medium bg-purple-500/15 text-purple-300 border border-purple-500/30 flex items-center gap-1.5">
                                <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
                                {lang === 'ar' ? 'مشرف (Admin)' : 'Admin'}
                              </span>
                            ) : isTargetMod ? (
                              <span className="px-2.5 py-1 rounded-md text-xs font-medium bg-sky-500/15 text-sky-300 border border-sky-500/30 flex items-center gap-1.5">
                                <Shield className="w-3.5 h-3.5 text-sky-400" />
                                {lang === 'ar' ? 'ضابط شات (Mod)' : 'Chat Mod'}
                              </span>
                            ) : (
                              <span className="px-2.5 py-1 rounded-md text-xs font-medium bg-neutral-800 text-neutral-300 border border-neutral-700 flex items-center gap-1.5">
                                <UserCheck className="w-3.5 h-3.5 text-neutral-400" />
                                {lang === 'ar' ? 'عضو عادي' : 'Member'}
                              </span>
                            )}

                            {/* Actions */}
                            {isTargetSuper ? (
                              <div className="flex items-center gap-1 px-3 py-1.5 text-xs text-amber-400/80 bg-amber-500/5 rounded-lg border border-amber-500/20">
                                <Lock className="w-3.5 h-3.5" />
                                <span>{lang === 'ar' ? 'محمي بالكامل' : 'Protected Root'}</span>
                              </div>
                            ) : (
                              <div className="flex items-center gap-1.5 flex-wrap">
                                {/* Ban / Unban Button */}
                                {u.isBanned ? (
                                  <button
                                    disabled={actionLoading === u.uid}
                                    onClick={() => handleUnbanPlayer(u)}
                                    className="px-2.5 py-1.5 text-xs font-semibold text-emerald-300 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 rounded-lg transition-colors disabled:opacity-50 flex items-center gap-1"
                                    title={lang === 'ar' ? 'إلغاء التبنيد واستعادة الحساب' : 'Unban player'}
                                  >
                                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                                    <span>{lang === 'ar' ? 'فك التبنيد' : 'Unban'}</span>
                                  </button>
                                ) : (
                                  <button
                                    disabled={actionLoading === u.uid}
                                    onClick={() => {
                                      setBanModalTarget(u);
                                      setBanReasonInput('مخالفة قواعد وسلوك السيرفر والمنصة');
                                    }}
                                    className="px-2.5 py-1.5 text-xs font-semibold text-rose-300 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 rounded-lg transition-colors disabled:opacity-50 flex items-center gap-1"
                                    title={lang === 'ar' ? 'تبنيد اللاعب ومنعه من الشات والسيرفر' : 'Ban player'}
                                  >
                                    <Ban className="w-3.5 h-3.5 text-rose-400" />
                                    <span>{lang === 'ar' ? 'تبنيد اللاعب' : 'Ban'}</span>
                                  </button>
                                )}

                                {/* Set as Chat Mod Button */}
                                {!isTargetMod && !u.isBanned && (
                                  <button
                                    disabled={actionLoading === u.uid}
                                    onClick={() => handleSetRole(u, 'moderator')}
                                    className="px-2.5 py-1.5 text-xs font-medium text-sky-300 bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 rounded-lg transition-colors disabled:opacity-50"
                                    title={lang === 'ar' ? 'تعيين كـ ضابط شات لمراقبة الدردشة' : 'Make Chat Moderator'}
                                  >
                                    {lang === 'ar' ? '👮 ضابط شات' : 'Make Mod'}
                                  </button>
                                )}

                                {/* Set as Admin Button */}
                                {!isTargetAdmin && !u.isBanned && (
                                  <button
                                    disabled={actionLoading === u.uid}
                                    onClick={() => handleSetRole(u, 'admin')}
                                    className="px-2.5 py-1.5 text-xs font-medium text-purple-300 bg-purple-500/15 hover:bg-purple-500/25 border border-purple-500/30 rounded-lg transition-colors disabled:opacity-50"
                                    title={lang === 'ar' ? 'ترقية لمشرف كامل' : 'Promote to Admin'}
                                  >
                                    {lang === 'ar' ? '🛡️ ترقية لمشرف' : 'Make Admin'}
                                  </button>
                                )}

                                {(isTargetAdmin || isTargetMod) && !u.isBanned && (
                                  <button
                                    disabled={actionLoading === u.uid}
                                    onClick={() => handleSetRole(u, 'user')}
                                    className="px-2.5 py-1.5 text-xs font-medium text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 rounded-lg transition-colors disabled:opacity-50"
                                    title={lang === 'ar' ? 'إعادة إلى رتبة عضو عادي' : 'Demote to regular Member'}
                                  >
                                    {lang === 'ar' ? 'عضو عادي' : 'To Member'}
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: SYSTEM SERVER MASTER CONTROL */}
          {activeTab === 'control' && (
            <div className="space-y-6">
              {/* Emergency Control Card */}
              <div className="p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-4">
                <div className="flex items-center gap-2 text-white font-semibold text-sm">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  <span>{lang === 'ar' ? 'إجراءات التحكم السريعة بالسيرفرات' : 'Global Server Batch Operations'}</span>
                </div>
                <p className="text-xs text-neutral-400">
                  {lang === 'ar'
                    ? 'هذه الأزرار تمنحك كمسؤول تحكماً مركزياً بكافة السيرفرات المشغلة في المنصة دفعة واحدة.'
                    : 'Execute mass administrative operations across all local servers.'}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  <button
                    onClick={() => {
                      onStartAllServers();
                      setActionSuccess(lang === 'ar' ? 'تم إصدار أمر تشغيل لجميع السيرفرات' : 'Triggered start for all servers');
                    }}
                    className="flex items-center justify-center gap-2 p-3 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 rounded-xl text-xs font-semibold transition-colors"
                  >
                    <Play className="w-4 h-4" />
                    <span>{lang === 'ar' ? 'تشغيل كافة السيرفرات' : 'Start All Servers'}</span>
                  </button>

                  <button
                    onClick={() => {
                      onRestartAllServers();
                      setActionSuccess(lang === 'ar' ? 'تمت إعادة تشغيل كافة السيرفرات' : 'Restarted all servers');
                    }}
                    className="flex items-center justify-center gap-2 p-3 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 text-blue-300 rounded-xl text-xs font-semibold transition-colors"
                  >
                    <RotateCw className="w-4 h-4" />
                    <span>{lang === 'ar' ? 'إعادة تشغيل عامة' : 'Restart All Servers'}</span>
                  </button>

                  <button
                    onClick={() => {
                      onStopAllServers();
                      setActionSuccess(lang === 'ar' ? 'تم إيقاف طوارئ لكافة السيرفرات' : 'Emergency stopped all servers');
                    }}
                    className="flex items-center justify-center gap-2 p-3 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 rounded-xl text-xs font-semibold transition-colors"
                  >
                    <Square className="w-4 h-4" />
                    <span>{lang === 'ar' ? 'إيقاف طوارئ للكل' : 'Emergency Stop All'}</span>
                  </button>
                </div>
              </div>

              {/* Broadcast Admin Notice */}
              <form onSubmit={handleSaveNotice} className="p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-4">
                <div className="flex items-center gap-2 text-white font-semibold text-sm">
                  <Volume2 className="w-4 h-4 text-amber-400" />
                  <span>{lang === 'ar' ? 'إذاعة إشعار إداري عام (Global Broadcast)' : 'Global Admin Announcement'}</span>
                </div>
                <p className="text-xs text-neutral-400">
                  {lang === 'ar'
                    ? 'يظهر هذا الإشعار كشريط تنبيهي أعلى المنصة لجميع المستخدمين واللاعبين.'
                    : 'This announcement banner will be pinned at the top of the interface for all users.'}
                </p>

                <div className="space-y-2">
                  <input
                    type="text"
                    value={noticeDraft}
                    onChange={(e) => setNoticeDraft(e.target.value)}
                    placeholder={
                      lang === 'ar'
                        ? 'مثال: تنبيه من الإدارة: سيتم إجراء صيانة مجدولة بعد 30 دقيقة...'
                        : 'e.g., Notice from Admin: Scheduled maintenance in 30 minutes...'
                    }
                    className="w-full bg-neutral-900 border border-neutral-700 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="flex items-center justify-between">
                  {noticeDraft && (
                    <button
                      type="button"
                      onClick={() => {
                        setNoticeDraft('');
                        onUpdateAdminNotice('');
                      }}
                      className="text-xs text-rose-400 hover:underline"
                    >
                      {lang === 'ar' ? 'مسح الإشعار الحالي' : 'Clear Announcement'}
                    </button>
                  )}
                  <button
                    type="submit"
                    className="ms-auto px-4 py-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 font-bold text-xs rounded-lg transition-colors"
                  >
                    {lang === 'ar' ? 'نشر الإشعار الآن' : 'Publish Broadcast'}
                  </button>
                </div>
              </form>

              {/* Status Overview of Servers */}
              <div className="p-5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-white">
                    {lang === 'ar' ? 'حالة السيرفرات في النظام' : 'Registered Server Nodes'}
                  </span>
                  <span className="text-xs text-neutral-400 font-mono">
                    {servers.filter((s) => s.status === 'online').length} / {servers.length} Online
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {servers.map((s) => (
                    <div
                      key={s.id}
                      className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            s.status === 'online'
                              ? 'bg-emerald-400 ring-2 ring-emerald-400/20'
                              : s.status === 'starting'
                              ? 'bg-amber-400 animate-pulse'
                              : 'bg-neutral-600'
                          }`}
                        />
                        <span className="font-semibold text-white">{s.name}</span>
                        <span className="text-neutral-400 font-mono">:{s.port}</span>
                      </div>
                      <span className="text-neutral-400 font-mono text-[10px]">
                        {s.allocatedRamMB}MB
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: AUDIT TRAIL LOGS */}
          {activeTab === 'audit' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span>{lang === 'ar' ? 'سجل العمليات الإدارية المسجلة في Firestore' : 'Administrative Actions Stored in Firestore'}</span>
                <span>{auditLogs.length} {lang === 'ar' ? 'عملية' : 'actions'}</span>
              </div>

              {auditLogs.length === 0 ? (
                <div className="p-8 text-center text-neutral-400 text-xs border border-neutral-800 rounded-xl bg-neutral-950">
                  <Clock className="w-8 h-8 mx-auto mb-2 opacity-40" />
                  {lang === 'ar'
                    ? 'لم يتم تسجيل أي عمليات ترقية أو سحب صلاحيات حتى الآن.'
                    : 'No administrative promotions or demotions recorded yet.'}
                </div>
              ) : (
                <div className="space-y-2">
                  {auditLogs.map((log) => (
                    <div
                      key={log.id}
                      className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800/80 text-xs flex items-start gap-3"
                    >
                      <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-semibold text-white">{log.action}</span>
                          <span className="text-[10px] text-neutral-400 font-mono">
                            {log.timestamp?.toDate ? log.timestamp.toDate().toLocaleString() : 'Just now'}
                          </span>
                        </div>
                        <p className="text-neutral-300 mt-1">{log.details}</p>
                        <div className="text-[10px] text-neutral-400 mt-1">
                          {lang === 'ar' ? 'المنفّذ: ' : 'By: '}
                          <span className="text-neutral-300">{log.performedByEmail}</span> | {lang === 'ar' ? 'الهدف: ' : 'Target: '}
                          <span className="text-neutral-300">{log.targetEmail}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-3.5 border-t border-neutral-800 bg-neutral-950/70 text-xs text-neutral-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>{lang === 'ar' ? 'قاعدة بيانات Firestore متصلة ومحمية بقواعد أمان' : 'Firestore security rules active & verified'}</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg transition-colors font-medium text-xs"
          >
            {lang === 'ar' ? 'إغلاق' : 'Close'}
          </button>
        </div>

      </div>

      {/* Ban Player Confirmation Modal */}
      {banModalTarget && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
          <div className="bg-neutral-900 border border-neutral-700/80 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/25 flex items-center justify-center text-rose-400 shrink-0">
                <Ban className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <h3 className="text-sm font-bold text-white">
                  {lang === 'ar' ? 'تأكيد تبنيد اللاعب من السيرفر' : 'Confirm Player Ban'}
                </h3>
                <p className="text-xs text-neutral-400 truncate">
                  {banModalTarget.displayName} ({maskEmail(banModalTarget.email)})
                </p>
              </div>
            </div>

            <p className="text-xs text-neutral-300">
              {lang === 'ar'
                ? 'سيتم حظر اللاعب فوراً من كتابة الرسائل في الشات وتقديم الاقتراحات وإظهار شارة الحظر في حسابه.'
                : 'The player will be immediately restricted from chat and suggestions with a banned badge.'}
            </p>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                {lang === 'ar' ? 'سبب التبنيد:' : 'Ban Reason:'}
              </label>
              <input
                type="text"
                value={banReasonInput}
                onChange={(e) => setBanReasonInput(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-rose-500 transition-colors"
                placeholder={lang === 'ar' ? 'اكتب سبب التبنيد...' : 'Enter ban reason...'}
              />
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setBanModalTarget(null)}
                className="px-4 py-2 text-xs font-medium text-neutral-400 hover:text-white rounded-xl transition-colors"
              >
                {lang === 'ar' ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleConfirmBan}
                disabled={actionLoading === banModalTarget.uid}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors shadow-md shadow-rose-950 disabled:opacity-50"
              >
                <Ban className="w-3.5 h-3.5" />
                <span>{lang === 'ar' ? 'تأكيد التبنيد' : 'Confirm Ban'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
