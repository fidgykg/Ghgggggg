import React, { useState } from 'react';
import { Wifi, Copy, Check, ShieldCheck, Terminal, Smartphone, Laptop, Globe } from 'lucide-react';
import { LocalServer, LocalNetworkInfo } from '../types/server';
import { Language, I18N } from '../utils/i18n';

interface NetworkViewProps {
  servers: LocalServer[];
  networkInfo: LocalNetworkInfo;
  onUpdateNetworkInfo: (info: LocalNetworkInfo) => void;
  lang: Language;
}

export const NetworkView: React.FC<NetworkViewProps> = ({
  servers,
  networkInfo,
  onUpdateNetworkInfo,
  lang,
}) => {
  const t = I18N[lang];
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [isEditingIp, setIsEditingIp] = useState(false);
  const [tempIp, setTempIp] = useState(networkInfo.localIp);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleSaveIp = () => {
    if (tempIp.trim()) {
      onUpdateNetworkInfo({ ...networkInfo, localIp: tempIp.trim() });
    }
    setIsEditingIp(false);
  };

  const onlineServers = servers.filter((s) => s.status === 'online');

  return (
    <div className="space-y-6">
      {/* Network Overview Card */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
              <Wifi className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                {lang === 'ar' ? 'معلومات الشبكة المحلية (LAN Status)' : 'Local Network Configuration'}
              </h2>
              <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono mt-0.5">
                <span>{networkInfo.hostname}</span>
                <span>·</span>
                <span>Gateway: {networkInfo.gateway}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isEditingIp ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={tempIp}
                  onChange={(e) => setTempIp(e.target.value)}
                  className="bg-neutral-950 border border-neutral-700 rounded px-2.5 py-1 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                />
                <button
                  onClick={handleSaveIp}
                  className="px-3 py-1 bg-emerald-400 text-neutral-950 rounded text-xs font-bold"
                >
                  حفظ
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 bg-neutral-950 px-3 py-1.5 rounded-lg border border-neutral-800 font-mono text-xs text-emerald-400">
                <span>IP: {networkInfo.localIp}</span>
                <button
                  onClick={() => setIsEditingIp(true)}
                  className="text-neutral-400 hover:text-white ms-2 text-[11px] underline"
                >
                  {lang === 'ar' ? 'تعديل' : 'Edit'}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Join Links for All Running Servers */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6">
        <h3 className="text-sm font-bold text-white mb-3">
          {lang === 'ar' ? 'عناوين الاتصال المباشر بالسيرفرات النشطة (LAN)' : 'Direct LAN Join Addresses for Active Servers'}
        </h3>

        {onlineServers.length === 0 ? (
          <p className="text-xs text-neutral-500 italic">
            {lang === 'ar' ? 'لا توجد سيرفرات تعمل حالياً. قم بتشغيل سيرفر لإنشاء رابط اتصال محلي.' : 'No active servers.'}
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {onlineServers.map((srv) => {
              const address = `${networkInfo.localIp}:${srv.port}`;
              return (
                <div
                  key={srv.id}
                  className="bg-neutral-950 border border-neutral-800/80 rounded-lg p-3.5 flex items-center justify-between"
                >
                  <div>
                    <div className="text-xs font-semibold text-white">{srv.name}</div>
                    <div className="text-[11px] font-mono text-emerald-400">{address}</div>
                  </div>
                  <button
                    onClick={() => copyToClipboard(address)}
                    className="p-1.5 rounded bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800 transition-colors flex items-center gap-1 text-xs"
                  >
                    {copiedText === address ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span className="text-[11px]">{copiedText === address ? t.copied : t.copyAddress}</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* playit.gg Global IP Addresses */}
      <div className="bg-gradient-to-r from-neutral-900 to-indigo-950/30 border border-indigo-900/40 rounded-xl p-6">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-bold text-white">
              {lang === 'ar' ? 'عناوين playit.gg العالمية (اللعب مع أصدقائك عبر الإنترنت دون فتح بورت)' : 'playit.gg Global Join IPs (Worldwide / Zero Port-Forwarding)'}
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              {lang === 'ar' ? 'انسخ هذا الآي بي وأرسله لأصدقائك في أي مكان في العالم للعب معاً فورياً.' : 'Share this IP with friends anywhere in the world to join directly.'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {servers
            .filter((s) => s.playitConfig?.enabled)
            .map((srv) => {
              const playitAddress = srv.playitConfig!.assignedAddress;
              return (
                <div
                  key={srv.id}
                  className="bg-neutral-950 border border-indigo-900/40 rounded-lg p-3.5 flex items-center justify-between"
                >
                  <div>
                    <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      <span>{srv.name}</span>
                    </div>
                    <div className="text-[11px] font-mono text-indigo-400 mt-0.5">{playitAddress}</div>
                  </div>
                  <button
                    onClick={() => copyToClipboard(playitAddress)}
                    className="p-1.5 rounded bg-indigo-950/60 hover:bg-indigo-900/80 text-indigo-300 hover:text-white border border-indigo-800/40 transition-colors flex items-center gap-1 text-xs"
                  >
                    {copiedText === playitAddress ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span className="text-[11px]">{copiedText === playitAddress ? t.copied : 'نسخ الآي بي'}</span>
                  </button>
                </div>
              );
            })}
        </div>
      </div>

      {/* Step-by-Step Connection Guide */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Minecraft Connection Card */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-white font-semibold text-sm">
            <Laptop className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'ar' ? 'طريقة دخول سيرفر ماين كرافت (كمبيوتر)' : 'Connecting to Minecraft (PC)'}</span>
          </div>
          <ol className="text-xs text-neutral-300 space-y-2 list-decimal ps-4 leading-relaxed">
            <li>تأكد أن جهازك وجهاز صديقك متصلان بنفس شبكة الواي فاي المنزلية.</li>
            <li>افتح لعبة Minecraft واختر <strong>Multiplayer</strong> ثم <strong>Direct Connection</strong>.</li>
            <li>
              أدخل العنوان: <code className="text-emerald-400 font-mono bg-neutral-950 px-1.5 py-0.5 rounded">{networkInfo.localIp}:25565</code> واضغط Join Server.
            </li>
          </ol>
        </div>

        {/* Web Browser / Mobile Devices Card */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-white font-semibold text-sm">
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <span>{lang === 'ar' ? 'فتح موقع الويب المحلي من الجوال أو التابلت' : 'Opening Web Server from Mobile'}</span>
          </div>
          <ol className="text-xs text-neutral-300 space-y-2 list-decimal ps-4 leading-relaxed">
            <li>اتصل بنفس شبكة الواي فاي المنزلية على هاتفك.</li>
            <li>افتح متصفح سفاري أو كروم على الجوال.</li>
            <li>
              اكتب في شريط العنوان: <code className="text-cyan-400 font-mono bg-neutral-950 px-1.5 py-0.5 rounded">http://{networkInfo.localIp}:8080</code>
            </li>
          </ol>
        </div>
      </div>

      {/* Windows Firewall & Port Troubleshooting Helper */}
      <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-5">
        <div className="flex items-center gap-2 text-white font-semibold text-sm mb-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>{lang === 'ar' ? 'حل مشكلة جدار الحماية (Firewall) في حال تعذر اتصال أصدقائك' : 'Firewall Port Exception'}</span>
        </div>
        <p className="text-xs text-neutral-400 mb-3 leading-relaxed">
          {lang === 'ar'
            ? 'في بعض الأحيان يقوم ويندوز بحظر المنافذ الواردة. يمكنك نسخ هذا الأمر وتشغيله في موجه أوامر PowerShell كمسؤول (Run as Admin):'
            : 'If external LAN devices cannot reach your server, allow TCP port 25565 in Windows Firewall:'}
        </p>
        <div className="bg-neutral-900 p-3 rounded-lg border border-neutral-800 flex items-center justify-between font-mono text-xs">
          <code className="text-neutral-300 overflow-x-auto truncate">
            netsh advfirewall firewall add rule name="NodeCraft Server" dir=in action=allow protocol=TCP localport=25565,8080
          </code>
          <button
            onClick={() =>
              copyToClipboard(
                'netsh advfirewall firewall add rule name="NodeCraft Server" dir=in action=allow protocol=TCP localport=25565,8080'
              )
            }
            className="p-1.5 ms-2 text-neutral-400 hover:text-white rounded hover:bg-neutral-800 shrink-0"
          >
            {copiedText?.includes('netsh') ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>
    </div>
  );
};
