import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Shield,
  Crown,
  ShieldCheck,
  User,
  Trash2,
  VolumeX,
  Volume2,
  AlertTriangle,
  Pin,
  Search,
  RotateCcw,
  Sparkles,
  Info,
  CheckCircle,
  Ban,
} from 'lucide-react';
import { useAuth, AppRole } from '../contexts/AuthContext';
import { Language } from '../utils/i18n';
import { db } from '../lib/firebase';
import { maskEmail } from '../utils/privacy';
import {
  collection,
  addDoc,
  onSnapshot,
  query,
  orderBy,
  limit,
  serverTimestamp,
  updateDoc,
  doc,
  Timestamp,
} from 'firebase/firestore';

export interface ChatMessage {
  id: string;
  text: string;
  authorUid: string;
  authorEmail: string;
  authorName: string;
  authorPhoto?: string;
  authorRole: AppRole;
  isDeleted?: boolean;
  deletedBy?: string;
  isPinned?: boolean;
  createdAt: number; // Unix timestamp
}

interface ChatModeratorViewProps {
  lang: Language;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    text: 'أهلاً وسهلاً بجميع اللاعبين والمطورين في سيرفر ماين كرافت ahop508! يرجى الالتزام بالقواعد وعدم استخدام الشتائم.',
    authorUid: 'superadmin-ahmed',
    authorEmail: 'ahmedopyj@gmail.com',
    authorName: 'أحمد (Super Admin)',
    authorPhoto: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    authorRole: 'superadmin',
    isPinned: true,
    createdAt: Date.now() - 1000 * 60 * 30,
  },
  {
    id: 'msg-2',
    text: 'أنا متواجد كـ ضابط شات لمراقبة المحادثات ومساعدة الأعضاء. أي استفسار أو مخالفة يرجى الإبلاغ عنها فوراً.',
    authorUid: 'mod-salem',
    authorEmail: 'salem.mod@nodecraft.local',
    authorName: 'سالم - ضابط الشات',
    authorPhoto: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    authorRole: 'moderator',
    createdAt: Date.now() - 1000 * 60 * 18,
  },
  {
    id: 'msg-3',
    text: 'تم تحديث منفذ السيرفر المحلي إلى 25565 ويعمل مع كافة إصدارات 1.7.5 حتى 1.21.11.',
    authorUid: 'admin-khalid',
    authorEmail: 'khalid.admin@nodecraft.local',
    authorName: 'خالد - مشرف تقني',
    authorPhoto: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    authorRole: 'admin',
    createdAt: Date.now() - 1000 * 60 * 8,
  },
  {
    id: 'msg-4',
    text: 'السيرفر سريع جداً والبينغ ممتاز! شكراً لكم شباب على جهودكم.',
    authorUid: 'player-omar',
    authorEmail: 'omar.gamer@nodecraft.local',
    authorName: 'عمر اللاعب',
    authorPhoto: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    authorRole: 'user',
    createdAt: Date.now() - 1000 * 60 * 2,
  },
];

export const ChatModeratorView: React.FC<ChatModeratorViewProps> = ({ lang }) => {
  const {
    currentUser,
    userProfile,
    isAdmin,
    isSuperAdmin,
    isChatModerator,
    muteUser,
    warnUser,
    banUser,
    unbanUser,
    allUsers,
  } = useAuth();

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('ahop508_chat_msgs');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_MESSAGES;
  });

  const [inputText, setInputText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSubTab, setActiveSubTab] = useState<'chat' | 'moderator_hub'>('chat');
  const [modNotice, setModNotice] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll on new messages
  useEffect(() => {
    if (activeSubTab === 'chat') {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, activeSubTab]);

  // Persist locally
  useEffect(() => {
    localStorage.setItem('ahop508_chat_msgs', JSON.stringify(messages));
  }, [messages]);

  // Sync with Firestore if active
  useEffect(() => {
    try {
      const q = query(collection(db, 'chat_messages'), orderBy('createdAt', 'asc'), limit(80));
      const unsub = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const list: ChatMessage[] = [];
            snapshot.forEach((doc) => {
              const data = doc.data();
              list.push({
                id: doc.id,
                text: data.text || '',
                authorUid: data.authorUid || '',
                authorEmail: data.authorEmail || '',
                authorName: data.authorName || 'User',
                authorPhoto: data.authorPhoto || '',
                authorRole: data.authorRole || 'user',
                isDeleted: data.isDeleted || false,
                deletedBy: data.deletedBy || '',
                isPinned: data.isPinned || false,
                createdAt: data.createdAt?.toMillis ? data.createdAt.toMillis() : Date.now(),
              });
            });
            setMessages(list);
          }
        },
        (error) => {
          console.warn('Firestore chat listener fallback:', error.message);
        }
      );
      return () => unsub();
    } catch (err) {
      console.warn('Firestore chat attach warning:', err);
    }
  }, []);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    if (userProfile?.isBanned) {
      setModNotice(`حسابك مبند حالياً بقرار إداري (${userProfile.banReason || 'مخالفة الشروط'}). لا يمكنك إرسال رسائل.`);
      return;
    }

    if (userProfile?.isMuted) {
      setModNotice('أنت مكتوم حالياً من قبل ضابط الشات، لا يمكنك إرسال رسائل.');
      return;
    }

    const currentRole: AppRole =
      isSuperAdmin ? 'superadmin' :
      isAdmin ? 'admin' :
      isChatModerator ? 'moderator' :
      'user';

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      text: inputText.trim(),
      authorUid: currentUser?.uid || 'guest-uid',
      authorEmail: currentUser?.email || 'guest@nodecraft.local',
      authorName: currentUser?.displayName || userProfile?.displayName || 'لاعب',
      authorPhoto: currentUser?.photoURL || userProfile?.photoURL || '',
      authorRole: currentRole,
      createdAt: Date.now(),
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputText('');

    // Try sending to Firestore
    try {
      await addDoc(collection(db, 'chat_messages'), {
        text: newMsg.text,
        authorUid: newMsg.authorUid,
        authorEmail: newMsg.authorEmail,
        authorName: newMsg.authorName,
        authorPhoto: newMsg.authorPhoto,
        authorRole: newMsg.authorRole,
        isDeleted: false,
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      console.warn('Message saved locally (Firestore fallback):', err);
    }
  };

  // Moderator: Delete message
  const handleDeleteMessage = async (msgId: string) => {
    if (!isChatModerator) return;

    setMessages((prev) =>
      prev.map((m) =>
        m.id === msgId
          ? {
              ...m,
              isDeleted: true,
              deletedBy: currentUser?.displayName || 'ضابط الشات',
            }
          : m
      )
    );

    try {
      const docRef = doc(db, 'chat_messages', msgId);
      await updateDoc(docRef, {
        isDeleted: true,
        deletedBy: currentUser?.displayName || 'ضابط الشات',
      });
    } catch {
      // optimistic
    }
  };

  // Moderator: Pin message
  const handleTogglePinMessage = async (msgId: string, currentPin?: boolean) => {
    if (!isChatModerator) return;

    setMessages((prev) =>
      prev.map((m) =>
        m.id === msgId ? { ...m, isPinned: !currentPin } : m
      )
    );

    try {
      const docRef = doc(db, 'chat_messages', msgId);
      await updateDoc(docRef, { isPinned: !currentPin });
    } catch {
      // optimistic
    }
  };

  // Moderator: Clear all messages
  const handleClearChat = () => {
    if (!isChatModerator) return;
    if (confirm('هل أنت متأكد من مسح جميع رسائل الشات الحالية؟')) {
      setMessages([]);
      localStorage.removeItem('ahop508_chat_msgs');
      setModNotice('تم مسح سجل المحادثة بالكامل بواسطة ضابط الشات.');
    }
  };

  // Quick moderation on author
  const handleMuteAuthor = (authorUid: string, authorName: string) => {
    muteUser(authorUid, true);
    setModNotice(`تم كتم العضو ${authorName} بنجاح من قبل ضابط الشات.`);
  };

  const handleWarnAuthor = (authorUid: string, authorEmail: string, authorName: string) => {
    const reason = prompt(`اكتب سبب التحذير للعضو ${authorName}:`, 'مخالفة قواعد المحادثة والسلوك العام');
    if (reason) {
      warnUser(authorUid, authorEmail, reason);
      setModNotice(`تم إرسال تحذير رسمي للعضو ${authorName}: ${reason}`);
    }
  };

  const handleBanAuthor = async (authorUid: string, authorEmail: string, authorName: string) => {
    if (!isAdmin) return;
    const reason = prompt(`اكتب سبب تبنيد اللاعب [${authorName}]:`, 'مخالفة قواعد السيرفر والشات');
    if (reason) {
      const res = await banUser(authorUid, authorEmail, reason);
      if (res.success) {
        setModNotice(`تم تبنيد اللاعب ${authorName} وحظره بنجاح.`);
      } else {
        alert(res.error || 'فشل التبنيد');
      }
    }
  };

  const handleUnbanAuthor = async (authorUid: string, authorName: string) => {
    if (!isAdmin) return;
    const res = await unbanUser(authorUid);
    if (res.success) {
      setModNotice(`تم إلغاء تبنيد اللاعب ${authorName} واستعادة حسابه.`);
    }
  };

  // Pinned message
  const pinnedMessage = messages.find((m) => m.isPinned && !m.isDeleted);

  // Filter messages
  const filteredMessages = messages.filter((m) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      m.text.toLowerCase().includes(q) ||
      m.authorName.toLowerCase().includes(q) ||
      m.authorRole.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-4">
      {/* Top Banner & Moderator Identity */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-sky-500/20 via-sky-600/10 to-indigo-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400 shrink-0">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-white tracking-tight">
                  {lang === 'ar' ? 'غرفة الشات وضابط الشات' : 'Server Live Chat & Moderation'}
                </h1>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30 flex items-center gap-1">
                  <Shield className="w-3 h-3" />
                  {lang === 'ar' ? 'نظام الضبط نشط' : 'Mod Active'}
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                {lang === 'ar'
                  ? 'محادثة حية للاعبين مع لوحة تحكم كاملة لضابط الشات (حذف، كتم، تحذير، وتثبيت الإعلانات)'
                  : 'Real-time player chat with moderator tools (delete, mute, warn, announcements)'}
              </p>
            </div>
          </div>

          {/* Current Rank Badge & Subtabs */}
          <div className="flex items-center gap-2 self-start sm:self-center">
            {/* Active user role tag */}
            <div className="px-3 py-1.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center gap-2 text-xs">
              <span className="text-neutral-400">{lang === 'ar' ? 'رتبتك:' : 'Your rank:'}</span>
              {isSuperAdmin ? (
                <span className="text-amber-400 font-bold flex items-center gap-1">
                  <Crown className="w-3.5 h-3.5" /> مدير أعلى
                </span>
              ) : isChatModerator ? (
                <span className="text-sky-400 font-bold flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5" /> ضابط شات
                </span>
              ) : isAdmin ? (
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> مشرف
                </span>
              ) : (
                <span className="text-neutral-300 font-medium flex items-center gap-1">
                  <User className="w-3.5 h-3.5" /> عضو
                </span>
              )}
            </div>

            {/* Subtab Buttons */}
            <div className="flex bg-neutral-950 p-1 rounded-xl border border-neutral-800 text-xs">
              <button
                onClick={() => setActiveSubTab('chat')}
                className={`px-3 py-1 rounded-lg font-medium transition-colors ${
                  activeSubTab === 'chat'
                    ? 'bg-neutral-800 text-white'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {lang === 'ar' ? 'المحادثة' : 'Chat'}
              </button>
              {isChatModerator && (
                <button
                  onClick={() => setActiveSubTab('moderator_hub')}
                  className={`px-3 py-1 rounded-lg font-semibold flex items-center gap-1 transition-colors ${
                    activeSubTab === 'moderator_hub'
                      ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                      : 'text-sky-400 hover:text-sky-300'
                  }`}
                >
                  <Shield className="w-3 h-3" />
                  <span>{lang === 'ar' ? 'أدوات الضابط' : 'Mod Tools'}</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Notice Alert if any */}
      {modNotice && (
        <div className="p-3 rounded-xl bg-sky-500/15 border border-sky-500/30 text-sky-200 text-xs flex items-center justify-between animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-sky-400 shrink-0" />
            <span>{modNotice}</span>
          </div>
          <button
            onClick={() => setModNotice(null)}
            className="text-sky-300 hover:text-white font-bold px-2 py-0.5"
          >
            ✕
          </button>
        </div>
      )}

      {/* Main Chat Interface */}
      {activeSubTab === 'chat' && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[650px]">
          {/* Chat Room Top Bar */}
          <div className="px-5 py-3 border-b border-neutral-800 bg-neutral-950/70 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 min-w-0">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-semibold text-white">
                {lang === 'ar' ? 'غرفة اللاعبين العامة (#general)' : 'General Chat (#general)'}
              </span>
              <span className="text-[11px] text-neutral-400 font-mono">
                ({filteredMessages.length} {lang === 'ar' ? 'رسالة' : 'messages'})
              </span>
            </div>

            {/* Search Bar & Moderator quick actions */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-neutral-500 absolute start-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder={lang === 'ar' ? 'بحث في الرسائل...' : 'Search...'}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-neutral-900 border border-neutral-800 rounded-lg ps-8 pe-3 py-1 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-neutral-700 w-32 sm:w-48"
                />
              </div>

              {isChatModerator && (
                <button
                  onClick={handleClearChat}
                  title="مسح سجل الشات"
                  className="p-1.5 rounded-lg text-neutral-400 hover:text-rose-400 hover:bg-rose-500/10 border border-neutral-800 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Pinned Announcement Bar */}
          {pinnedMessage && (
            <div className="bg-gradient-to-r from-amber-500/15 via-sky-500/15 to-amber-500/15 border-b border-amber-500/30 px-4 py-2 flex items-center justify-between gap-3 text-xs text-amber-200 animate-in fade-in">
              <div className="flex items-center gap-2 min-w-0">
                <Pin className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="font-bold text-amber-300 shrink-0">
                  {lang === 'ar' ? 'إعلان مثبت من ضابط الشات:' : 'Pinned Announcement:'}
                </span>
                <span className="truncate">{pinnedMessage.text}</span>
              </div>
              {isChatModerator && (
                <button
                  onClick={() => handleTogglePinMessage(pinnedMessage.id, true)}
                  className="text-[11px] text-amber-400/80 hover:text-white shrink-0 underline"
                >
                  {lang === 'ar' ? 'إلغاء التثبيت' : 'Unpin'}
                </button>
              )}
            </div>
          )}

          {/* Messages Stream */}
          <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4">
            {filteredMessages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-neutral-500 py-12">
                <Shield className="w-12 h-12 text-neutral-700 mb-2" />
                <p className="text-sm font-medium">
                  {lang === 'ar' ? 'لا توجد رسائل بعد' : 'No messages yet'}
                </p>
                <p className="text-xs text-neutral-600 mt-1">
                  {lang === 'ar' ? 'كن أول من يكتب في شات السيرفر!' : 'Be the first to say hello!'}
                </p>
              </div>
            ) : (
              filteredMessages.map((msg) => {
                const isAuthorSuperAdmin = msg.authorRole === 'superadmin';
                const isAuthorMod = msg.authorRole === 'moderator';
                const isAuthorAdmin = msg.authorRole === 'admin';
                const isMe = currentUser?.uid === msg.authorUid || currentUser?.email === msg.authorEmail;

                return (
                  <div
                    key={msg.id}
                    className={`group relative flex items-start gap-3 p-3 rounded-xl transition-all ${
                      msg.isDeleted
                        ? 'bg-neutral-950/40 border border-dashed border-neutral-800 opacity-60'
                        : isAuthorSuperAdmin
                        ? 'bg-gradient-to-r from-amber-500/10 via-neutral-950 to-neutral-950 border border-amber-500/30'
                        : isAuthorMod
                        ? 'bg-gradient-to-r from-sky-500/10 via-neutral-950 to-neutral-950 border border-sky-500/30'
                        : isAuthorAdmin
                        ? 'bg-gradient-to-r from-emerald-500/10 via-neutral-950 to-neutral-950 border border-emerald-500/20'
                        : 'bg-neutral-950/60 border border-neutral-800/80 hover:border-neutral-700'
                    }`}
                  >
                    {/* User Avatar */}
                    {msg.authorPhoto ? (
                      <img
                        src={msg.authorPhoto}
                        alt={msg.authorName}
                        className="w-8 h-8 rounded-full object-cover shrink-0 border border-neutral-700 mt-0.5"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-neutral-800 text-neutral-300 font-bold text-xs flex items-center justify-center shrink-0 border border-neutral-700 mt-0.5">
                        {msg.authorName[0]?.toUpperCase() || 'U'}
                      </div>
                    )}

                    {/* Message Body */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span className="text-xs font-bold text-white">
                          {msg.authorName}
                        </span>

                        {/* Role Badges */}
                        {isAuthorSuperAdmin ? (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-gradient-to-r from-amber-500/20 to-amber-600/30 text-amber-300 border border-amber-500/40 flex items-center gap-1 shadow-sm">
                            <Crown className="w-3 h-3 text-amber-400" />
                            {lang === 'ar' ? 'مدير أعلى' : 'SUPER ADMIN'}
                          </span>
                        ) : isAuthorMod ? (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/40 flex items-center gap-1 shadow-sm">
                            <Shield className="w-3 h-3 text-sky-400" />
                            {lang === 'ar' ? 'ضابط شات' : 'MODERATOR'}
                          </span>
                        ) : isAuthorAdmin ? (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3 text-emerald-400" />
                            {lang === 'ar' ? 'مشرف' : 'ADMIN'}
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 rounded text-[10px] text-neutral-400 bg-neutral-800">
                            {lang === 'ar' ? 'عضو' : 'MEMBER'}
                          </span>
                        )}

                        {/* Timestamp */}
                        <span className="text-[10px] text-neutral-500 ms-auto">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      {/* Text content or deleted notice */}
                      {msg.isDeleted ? (
                        <p className="text-xs italic text-rose-400/80 flex items-center gap-1">
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>
                            {lang === 'ar'
                              ? `[تم حذف هذه الرسالة بواسطة ${msg.deletedBy || 'ضابط الشات'}]`
                              : `[This message was removed by ${msg.deletedBy || 'Moderator'}]`}
                          </span>
                        </p>
                      ) : (
                        <p className="text-xs text-neutral-200 leading-relaxed break-words whitespace-pre-wrap">
                          {msg.text}
                        </p>
                      )}
                    </div>

                    {/* Moderator Inline Action Bar (visible on hover for mods) */}
                    {isChatModerator && !msg.isDeleted && (
                      <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-neutral-900 border border-neutral-700 p-1 rounded-lg shadow-lg self-start">
                        {/* Pin */}
                        <button
                          onClick={() => handleTogglePinMessage(msg.id, msg.isPinned)}
                          title={msg.isPinned ? 'إلغاء التثبيت' : 'تثبيت كإعلان'}
                          className={`p-1 rounded text-neutral-400 hover:text-amber-400 hover:bg-neutral-800 ${
                            msg.isPinned ? 'text-amber-400' : ''
                          }`}
                        >
                          <Pin className="w-3.5 h-3.5" />
                        </button>

                        {/* Delete message */}
                        <button
                          onClick={() => handleDeleteMessage(msg.id)}
                          title="حذف الرسالة (صلاحية ضابط الشات)"
                          className="p-1 rounded text-neutral-400 hover:text-rose-400 hover:bg-rose-500/10"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>

                        {/* Mute author if not superadmin */}
                        {!isAuthorSuperAdmin && !isMe && (
                          <button
                            onClick={() => handleMuteAuthor(msg.authorUid, msg.authorName)}
                            title="كتم العضو من المحادثة"
                            className="p-1 rounded text-neutral-400 hover:text-amber-400 hover:bg-amber-500/10"
                          >
                            <VolumeX className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* Warn author */}
                        {!isAuthorSuperAdmin && !isMe && (
                          <button
                            onClick={() => handleWarnAuthor(msg.authorUid, msg.authorEmail, msg.authorName)}
                            title="إرسال تحذير رسمي"
                            className="p-1 rounded text-neutral-400 hover:text-yellow-400 hover:bg-yellow-500/10"
                          >
                            <AlertTriangle className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* Ban author (Admin & Superadmin privilege) */}
                        {isAdmin && !isAuthorSuperAdmin && !isMe && (
                          <button
                            onClick={() => handleBanAuthor(msg.authorUid, msg.authorEmail, msg.authorName)}
                            title={lang === 'ar' ? 'تبنيد اللاعب وحظره من السيرفر' : 'Ban player from server'}
                            className="p-1 rounded text-neutral-400 hover:text-rose-400 hover:bg-rose-500/10"
                          >
                            <Ban className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input Bar */}
          <form onSubmit={handleSendMessage} className="p-3 border-t border-neutral-800 bg-neutral-950/80">
            {userProfile?.isBanned ? (
              <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs text-center flex items-center justify-center gap-2 font-bold animate-pulse">
                <Ban className="w-4 h-4 text-rose-400 shrink-0" />
                <span>
                  {lang === 'ar'
                    ? `حسابك مبند حالياً من قبل إدارة السيرفر (${userProfile.banReason || 'مخالفة الشروط'}). لا يمكنك إرسال رسائل.`
                    : `Your account is banned (${userProfile.banReason || 'Rule violation'}). You cannot send messages.`}
                </span>
              </div>
            ) : userProfile?.isMuted ? (
              <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs text-center flex items-center justify-center gap-2 font-medium">
                <VolumeX className="w-4 h-4" />
                <span>
                  {lang === 'ar'
                    ? 'أنت مكتوم حالياً في الشات بقرار من ضابط الشات. يرجى مراجعة الإدارة.'
                    : 'You have been muted in chat by the moderator.'}
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder={
                    isChatModerator
                      ? (lang === 'ar' ? 'اكتب كـ ضابط شات (الرسائل مميزة برتبتك)...' : 'Type as Moderator...')
                      : (lang === 'ar' ? 'اكتب رسالتك هنا في الشات العام...' : 'Type a message...')
                  }
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  className="flex-1 bg-neutral-900 border border-neutral-700/80 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-sky-500 transition-colors"
                />

                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all shadow-sm disabled:opacity-40 disabled:cursor-not-allowed ${
                    isChatModerator
                      ? 'bg-sky-500 hover:bg-sky-400 text-neutral-950'
                      : 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950'
                  }`}
                >
                  <span>{lang === 'ar' ? 'إرسال' : 'Send'}</span>
                  <Send className="w-3.5 h-3.5 rtl:rotate-180" />
                </button>
              </div>
            )}
          </form>
        </div>
      )}

      {/* Subtab: Moderator Hub / Control Dashboard */}
      {activeSubTab === 'moderator_hub' && isChatModerator && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="border-b border-neutral-800 pb-4 flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-sky-400" />
                <span>{lang === 'ar' ? 'لوحة تحكم ضابط الشات' : 'Chat Moderator Control Hub'}</span>
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                {lang === 'ar'
                  ? 'متابعة سلوك الأعضاء، إدارة المكتومين، ومراجعة سجل المخالفات'
                  : 'Monitor user behavior, manage mutes, and review infractions'}
              </p>
            </div>

            <button
              onClick={() => setActiveSubTab('chat')}
              className="text-xs text-neutral-400 hover:text-white px-3 py-1.5 rounded-lg border border-neutral-800"
            >
              {lang === 'ar' ? 'العودة للمحادثة' : 'Back to Chat'}
            </button>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800">
              <span className="text-[11px] text-neutral-400 block mb-1">
                {lang === 'ar' ? 'إجمالي الرسائل' : 'Total Messages'}
              </span>
              <span className="text-2xl font-bold font-mono text-white">
                {messages.length}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800">
              <span className="text-[11px] text-neutral-400 block mb-1">
                {lang === 'ar' ? 'الرسائل المحذوفة من الضابط' : 'Deleted by Mod'}
              </span>
              <span className="text-2xl font-bold font-mono text-rose-400">
                {messages.filter((m) => m.isDeleted).length}
              </span>
            </div>
            <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800">
              <span className="text-[11px] text-neutral-400 block mb-1">
                {lang === 'ar' ? 'الأعضاء المكتومين' : 'Muted Members'}
              </span>
              <span className="text-2xl font-bold font-mono text-amber-400">
                {allUsers.filter((u) => u.isMuted).length}
              </span>
            </div>
          </div>

          {/* Users Moderation List */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-neutral-300 uppercase tracking-wider">
              {lang === 'ar' ? 'قائمة الأعضاء وإجراءات الضبط' : 'Members & Moderation Actions'}
            </h3>

            <div className="divide-y divide-neutral-800/80 border border-neutral-800 rounded-xl bg-neutral-950/60 overflow-hidden">
              {allUsers.map((user) => (
                <div key={user.uid} className="p-3.5 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    {user.photoURL ? (
                      <img src={user.photoURL} alt="" className="w-8 h-8 rounded-full object-cover shrink-0" />
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-neutral-800 text-neutral-300 flex items-center justify-center text-xs font-bold shrink-0">
                        {user.displayName[0]?.toUpperCase() || 'U'}
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white truncate">{user.displayName}</span>
                        <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                          user.role === 'superadmin' ? 'text-amber-400 bg-amber-500/20' :
                          user.role === 'moderator' ? 'text-sky-400 bg-sky-500/20' :
                          user.role === 'admin' ? 'text-emerald-400 bg-emerald-500/20' : 'text-neutral-400 bg-neutral-800'
                        }`}>
                          {user.role}
                        </span>
                        {user.isBanned && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded font-bold text-rose-400 bg-rose-500/20 border border-rose-500/30 flex items-center gap-1">
                            <Ban className="w-2.5 h-2.5" />
                            {lang === 'ar' ? 'مبند' : 'BANNED'}
                          </span>
                        )}
                        {user.isMuted && !user.isBanned && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded font-bold text-rose-400 bg-rose-500/20 border border-rose-500/30">
                            {lang === 'ar' ? 'مكتوم' : 'MUTED'}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-neutral-400 font-mono truncate">{maskEmail(user.email)}</p>
                      {user.warningsCount ? (
                        <p className="text-[10px] text-yellow-400 mt-0.5">
                          ⚠️ {user.warningsCount} {lang === 'ar' ? 'تحذيرات' : 'warnings'}: {user.lastWarningReason}
                        </p>
                      ) : null}
                    </div>
                  </div>

                  {/* Actions (cannot moderate superadmin) */}
                  {user.role !== 'superadmin' && (
                    <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
                      {/* Ban / Unban for Admin / Superadmin */}
                      {isAdmin && (
                        user.isBanned ? (
                          <button
                            onClick={() => handleUnbanAuthor(user.uid, user.displayName)}
                            className="px-2.5 py-1 text-xs font-semibold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-lg flex items-center gap-1"
                          >
                            <CheckCircle className="w-3.5 h-3.5" />
                            <span>{lang === 'ar' ? 'فك التبنيد' : 'Unban'}</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleBanAuthor(user.uid, user.email, user.displayName)}
                            className="px-2.5 py-1 text-xs font-semibold bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 rounded-lg flex items-center gap-1"
                          >
                            <Ban className="w-3.5 h-3.5" />
                            <span>{lang === 'ar' ? 'تبنيد' : 'Ban'}</span>
                          </button>
                        )
                      )}

                      {/* Mute / Unmute */}
                      {!user.isBanned && (
                        user.isMuted ? (
                          <button
                            onClick={() => {
                              muteUser(user.uid, false);
                              setModNotice(`تم فك الكتم عن ${user.displayName}`);
                            }}
                            className="px-2.5 py-1 text-xs font-semibold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-lg flex items-center gap-1"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>{lang === 'ar' ? 'فك الكتم' : 'Unmute'}</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleMuteAuthor(user.uid, user.displayName)}
                            className="px-2.5 py-1 text-xs font-semibold bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-lg flex items-center gap-1"
                          >
                            <VolumeX className="w-3.5 h-3.5" />
                            <span>{lang === 'ar' ? 'كتم' : 'Mute'}</span>
                          </button>
                        )
                      )}

                      <button
                        onClick={() => handleWarnAuthor(user.uid, user.email, user.displayName)}
                        className="px-2.5 py-1 text-xs font-semibold bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-300 border border-yellow-500/30 rounded-lg flex items-center gap-1"
                      >
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>{lang === 'ar' ? 'تحذير' : 'Warn'}</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
