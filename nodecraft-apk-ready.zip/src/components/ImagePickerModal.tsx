import React, { useState } from 'react';
import { X, Image as ImageIcon, Upload, Check, Link, Trash2 } from 'lucide-react';
import { Language, I18N } from '../utils/i18n';

interface ImagePickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentImage?: string;
  onSaveImage: (newImageUrl: string) => void;
  serverName: string;
  lang: Language;
}

export const PRESET_IMAGES = [
  {
    id: 'voxel_castle',
    name: 'قلعة الفوكسل والبرج المائي',
    nameEn: 'Voxel Castle & River',
    url: '/src/assets/images/minecraft_server_hero_1793499576781.jpg',
  },
  {
    id: 'nether_portal',
    name: 'بوابة النذر واللافا المشتعلة',
    nameEn: 'Nether Portal & Magma',
    url: '/src/assets/images/minecraft_nether_portal_1793501038603.jpg',
  },
  {
    id: 'cozy_village',
    name: 'القرية الجبلية الدافئة والثلوج',
    nameEn: 'Snowy Alpine Village',
    url: '/src/assets/images/minecraft_cozy_village_1793501038268.jpg',
  },
  {
    id: 'server_datacenter',
    name: 'مركز خوادم الويب الحديث',
    nameEn: 'Modern Server Datacenter',
    url: '/src/assets/images/web_server_datacenter_1793499577418.jpg',
  },
];

export const ImagePickerModal: React.FC<ImagePickerModalProps> = ({
  isOpen,
  onClose,
  currentImage,
  onSaveImage,
  serverName,
  lang,
}) => {
  const [selectedUrl, setSelectedUrl] = useState(currentImage || PRESET_IMAGES[0].url);
  const [customUrl, setCustomUrl] = useState('');
  const [tab, setTab] = useState<'presets' | 'custom' | 'upload'>('presets');

  if (!isOpen) return null;

  const handleApplyPreset = (url: string) => {
    setSelectedUrl(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setSelectedUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    onSaveImage(selectedUrl);
    onClose();
  };

  const handleRemoveImage = () => {
    onSaveImage('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-800 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ImageIcon className="w-5 h-5 text-emerald-400" />
              <span>{lang === 'ar' ? 'تغيير صورة غلاف السيرفر' : 'Change Server Banner Image'}</span>
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">{serverName}</p>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded hover:bg-neutral-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Live Preview */}
        <div className="p-5 border-b border-neutral-800 bg-neutral-950 flex flex-col items-center">
          <div className="text-xs text-neutral-400 mb-2 font-mono">
            {lang === 'ar' ? 'معاينة الغلاف الحالي:' : 'Current Banner Preview:'}
          </div>
          <div className="relative w-full h-32 rounded-lg overflow-hidden border border-neutral-800 bg-neutral-900">
            {selectedUrl ? (
              <img
                src={selectedUrl}
                alt="Server Banner Preview"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-xs text-neutral-500 italic">
                {lang === 'ar' ? 'بدون صورة غلاف' : 'No banner image'}
              </div>
            )}
          </div>
        </div>

        {/* Tabs: Presets vs Custom Link vs Upload */}
        <div className="flex items-center gap-1 p-2 bg-neutral-950/80 border-b border-neutral-800 px-5 text-xs font-medium">
          <button
            onClick={() => setTab('presets')}
            className={`px-3 py-1.5 rounded transition-colors ${
              tab === 'presets' ? 'bg-neutral-800 text-white font-bold' : 'text-neutral-400 hover:text-white'
            }`}
          >
            {lang === 'ar' ? 'المعرض الجاهز (Presets)' : 'Preset Gallery'}
          </button>
          <button
            onClick={() => setTab('upload')}
            className={`px-3 py-1.5 rounded transition-colors ${
              tab === 'upload' ? 'bg-neutral-800 text-white font-bold' : 'text-neutral-400 hover:text-white'
            }`}
          >
            {lang === 'ar' ? 'رفع صورة من جهازك' : 'Upload File'}
          </button>
          <button
            onClick={() => setTab('custom')}
            className={`px-3 py-1.5 rounded transition-colors ${
              tab === 'custom' ? 'bg-neutral-800 text-white font-bold' : 'text-neutral-400 hover:text-white'
            }`}
          >
            {lang === 'ar' ? 'رابط مباشر (URL)' : 'Direct URL'}
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          {tab === 'presets' && (
            <div className="grid grid-cols-2 gap-3">
              {PRESET_IMAGES.map((preset) => (
                <div
                  key={preset.id}
                  onClick={() => handleApplyPreset(preset.url)}
                  className={`group relative rounded-lg border overflow-hidden cursor-pointer transition-all ${
                    selectedUrl === preset.url
                      ? 'border-emerald-400 ring-2 ring-emerald-400/30'
                      : 'border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div className="h-24 w-full overflow-hidden bg-neutral-950">
                    <img
                      src={preset.url}
                      alt={preset.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="p-2 bg-neutral-900/90 flex items-center justify-between text-xs">
                    <span className="font-semibold text-white text-[11px] truncate">
                      {lang === 'ar' ? preset.name : preset.nameEn}
                    </span>
                    {selectedUrl === preset.url && (
                      <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab === 'upload' && (
            <div className="p-8 border border-dashed border-neutral-700 rounded-xl text-center space-y-3 bg-neutral-950/40">
              <Upload className="w-8 h-8 text-emerald-400 mx-auto" />
              <div>
                <p className="text-sm font-semibold text-white mb-1">
                  {lang === 'ar' ? 'اختر صورة من جهازك الكمبيوتر أو الهاتف' : 'Select an image file from your device'}
                </p>
                <p className="text-xs text-neutral-400">يدعم صيغ PNG و JPG و GIF و WEBP</p>
              </div>
              <label className="inline-block px-4 py-2 bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded-lg font-bold text-xs cursor-pointer transition-colors">
                <span>{lang === 'ar' ? 'تصفح الملفات...' : 'Browse files...'}</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          )}

          {tab === 'custom' && (
            <div className="space-y-3">
              <label className="text-xs text-neutral-400 block">
                {lang === 'ar' ? 'أدخل رابط الصورة المباشر (https://...):' : 'Enter direct image URL:'}
              </label>
              <div className="flex gap-2">
                <input
                  type="url"
                  placeholder="https://example.com/banner.jpg"
                  value={customUrl}
                  onChange={(e) => setCustomUrl(e.target.value)}
                  className="flex-1 bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (customUrl.trim()) setSelectedUrl(customUrl.trim());
                  }}
                  className="px-3 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs font-semibold"
                >
                  {lang === 'ar' ? 'تطبيق الرابط' : 'Apply'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between">
          <button
            onClick={handleRemoveImage}
            className="flex items-center gap-1 text-xs text-neutral-500 hover:text-red-400 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'إزالة الغلاف' : 'Remove Banner'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-1.5 rounded text-xs text-neutral-400 hover:text-white"
            >
              {lang === 'ar' ? 'إلغاء' : 'Cancel'}
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-1.5 rounded bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold text-xs transition-colors shadow-sm"
            >
              {lang === 'ar' ? 'حفظ الصورة الجديدة' : 'Save Image'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
