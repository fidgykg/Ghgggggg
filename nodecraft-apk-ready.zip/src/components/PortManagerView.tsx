import React, { useState } from 'react';
import { Radio, AlertTriangle, CheckCircle, RefreshCw, ArrowUpRight } from 'lucide-react';
import { LocalServer } from '../types/server';
import { Language, I18N } from '../utils/i18n';

interface PortManagerViewProps {
  servers: LocalServer[];
  lang: Language;
}

interface KnownPort {
  port: number;
  service: string;
  category: 'Gaming' | 'Web' | 'Database' | 'System';
  description: string;
}

const KNOWN_PORTS: KnownPort[] = [
  { port: 25565, service: 'Minecraft Java Edition', category: 'Gaming', description: 'المنفذ الافتراضي لسيرفرات ماين كرافت الجافا' },
  { port: 19132, service: 'Minecraft Bedrock / PE', category: 'Gaming', description: 'منفذ نسخ ماين كرافت للجوال وويندوز 10' },
  { port: 8080, service: 'HTTP Local Web Server', category: 'Web', description: 'خوادم الويب وتطبيقات Node.js التجريبية' },
  { port: 3000, service: 'Node.js / React Dev Server', category: 'Web', description: 'بيئات التطوير ومواقع الويب السريعة' },
  { port: 6379, service: 'Redis In-Memory Cache', category: 'Database', description: 'مستودع الكاش وقوائم الجلسات' },
  { port: 5432, service: 'PostgreSQL Relational DB', category: 'Database', description: 'قواعد البيانات العلائقية' },
  { port: 8211, service: 'Palworld Dedicated', category: 'Gaming', description: 'سيرفرات بال ورلد المخصصة' },
  { port: 7777, service: 'Terraria Server', category: 'Gaming', description: 'سيرفرات لعبة تيراريا' },
];

export const PortManagerView: React.FC<PortManagerViewProps> = ({ servers, lang }) => {
  const t = I18N[lang];
  const [testingPort, setTestingPort] = useState<number | null>(null);
  const [testResult, setTestResult] = useState<{ port: number; success: boolean } | null>(null);

  // Group servers by port to detect duplicates
  const portMap = new Map<number, LocalServer[]>();
  servers.forEach((s) => {
    const list = portMap.get(s.port) || [];
    list.push(s);
    portMap.set(s.port, list);
  });

  const handleTestPort = (port: number) => {
    setTestingPort(port);
    setTestResult(null);
    setTimeout(() => {
      setTestingPort(null);
      const isBound = servers.some((s) => s.port === port && s.status === 'online');
      setTestResult({ port, success: isBound });
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-6">
        <h2 className="text-lg font-bold text-white mb-1">
          {lang === 'ar' ? 'خريطة المنافذ والشبكة المحلية (Port Map)' : 'Local Network Port Map'}
        </h2>
        <p className="text-xs text-neutral-400 leading-relaxed max-w-2xl">
          {lang === 'ar'
            ? 'تتبع ومراقبة جميع المنافذ المستخدمة محلياً على جهازك لتفادي التعارض وضمان وصول الأجهزة الأخرى بسلاسة.'
            : 'Monitor local listening ports on your machine to prevent collisions and streamline local access.'}
        </p>
      </div>

      {/* Port Conflict Alerts */}
      {Array.from(portMap.entries())
        .filter(([_, sList]) => sList.length > 1)
        .map(([conflictedPort, sList]) => (
          <div
            key={conflictedPort}
            className="bg-amber-950/30 border border-amber-500/40 rounded-xl p-4 flex items-start gap-3"
          >
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-bold text-amber-300">
                {lang === 'ar' ? `تعارض منافذ نشط على المنفذ :${conflictedPort}` : `Port Conflict Detected on :${conflictedPort}`}
              </div>
              <div className="text-xs text-amber-200/80 mt-1">
                {lang === 'ar'
                  ? `السيرفرات التالية تستخدم نفس المنفذ: ${sList.map((s) => s.name).join(' و ')}. يرجى تغيير منفذ أحدهما.`
                  : `The following servers share this port: ${sList.map((s) => s.name).join(', ')}. Please assign unique ports.`}
              </div>
            </div>
          </div>
        ))}

      {/* Ports Table */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white">
            {lang === 'ar' ? 'سجل المنافذ الشائعة وحالتها الحالية' : 'Standard Ports & Current Binding'}
          </h3>
          <span className="text-xs font-mono text-neutral-400">
            {servers.filter((s) => s.status === 'online').length} {lang === 'ar' ? 'منافذ مفتوحة' : 'Open Ports'}
          </span>
        </div>

        <div className="divide-y divide-neutral-800">
          {KNOWN_PORTS.map((item) => {
            const boundServers = portMap.get(item.port) || [];
            const isOnline = boundServers.some((s) => s.status === 'online');

            return (
              <div
                key={item.port}
                className="p-4 hover:bg-neutral-950/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-16 font-mono font-bold text-sm text-emerald-400 tabular-nums">
                    :{item.port}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white">{item.service}</span>
                      <span className="text-[11px] text-neutral-500 font-mono">({item.category})</span>
                    </div>
                    <div className="text-[11px] text-neutral-400">{item.description}</div>
                  </div>
                </div>

                <div className="flex items-center gap-4 justify-between sm:justify-end">
                  {boundServers.length > 0 ? (
                    <div className="text-start sm:text-end">
                      <div className="font-medium text-white truncate max-w-xs">
                        {boundServers.map((s) => s.name).join(', ')}
                      </div>
                      <div className="text-[11px] font-mono">
                        {isOnline ? (
                          <span className="text-emerald-400">● {t.statusOnline} (Listening)</span>
                        ) : (
                          <span className="text-neutral-500">○ {t.statusOffline} (Bound)</span>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="text-neutral-500 font-mono text-[11px]">
                      {lang === 'ar' ? 'متاح للاستخدام (Free)' : 'Available'}
                    </div>
                  )}

                  <button
                    onClick={() => handleTestPort(item.port)}
                    disabled={testingPort === item.port}
                    className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors flex items-center gap-1 font-mono shrink-0"
                  >
                    <RefreshCw className={`w-3 h-3 ${testingPort === item.port ? 'animate-spin' : ''}`} />
                    <span>{lang === 'ar' ? 'فحص' : 'Check'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {testResult && (
        <div
          className={`p-4 rounded-xl border text-xs font-mono flex items-center justify-between ${
            testResult.success
              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
              : 'bg-neutral-900 border-neutral-800 text-neutral-300'
          }`}
        >
          <span>
            {testResult.success
              ? `[OK] المنفذ :${testResult.port} يستجيب للاتصالات المحلية بنجاح.`
              : `[IDLE] لا توجد خدمة تستمع حالياً على المنفذ :${testResult.port}.`}
          </span>
          <button
            onClick={() => setTestResult(null)}
            className="text-neutral-400 hover:text-white ms-2 text-[11px]"
          >
            إغلاق
          </button>
        </div>
      )}
    </div>
  );
};
