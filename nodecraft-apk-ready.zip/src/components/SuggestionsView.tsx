import React, { useState, useEffect } from 'react';
import {
  Lightbulb,
  Plus,
  ThumbsUp,
  MessageSquare,
  CheckCircle2,
  Clock,
  AlertCircle,
  XCircle,
  Tag,
  Search,
  Filter,
  Trash2,
  User,
  Crown,
  Shield,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Language } from '../utils/i18n';
import { maskEmail } from '../utils/privacy';
import { db } from '../lib/firebase';
import {
  collection,
  addDoc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
  updateDoc,
  doc,
  deleteDoc,
  Timestamp,
} from 'firebase/firestore';

export type SuggestionCategory = 'server' | 'performance' | 'mods_plugins' | 'feature' | 'general';
export type SuggestionStatus = 'pending' | 'in_progress' | 'completed' | 'rejected';

export interface SuggestionItem {
  id: string;
  title: string;
  description: string;
  category: SuggestionCategory;
  authorUid: string;
  authorEmail: string;
  authorName: string;
  authorPhoto?: string;
  status: SuggestionStatus;
  votesCount: number;
  votedUsers: string[];
  adminResponse?: string;
  respondedByEmail?: string;
  respondedAt?: number | null;
  createdAt: number;
}

interface SuggestionsViewProps {
  lang: Language;
}

const CATEGORY_LABELS: Record<SuggestionCategory, { ar: string; en: string; color: string }> = {
  server: { ar: '🎮 سيرفر وماين كرافت', en: 'Server & Game', color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' },
  performance: { ar: '⚡ تسريع وتحسين الأداء', en: 'Performance', color: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
  mods_plugins: { ar: '🧩 مودات وإضافات', en: 'Mods & Plugins', color: 'bg-purple-500/10 text-purple-400 border-purple-500/20' },
  feature: { ar: '💡 ميزات وأفكار جديدة', en: 'New Feature', color: 'bg-sky-500/10 text-sky-400 border-sky-500/20' },
  general: { ar: '💬 اقتراح عام', en: 'General', color: 'bg-neutral-800 text-neutral-300 border-neutral-700' },
};

const STATUS_CONFIG: Record<SuggestionStatus, { ar: string; en: string; color: string; icon: React.ElementType }> = {
  pending: { ar: 'قيد المراجعة', en: 'Pending Review', color: 'bg-yellow-500/15 text-yellow-300 border-yellow-500/30', icon: Clock },
  in_progress: { ar: 'قيد التنفيذ', en: 'In Progress', color: 'bg-sky-500/15 text-sky-300 border-sky-500/30', icon: AlertCircle },
  completed: { ar: 'تم التنفيذ', en: 'Completed', color: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30', icon: CheckCircle2 },
  rejected: { ar: 'مرفوض', en: 'Declined', color: 'bg-rose-500/15 text-rose-300 border-rose-500/30', icon: XCircle },
};

const INITIAL_SUGGESTIONS: SuggestionItem[] = [
  {
    id: 'sug-1',
    title: 'إضافة دعم التحديث التلقائي للبلوجنات بنقرة واحدة من SpigotMC',
    description: 'نقترح توفير زر تحديث تلقائي للبلوجنات المثبتة في مجلد السيرفر مباشرة دون الحاجة لتحميل ملف jar يدوياً في كل مرة ينزل فيها تحديث.',
    category: 'mods_plugins',
    authorUid: 'player-omar',
    authorEmail: 'omar.gamer@nodecraft.local',
    authorName: 'عمر اللاعب',
    authorPhoto: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&auto=format&fit=crop&q=80',
    status: 'in_progress',
    votesCount: 14,
    votedUsers: ['player-omar', 'salem.mod@nodecraft.local'],
    adminResponse: 'اقتراح رائع ومهم جداً! بدأنا بالفعل بالعمل على دمج أداة فحص التحديثات لمجلد plugins وستتوفر قريباً.',
    respondedByEmail: 'ahmedopyj@gmail.com',
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 2,
  },
  {
    id: 'sug-2',
    title: 'تخصيص استهلاك المعالج وتنبيه عند انخفاض TPS عن 18',
    description: 'حبذا لو يتم إضافة جرس تنبيه أو إشعار صوتي عند حدوث لاغ مفاجئ أو نزول الـ TPS في وحدة التحكم.',
    category: 'performance',
    authorUid: 'mod-salem',
    authorEmail: 'salem.mod@nodecraft.local',
    authorName: 'سالم - ضابط الشات',
    authorPhoto: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    status: 'completed',
    votesCount: 22,
    votedUsers: ['mod-salem'],
    adminResponse: 'تم تنفيذ الفكرة! يظهر شريط المقاييس الآن استهلاك المعالج والرام مع كاشف أداء حي.',
    respondedByEmail: 'ahmedopyj@gmail.com',
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 4,
  },
  {
    id: 'sug-3',
    title: 'إضافة سيرفر ديسكورد رسمي وربطه مع شات اللعبة',
    description: 'ربط شات السيرفر ahop508 مع قناة Discord لنتحدث مع اللاعبين داخل وخارج اللعبة في نفس الوقت.',
    category: 'feature',
    authorUid: 'player-omar',
    authorEmail: 'omar.gamer@nodecraft.local',
    authorName: 'عمر اللاعب',
    status: 'pending',
    votesCount: 8,
    votedUsers: [],
    createdAt: Date.now() - 1000 * 60 * 60 * 5,
  },
];

export const SuggestionsView: React.FC<SuggestionsViewProps> = ({ lang }) => {
  const { currentUser, userProfile, isChatModerator, isAdmin, isSuperAdmin } = useAuth();

  const [suggestions, setSuggestions] = useState<SuggestionItem[]>(() => {
    try {
      const saved = localStorage.getItem('ahop508_suggestions');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_SUGGESTIONS;
  });

  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);

  // New suggestion form state
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState<SuggestionCategory>('server');

  // Response input state per suggestion
  const [activeResponseId, setActiveResponseId] = useState<string | null>(null);
  const [responseText, setResponseText] = useState<string>('');

  // Persist locally
  useEffect(() => {
    localStorage.setItem('ahop508_suggestions', JSON.stringify(suggestions));
  }, [suggestions]);

  // Sync with Firestore if active
  useEffect(() => {
    try {
      const q = query(collection(db, 'suggestions'), orderBy('createdAt', 'desc'));
      const unsub = onSnapshot(
        q,
        (snapshot) => {
          if (!snapshot.empty) {
            const list: SuggestionItem[] = [];
            snapshot.forEach((d) => {
              const data = d.data();
              list.push({
                id: d.id,
                title: data.title || '',
                description: data.description || '',
                category: data.category || 'general',
                authorUid: data.authorUid || '',
                authorEmail: data.authorEmail || '',
                authorName: data.authorName || 'عضو',
                authorPhoto: data.authorPhoto,
                status: data.status || 'pending',
                votesCount: data.votesCount || 0,
                votedUsers: data.votedUsers || [],
                adminResponse: data.adminResponse,
                respondedByEmail: data.respondedByEmail,
                respondedAt: data.respondedAt?.toMillis ? data.respondedAt.toMillis() : null,
                createdAt: data.createdAt?.toMillis ? data.createdAt.toMillis() : Date.now(),
              });
            });
            setSuggestions(list);
          }
        },
        (error) => {
          console.warn('Firestore suggestions listener warning:', error.message);
        }
      );
      return () => unsub();
    } catch (err) {
      console.warn('Firestore suggestions attach warning:', err);
    }
  }, []);

  // Submit new suggestion
  const handleSubmitSuggestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDesc.trim()) return;

    if (userProfile?.isBanned) {
      alert(lang === 'ar' ? `حسابك مبند حالياً من إدارة السيرفر (${userProfile.banReason || 'مخالفة الشروط'}). لا يمكنك إضافة اقتراحات.` : 'Your account is banned.');
      return;
    }

    const newSug: SuggestionItem = {
      id: `sug-${Date.now()}`,
      title: newTitle.trim(),
      description: newDesc.trim(),
      category: newCategory,
      authorUid: currentUser?.uid || 'guest-uid',
      authorEmail: currentUser?.email || 'guest@nodecraft.local',
      authorName: currentUser?.displayName || 'عضو المجتمع',
      authorPhoto: currentUser?.photoURL || '',
      status: 'pending',
      votesCount: 1,
      votedUsers: [currentUser?.uid || 'guest-uid'],
      createdAt: Date.now(),
    };

    setSuggestions((prev) => [newSug, ...prev]);
    setIsSubmitModalOpen(false);
    setNewTitle('');
    setNewDesc('');

    try {
      await addDoc(collection(db, 'suggestions'), {
        title: newSug.title,
        description: newSug.description,
        category: newSug.category,
        authorUid: newSug.authorUid,
        authorEmail: newSug.authorEmail,
        authorName: newSug.authorName,
        authorPhoto: newSug.authorPhoto,
        status: newSug.status,
        votesCount: 1,
        votedUsers: [newSug.authorUid],
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      console.warn('Suggestion saved locally:', err);
    }
  };

  // Upvote / Un-vote
  const handleToggleVote = async (sugId: string) => {
    if (userProfile?.isBanned) {
      alert(lang === 'ar' ? 'لا يمكنك التصويت، الحساب مبند بقرار إداري.' : 'You cannot vote because your account is banned.');
      return;
    }

    const uid = currentUser?.uid || 'guest-uid';

    setSuggestions((prev) =>
      prev.map((s) => {
        if (s.id !== sugId) return s;
        const alreadyVoted = s.votedUsers.includes(uid);
        const updatedVoters = alreadyVoted
          ? s.votedUsers.filter((u) => u !== uid)
          : [...s.votedUsers, uid];
        const newCount = updatedVoters.length;

        // Try updating Firestore
        try {
          const docRef = doc(db, 'suggestions', sugId);
          updateDoc(docRef, {
            votesCount: newCount,
            votedUsers: updatedVoters,
          });
        } catch {
          // ignore
        }

        return {
          ...s,
          votesCount: newCount,
          votedUsers: updatedVoters,
        };
      })
    );
  };

  // Moderator/Admin: Update Status
  const handleUpdateStatus = async (sugId: string, newStatus: SuggestionStatus) => {
    if (!isChatModerator) return;

    setSuggestions((prev) =>
      prev.map((s) => (s.id === sugId ? { ...s, status: newStatus } : s))
    );

    try {
      const docRef = doc(db, 'suggestions', sugId);
      await updateDoc(docRef, { status: newStatus });
    } catch {
      // optimistic
    }
  };

  // Moderator/Admin: Submit Response
  const handleSaveResponse = async (sugId: string) => {
    if (!isChatModerator || !responseText.trim()) return;

    setSuggestions((prev) =>
      prev.map((s) =>
        s.id === sugId
          ? {
              ...s,
              adminResponse: responseText.trim(),
              respondedByEmail: currentUser?.email || 'admin',
              respondedAt: Date.now(),
            }
          : s
      )
    );

    try {
      const docRef = doc(db, 'suggestions', sugId);
      await updateDoc(docRef, {
        adminResponse: responseText.trim(),
        respondedByEmail: currentUser?.email || 'admin',
        respondedAt: serverTimestamp(),
      });
    } catch {
      // optimistic
    }

    setActiveResponseId(null);
    setResponseText('');
  };

  // Moderator/Admin: Delete suggestion
  const handleDeleteSuggestion = async (sugId: string) => {
    if (!isChatModerator) return;
    if (confirm('هل أنت متأكد من حذف هذا الاقتراح؟')) {
      setSuggestions((prev) => prev.filter((s) => s.id !== sugId));
      try {
        await deleteDoc(doc(db, 'suggestions', sugId));
      } catch {
        // optimistic
      }
    }
  };

  // Filter & Search
  const filteredSuggestions = suggestions.filter((s) => {
    if (activeFilter !== 'all' && s.status !== activeFilter) return false;
    if (selectedCategory !== 'all' && s.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        s.title.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q) ||
        s.authorName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
            <Lightbulb className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-white tracking-tight">
                {lang === 'ar' ? 'صندوق اقتراحات المجتمع والسيرفر' : 'Community & Server Suggestions'}
              </h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {lang === 'ar' ? 'مفتوح للتصويت' : 'Voting Open'}
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">
              {lang === 'ar'
                ? 'شارك أفكارك لتحسين السيرفر وتطويره، صوّت على اقتراحات الآخرين، وتابع ردود الإدارة وضباط الشات'
                : 'Suggest new features, vote on server improvements, and see management updates'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsSubmitModalOpen(true)}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-xl transition-all shadow-md self-start sm:self-center shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>{lang === 'ar' ? 'إضافة اقتراح جديد' : 'New Suggestion'}</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Status Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 text-xs">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap ${
              activeFilter === 'all'
                ? 'bg-neutral-800 text-white font-semibold'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            {lang === 'ar' ? 'الكل' : 'All'} ({suggestions.length})
          </button>
          <button
            onClick={() => setActiveFilter('pending')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeFilter === 'pending'
                ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40'
                : 'text-neutral-400 hover:text-yellow-400'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'قيد المراجعة' : 'Pending'}</span>
          </button>
          <button
            onClick={() => setActiveFilter('in_progress')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeFilter === 'in_progress'
                ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                : 'text-neutral-400 hover:text-sky-400'
            }`}
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'قيد التنفيذ' : 'In Progress'}</span>
          </button>
          <button
            onClick={() => setActiveFilter('completed')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeFilter === 'completed'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'text-neutral-400 hover:text-emerald-400'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'تم التنفيذ' : 'Completed'}</span>
          </button>
          <button
            onClick={() => setActiveFilter('rejected')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeFilter === 'rejected'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                : 'text-neutral-400 hover:text-rose-400'
            }`}
          >
            <XCircle className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'مرفوض' : 'Declined'}</span>
          </button>
        </div>

        {/* Category & Search */}
        <div className="flex items-center gap-2">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1.5 text-xs text-neutral-300 focus:outline-none focus:border-neutral-700"
          >
            <option value="all">{lang === 'ar' ? 'جميع التصنيفات' : 'All Categories'}</option>
            <option value="server">{lang === 'ar' ? 'سيرفر وماين كرافت' : 'Server & Gameplay'}</option>
            <option value="performance">{lang === 'ar' ? 'تحسين الأداء' : 'Performance'}</option>
            <option value="mods_plugins">{lang === 'ar' ? 'مودات وإضافات' : 'Mods & Plugins'}</option>
            <option value="feature">{lang === 'ar' ? 'ميزات جديدة' : 'New Features'}</option>
            <option value="general">{lang === 'ar' ? 'عام' : 'General'}</option>
          </select>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute start-2.5 top-2.5" />
            <input
              type="text"
              placeholder={lang === 'ar' ? 'بحث في الاقتراحات...' : 'Search...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-neutral-950 border border-neutral-800 rounded-lg ps-8 pe-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-neutral-700 w-36 sm:w-48"
            />
          </div>
        </div>
      </div>

      {/* Suggestions List */}
      <div className="space-y-4">
        {filteredSuggestions.length === 0 ? (
          <div className="py-16 text-center border border-dashed border-neutral-800 rounded-2xl bg-neutral-950/40">
            <Lightbulb className="w-12 h-12 text-neutral-700 mx-auto mb-2" />
            <p className="text-sm font-semibold text-neutral-300">
              {lang === 'ar' ? 'لا توجد اقتراحات مطابقة' : 'No suggestions found'}
            </p>
            <p className="text-xs text-neutral-500 mt-1 mb-4">
              {lang === 'ar'
                ? 'كن أول من يضيف فكرة جديدة لتحسين السيرفر!'
                : 'Submit a new idea to make the server even better!'}
            </p>
            <button
              onClick={() => setIsSubmitModalOpen(true)}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-lg"
            >
              {lang === 'ar' ? 'إضافة اقتراحك الآن' : 'Submit Suggestion'}
            </button>
          </div>
        ) : (
          filteredSuggestions.map((sug) => {
            const cat = CATEGORY_LABELS[sug.category] || CATEGORY_LABELS.general;
            const status = STATUS_CONFIG[sug.status] || STATUS_CONFIG.pending;
            const StatusIcon = status.icon;
            const uid = currentUser?.uid || 'guest-uid';
            const hasVoted = sug.votedUsers?.includes(uid);

            return (
              <div
                key={sug.id}
                className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 hover:border-neutral-700 transition-all shadow-lg flex flex-col md:flex-row items-start gap-4"
              >
                {/* Upvote Button with counter */}
                <button
                  onClick={() => handleToggleVote(sug.id)}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all shrink-0 w-16 ${
                    hasVoted
                      ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 shadow-md shadow-emerald-950/30'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                  }`}
                  title={hasVoted ? 'إلغاء التصويت' : 'تصويت لهذا الاقتراح'}
                >
                  <ThumbsUp className={`w-5 h-5 mb-1 ${hasVoted ? 'text-emerald-400 fill-emerald-500/30' : ''}`} />
                  <span className="text-sm font-bold font-mono">{sug.votesCount}</span>
                  <span className="text-[10px] text-neutral-500">
                    {lang === 'ar' ? 'صوت' : 'votes'}
                  </span>
                </button>

                {/* Content */}
                <div className="flex-1 min-w-0 space-y-2.5">
                  <div className="flex flex-wrap items-center gap-2">
                    {/* Category */}
                    <span className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold border ${cat.color}`}>
                      {lang === 'ar' ? cat.ar : cat.en}
                    </span>

                    {/* Status */}
                    <span className={`px-2.5 py-0.5 rounded-md text-[11px] font-bold border flex items-center gap-1 ${status.color}`}>
                      <StatusIcon className="w-3 h-3" />
                      <span>{lang === 'ar' ? status.ar : status.en}</span>
                    </span>

                    {/* Author & Date */}
                    <span className="text-[11px] text-neutral-500 ms-auto flex items-center gap-1.5">
                      <span>{sug.authorName}</span>
                      <span>•</span>
                      <span>{new Date(sug.createdAt).toLocaleDateString()}</span>
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white tracking-tight">
                    {sug.title}
                  </h3>

                  <p className="text-xs text-neutral-300 leading-relaxed break-words whitespace-pre-wrap">
                    {sug.description}
                  </p>

                  {/* Official Management Response Box */}
                  {sug.adminResponse && (
                    <div className="mt-3 p-3.5 rounded-xl bg-gradient-to-r from-neutral-950 via-neutral-950 to-amber-950/30 border border-amber-500/30 space-y-1.5">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                        <Crown className="w-3.5 h-3.5 text-amber-400" />
                        <span>{lang === 'ar' ? 'رد الإدارة وضباط الشات الرسمي:' : 'Official Admin Response:'}</span>
                        {sug.respondedByEmail && (
                          <span className="text-[10px] font-mono text-neutral-400 font-normal">
                            ({maskEmail(sug.respondedByEmail)})
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-neutral-200 ps-5">
                        {sug.adminResponse}
                      </p>
                    </div>
                  )}

                  {/* Moderator / Admin Inline Controls */}
                  {isChatModerator && (
                    <div className="pt-2 border-t border-neutral-800/80 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-neutral-400 font-medium">
                          {lang === 'ar' ? 'تغيير الحالة:' : 'Set Status:'}
                        </span>
                        <select
                          value={sug.status}
                          onChange={(e) => handleUpdateStatus(sug.id, e.target.value as SuggestionStatus)}
                          className="bg-neutral-950 border border-neutral-700 rounded-lg px-2 py-1 text-xs text-white focus:outline-none focus:border-sky-500"
                        >
                          <option value="pending">{lang === 'ar' ? 'قيد المراجعة' : 'Pending'}</option>
                          <option value="in_progress">{lang === 'ar' ? 'قيد التنفيذ' : 'In Progress'}</option>
                          <option value="completed">{lang === 'ar' ? 'تم التنفيذ' : 'Completed'}</option>
                          <option value="rejected">{lang === 'ar' ? 'مرفوض' : 'Declined'}</option>
                        </select>

                        <button
                          onClick={() => {
                            setActiveResponseId(sug.id);
                            setResponseText(sug.adminResponse || '');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold"
                        >
                          {sug.adminResponse ? (lang === 'ar' ? 'تعديل رد الإدارة' : 'Edit Response') : (lang === 'ar' ? 'إضافة رد رسمي' : 'Add Response')}
                        </button>
                      </div>

                      <button
                        onClick={() => handleDeleteSuggestion(sug.id)}
                        className="text-neutral-400 hover:text-rose-400 p-1.5 rounded-lg hover:bg-rose-500/10 transition-colors"
                        title={lang === 'ar' ? 'حذف الاقتراح' : 'Delete'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {/* Inline Response Form for Moderator */}
                  {activeResponseId === sug.id && (
                    <div className="p-3 bg-neutral-950 rounded-xl border border-amber-500/40 space-y-2 mt-2">
                      <label className="text-xs font-bold text-amber-300 block">
                        {lang === 'ar' ? 'كتابة رد رسمي من الإدارة أو ضابط الشات:' : 'Official Admin Response:'}
                      </label>
                      <textarea
                        rows={2}
                        value={responseText}
                        onChange={(e) => setResponseText(e.target.value)}
                        placeholder={lang === 'ar' ? 'اكتب ملاحظات الإدارة وتفاصيل التنفيذ...' : 'Write official remarks...'}
                        className="w-full bg-neutral-900 border border-neutral-700 rounded-lg p-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                      />
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setActiveResponseId(null)}
                          className="px-3 py-1 text-xs text-neutral-400 hover:text-white"
                        >
                          {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                        </button>
                        <button
                          onClick={() => handleSaveResponse(sug.id)}
                          className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-lg"
                        >
                          {lang === 'ar' ? 'حفظ الرد' : 'Save Response'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* New Suggestion Modal */}
      {isSubmitModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden">
            <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-amber-400" />
                <h2 className="text-base font-bold text-white">
                  {lang === 'ar' ? 'تقديم اقتراح جديد للسيرفر' : 'Submit Server Suggestion'}
                </h2>
              </div>
              <button
                onClick={() => setIsSubmitModalOpen(false)}
                className="text-neutral-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitSuggestion} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {lang === 'ar' ? 'عنوان الاقتراح' : 'Title'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={lang === 'ar' ? 'مثال: إضافة مود Voice Chat الصوتي للعبة' : 'e.g. Add Simple Voice Chat mod'}
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {lang === 'ar' ? 'التصنيف' : 'Category'}
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as SuggestionCategory)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="server">{lang === 'ar' ? '🎮 سيرفر وماين كرافت' : 'Server & Gameplay'}</option>
                  <option value="performance">{lang === 'ar' ? '⚡ تسريع وتحسين الأداء' : 'Performance'}</option>
                  <option value="mods_plugins">{lang === 'ar' ? '🧩 مودات وإضافات' : 'Mods & Plugins'}</option>
                  <option value="feature">{lang === 'ar' ? '💡 ميزات جديدة' : 'New Feature'}</option>
                  <option value="general">{lang === 'ar' ? '💬 اقتراح عام' : 'General'}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {lang === 'ar' ? 'تفاصيل الاقتراح وفائدته' : 'Detailed Description'}
                </label>
                <textarea
                  required
                  rows={4}
                  placeholder={lang === 'ar' ? 'اشرح فكرتك بالتفصيل وكيف تفيد اللاعبين والسيرفر...' : 'Explain your idea in detail...'}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-700 rounded-xl p-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsSubmitModalOpen(false)}
                  className="px-4 py-2 text-xs text-neutral-400 hover:text-white"
                >
                  {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-xl transition-colors"
                >
                  {lang === 'ar' ? 'نشر الاقتراح' : 'Publish Suggestion'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
