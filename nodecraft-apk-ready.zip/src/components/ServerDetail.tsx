import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Square,
  RotateCw,
  Terminal,
  Users,
  Globe,
  Settings,
  Database,
  Share2,
  Archive,
  Trash2,
  Copy,
  Check,
  Send,
  Heart,
  Wifi,
  Shield,
  ShieldAlert,
  ArrowRight,
  RefreshCw,
  ExternalLink,
  Code,
  Layers,
  Save,
  Download,
  Package,
  FolderOpen,
  Image as ImageIcon,
  Cloud,
} from 'lucide-react';
import { LocalServer, ServerPlayer, ServerLog } from '../types/server';
import { Language, I18N } from '../utils/i18n';
import {
  executeMinecraftCommand,
  executeRedisCommand,
  formatUptime,
} from '../utils/storage';
import { PluginsManager } from './PluginsManager';
import { FabricModsManager } from './FabricModsManager';
import { FileManager } from './FileManager';
import { ImagePickerModal } from './ImagePickerModal';
import { PlayitTunnelManager } from './PlayitTunnelManager';
import { ChangeSoftwareModal } from './ChangeSoftwareModal';
import { GoogleDriveBackupModal } from './GoogleDriveBackupModal';

interface ServerDetailProps {
  server: LocalServer;
  onUpdateServer: (updated: LocalServer) => void;
  onDeleteServer: (id: string) => void;
  onStart: (id: string) => void;
  onStop: (id: string) => void;
  onRestart: (id: string) => void;
  lang: Language;
  localIp: string;
}

export const ServerDetail: React.FC<ServerDetailProps> = ({
  server,
  onUpdateServer,
  onDeleteServer,
  onStart,
  onStop,
  onRestart,
  lang,
  localIp,
}) => {
  const t = I18N[lang];
  const [activeTab, setActiveTab] = useState<
    'console' | 'players' | 'plugins' | 'mods' | 'files' | 'preview' | 'database' | 'config' | 'network' | 'backups'
  >('console');
  const [commandInput, setCommandInput] = useState('');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [logFilter, setLogFilter] = useState<'ALL' | 'INFO' | 'WARN' | 'ERROR'>('ALL');
  const [copiedIp, setCopiedIp] = useState(false);

  // Web editor state
  const [webHtml, setWebHtml] = useState(server.webConfig?.htmlContent || '');
  const [webSubTab, setWebSubTab] = useState<'preview' | 'code' | 'api'>('preview');
  const [apiRouteResponse, setApiRouteResponse] = useState<string | null>(null);

  // Snapshot modal/form
  const [snapshotName, setSnapshotName] = useState('');
  const [snapshotDesc, setSnapshotDesc] = useState('');
  const [showSnapshotForm, setShowSnapshotForm] = useState(false);
  const [showImagePicker, setShowImagePicker] = useState(false);
  const [showChangeSoftwareModal, setShowChangeSoftwareModal] = useState(false);
  const [showGoogleDriveModal, setShowGoogleDriveModal] = useState(false);

  const handleSaveBannerImage = (newUrl: string) => {
    onUpdateServer({
      ...server,
      imageBanner: newUrl,
      logs: [
        ...server.logs,
        {
          id: `img-log-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString('en-GB'),
          level: 'INFO',
          message: `[System] Server banner image updated.`,
        },
      ],
    });
  };

  // DB new key form
  const [newDbKey, setNewDbKey] = useState('');
  const [newDbVal, setNewDbVal] = useState('');

  // Terminal autoscroll
  const consoleBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (activeTab === 'console') {
      consoleBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [server.logs, activeTab]);

  // Keep webHtml in sync if server changes
  useEffect(() => {
    if (server.webConfig) {
      setWebHtml(server.webConfig.htmlContent);
    }
  }, [server.id]);

  const fullAddress = `${localIp}:${server.port}`;

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(fullAddress);
    setCopiedIp(true);
    setTimeout(() => setCopiedIp(false), 2000);
  };

  // Run interactive command
  const handleSendCommand = (e?: React.FormEvent, customCmd?: string) => {
    if (e) e.preventDefault();
    const cmd = customCmd || commandInput;
    if (!cmd.trim()) return;

    const time = new Date().toLocaleTimeString('en-GB');

    // Add user command to log
    const userLog: ServerLog = {
      id: `cmd-${Date.now()}`,
      timestamp: time,
      level: 'INFO',
      message: `> ${cmd}`,
    };

    let updated = { ...server, logs: [...server.logs, userLog] };

    if (server.type === 'minecraft') {
      const result = executeMinecraftCommand(updated, cmd);
      const resLog: ServerLog = {
        id: `res-${Date.now()}`,
        timestamp: time,
        level: result.level,
        message: result.response,
      };
      if (result.updatedServer) {
        updated = {
          ...result.updatedServer,
          logs: [...result.updatedServer.logs, userLog, resLog],
        };
      } else {
        updated.logs.push(resLog);
      }
    } else if (server.type === 'database') {
      const result = executeRedisCommand(updated, cmd);
      const resLog: ServerLog = {
        id: `res-${Date.now()}`,
        timestamp: time,
        level: result.level,
        message: result.response,
      };
      if (result.updatedServer) {
        updated = {
          ...result.updatedServer,
          logs: [...result.updatedServer.logs, userLog, resLog],
        };
      } else {
        updated.logs.push(resLog);
      }
    } else {
      // Generic web or game command
      updated.logs.push({
        id: `res-${Date.now()}`,
        timestamp: time,
        level: 'INFO',
        message: `Command executed: ${cmd}`,
      });
    }

    onUpdateServer(updated);
    setCommandHistory((prev) => [cmd, ...prev]);
    setHistoryIndex(-1);
    setCommandInput('');
  };

  const handleClearLogs = () => {
    onUpdateServer({ ...server, logs: [] });
  };

  const handleExportLogs = () => {
    const text = server.logs.map((l) => `[${l.timestamp}] [${l.level}] ${l.message}`).join('\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${server.name.replace(/\s+/g, '_')}_logs.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Player actions
  const handleKickPlayer = (playerName: string) => {
    handleSendCommand(undefined, `/kick ${playerName} Kicked from control dashboard`);
  };

  const handleBanPlayer = (playerName: string) => {
    handleSendCommand(undefined, `/ban ${playerName}`);
  };

  const handleToggleOp = (player: ServerPlayer) => {
    if (player.isOp) {
      handleSendCommand(undefined, `/deop ${player.name}`);
    } else {
      handleSendCommand(undefined, `/op ${player.name}`);
    }
  };

  const handleGiveDiamond = (playerName: string) => {
    handleSendCommand(undefined, `/say تم منح ${playerName} عدد 64 حبة دايموند!`);
  };

  // Save web HTML edits
  const handleSaveWebContent = () => {
    if (!server.webConfig) return;
    const updated: LocalServer = {
      ...server,
      webConfig: {
        ...server.webConfig,
        htmlContent: webHtml,
      },
      logs: [
        ...server.logs,
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString('en-GB'),
          level: 'INFO',
          message: 'Website files updated (index.html modified and reloaded).',
        },
      ],
    };
    onUpdateServer(updated);
  };

  // Test an API route
  const handleTestRoute = (path: string) => {
    const route = server.webConfig?.routes.find((r) => r.path === path);
    const time = new Date().toLocaleTimeString('en-GB');
    const responsePayload = route ? route.response : '{"error": "404 Not Found"}';
    setApiRouteResponse(responsePayload);

    // log request
    const newLogs: ServerLog[] = [
      ...server.logs,
      {
        id: `web-req-${Date.now()}`,
        timestamp: time,
        level: 'INFO',
        message: `GET ${path} 200 OK - 8ms [Local Test Request]`,
      },
    ];
    onUpdateServer({ ...server, logs: newLogs });
  };

  // Create Snapshot
  const handleCreateSnapshot = (e: React.FormEvent) => {
    e.preventDefault();
    if (!snapshotName.trim()) return;

    const newSnapshot = {
      id: `snap-${Date.now()}`,
      name: snapshotName.trim(),
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      sizeMB: Math.floor(server.metrics.memoryUsageMB / 5) + 80,
      serverType: server.type,
      description: snapshotDesc.trim() || 'نقطة استعادة يدوية',
    };

    onUpdateServer({
      ...server,
      backups: [newSnapshot, ...server.backups],
      logs: [
        ...server.logs,
        {
          id: `snap-log-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString('en-GB'),
          level: 'INFO',
          message: `Snapshot created: "${newSnapshot.name}" (${newSnapshot.sizeMB}MB)`,
        },
      ],
    });

    setSnapshotName('');
    setSnapshotDesc('');
    setShowSnapshotForm(false);
  };

  // Restore snapshot
  const handleRestoreSnapshot = (snapName: string) => {
    onUpdateServer({
      ...server,
      logs: [
        ...server.logs,
        {
          id: `restore-log-${Date.now()}`,
          timestamp: new Date().toLocaleTimeString('en-GB'),
          level: 'WARN',
          message: `Server restored to snapshot: "${snapName}" successfully!`,
        },
      ],
    });
  };

  const handleAddDbKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDbKey.trim() || !server.dbConfig) return;
    const currentKeys = server.dbConfig.keys || [];
    const updated: LocalServer = {
      ...server,
      dbConfig: {
        ...server.dbConfig,
        keys: [
          { key: newDbKey.trim(), value: newDbVal.trim(), type: 'string', ttl: -1 },
          ...currentKeys.filter((k) => k.key !== newDbKey.trim()),
        ],
      },
    };

    onUpdateServer(updated);
    setNewDbKey('');
    setNewDbVal('');
  };

  const handleDeleteDbKey = (key: string) => {
    if (!server.dbConfig) return;
    const updated: LocalServer = {
      ...server,
      dbConfig: {
        ...server.dbConfig,
        keys: server.dbConfig.keys.filter((k) => k.key !== key),
      },
    };
    onUpdateServer(updated);
  };

  const filteredLogs = server.logs.filter((log) => {
    if (logFilter === 'ALL') return true;
    return log.level === logFilter;
  });

  return (
    <div className="bg-neutral-900/90 border border-neutral-800 rounded-xl overflow-hidden flex flex-col min-h-[640px]">
      {/* Workstation Header */}
      <div className="p-4 sm:p-6 border-b border-neutral-800 bg-neutral-950/60">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  server.status === 'online'
                    ? 'bg-emerald-400 ring-4 ring-emerald-400/20'
                    : server.status === 'starting'
                    ? 'bg-amber-400 ring-4 ring-amber-400/20 animate-pulse'
                    : 'bg-neutral-600'
                }`}
              />
              <h2 className="text-xl font-bold text-white tracking-tight">{server.name}</h2>
              <span className="text-xs text-neutral-400 font-mono">
                {server.status === 'online' ? t.statusOnline : t.statusOffline}
              </span>
            </div>

            {/* Quiet metadata line without pills */}
            <div className="flex items-center gap-2 text-xs text-neutral-400 font-mono">
              <span>{server.type.toUpperCase()}</span>
              <span>·</span>
              <span className="text-emerald-400">{fullAddress}</span>
              <span>·</span>
              {server.minecraftConfig && (
                <>
                  <span className="text-cyan-400 font-semibold">
                    {server.minecraftConfig.serverSoftware} {server.minecraftConfig.version}
                  </span>
                  <span>·</span>
                </>
              )}
              <span>
                {server.status === 'online'
                  ? formatUptime(server.metrics.uptimeSeconds, lang)
                  : t.statusOffline}
              </span>
            </div>
          </div>

          {/* Quick controls */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setShowChangeSoftwareModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg border border-neutral-800 text-neutral-200 hover:text-white hover:border-emerald-500/60 bg-neutral-900 transition-colors shadow-sm"
              title={lang === 'ar' ? 'تغيير أو تنزيل نظام السيرفر والإصدار' : 'Change or download server software version'}
            >
              <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
              <span>
                {server.minecraftConfig
                  ? `${server.minecraftConfig.serverSoftware} ${server.minecraftConfig.version}`
                  : (lang === 'ar' ? 'تغيير النظام والإصدار' : 'Software Version')}
              </span>
            </button>

            <button
              onClick={handleCopyAddress}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg border border-neutral-800 text-neutral-300 hover:text-white hover:border-neutral-700 bg-neutral-900 transition-colors"
            >
              {copiedIp ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedIp ? t.copied : t.copyAddress}</span>
            </button>

            <button
              onClick={() => setShowImagePicker(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg border border-neutral-800 text-neutral-300 hover:text-white hover:border-neutral-700 bg-neutral-900 transition-colors"
              title={lang === 'ar' ? 'تغيير صورة غلاف السيرفر' : 'Change Server Banner'}
            >
              <ImageIcon className="w-3.5 h-3.5 text-emerald-400" />
              <span>{lang === 'ar' ? 'تغيير الصورة' : 'Change Image'}</span>
            </button>

            {server.status === 'online' ? (
              <>
                <button
                  onClick={() => onRestart(server.id)}
                  title={t.restart}
                  className="p-2 rounded-lg border border-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-800 transition-colors"
                >
                  <RotateCw className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onStop(server.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-red-400 bg-red-950/40 border border-red-900/50 hover:bg-red-900/60 transition-colors"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>{t.stop}</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => onStart(server.id)}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold text-neutral-950 bg-emerald-400 hover:bg-emerald-300 transition-colors shadow-sm"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{t.start}</span>
              </button>
            )}

            <button
              onClick={() => {
                if (window.confirm(t.confirmDelete)) {
                  onDeleteServer(server.id);
                }
              }}
              title={t.deleteServer}
              className="p-2 rounded-lg text-neutral-500 hover:text-red-400 hover:bg-neutral-800 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Workstation Navigation Tabs */}
        <div className="flex items-center gap-1 mt-6 border-b border-neutral-800/80 overflow-x-auto pb-px">
          <button
            onClick={() => setActiveTab('console')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'console'
                ? 'border-emerald-400 text-white font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>{t.console}</span>
          </button>

          {server.type === 'minecraft' && (
            <button
              onClick={() => setActiveTab('players')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
                activeTab === 'players'
                  ? 'border-emerald-400 text-white font-semibold'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>{t.players} ({server.players?.length || 0})</span>
            </button>
          )}

          {/* Plugins Tab (Paper / Spigot / Purpur) */}
          {server.type === 'minecraft' && (
            <button
              onClick={() => setActiveTab('plugins')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
                activeTab === 'plugins'
                  ? 'border-emerald-400 text-white font-semibold'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Package className="w-4 h-4 text-emerald-400" />
              <span>{t.plugins} ({server.plugins?.length || 0})</span>
            </button>
          )}

          {/* Fabric Mods Tab */}
          {server.type === 'minecraft' && (
            <button
              onClick={() => setActiveTab('mods')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
                activeTab === 'mods'
                  ? 'border-cyan-400 text-white font-semibold'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>{t.mods} ({server.mods?.length || 0})</span>
            </button>
          )}

          {/* File Manager & Opener (Available for all servers) */}
          <button
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'files'
                ? 'border-emerald-400 text-white font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <FolderOpen className="w-4 h-4 text-emerald-400" />
            <span>{t.files} ({server.files?.length || 0})</span>
          </button>

          {server.type === 'web' && (
            <button
              onClick={() => setActiveTab('preview')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
                activeTab === 'preview'
                  ? 'border-emerald-400 text-white font-semibold'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Globe className="w-4 h-4" />
              <span>{t.preview}</span>
            </button>
          )}

          {server.type === 'database' && (
            <button
              onClick={() => setActiveTab('database')}
              className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
                activeTab === 'database'
                  ? 'border-emerald-400 text-white font-semibold'
                  : 'border-transparent text-neutral-400 hover:text-neutral-200'
              }`}
            >
              <Database className="w-4 h-4" />
              <span>{t.database} ({server.dbConfig?.keys.length || 0})</span>
            </button>
          )}

          <button
            onClick={() => setActiveTab('config')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'config'
                ? 'border-emerald-400 text-white font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>{t.config}</span>
          </button>

          <button
            onClick={() => setActiveTab('network')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'network'
                ? 'border-emerald-400 text-white font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Share2 className="w-4 h-4" />
            <span>{t.network}</span>
          </button>

          <button
            onClick={() => setActiveTab('backups')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === 'backups'
                ? 'border-emerald-400 text-white font-semibold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Archive className="w-4 h-4" />
            <span>{t.backups} ({server.backups.length})</span>
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 p-4 sm:p-6 flex flex-col">
        {/* 1. CONSOLE TAB */}
        {activeTab === 'console' && (
          <div className="flex-1 flex flex-col">
            {/* Terminal Top Bar */}
            <div className="flex items-center justify-between mb-2 text-xs">
              <div className="flex items-center gap-2">
                <span className="text-neutral-400">{t.console}:</span>
                <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded border border-neutral-800">
                  {(['ALL', 'INFO', 'WARN', 'ERROR'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => setLogFilter(lvl)}
                      className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                        logFilter === lvl
                          ? 'bg-neutral-800 text-white font-semibold'
                          : 'text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      {lvl === 'ALL' ? t.filterAll : lvl}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleClearLogs}
                  className="px-2.5 py-1 rounded text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                >
                  {t.clearLogs}
                </button>
                <button
                  onClick={handleExportLogs}
                  className="flex items-center gap-1 px-2.5 py-1 rounded text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{t.exportLogs}</span>
                </button>
              </div>
            </div>

            {/* Terminal Window */}
            <div className="flex-1 bg-neutral-950 border border-neutral-800 rounded-lg p-3 sm:p-4 font-mono text-xs overflow-y-auto max-h-[380px] min-h-[300px] select-text">
              {filteredLogs.length === 0 ? (
                <div className="text-neutral-600 italic py-8 text-center">
                  {lang === 'ar' ? 'لا توجد سجلات حالياً.' : 'No logs recorded.'}
                </div>
              ) : (
                filteredLogs.map((log) => (
                  <div key={log.id} className="leading-relaxed mb-1 flex items-start gap-2">
                    <span className="text-neutral-500 shrink-0 select-none">[{log.timestamp}]</span>
                    <span
                      className={`shrink-0 font-semibold ${
                        log.level === 'WARN'
                          ? 'text-amber-400'
                          : log.level === 'ERROR'
                          ? 'text-red-400'
                          : log.level === 'SYSTEM'
                          ? 'text-purple-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      [{log.level}]
                    </span>
                    <span
                      className={`break-all ${
                        log.message.startsWith('>')
                          ? 'text-cyan-300 font-semibold'
                          : log.level === 'ERROR'
                          ? 'text-red-300'
                          : log.level === 'WARN'
                          ? 'text-amber-200'
                          : 'text-neutral-300'
                      }`}
                    >
                      {log.message}
                    </span>
                  </div>
                ))
              )}
              <div ref={consoleBottomRef} />
            </div>

            {/* Quick Command Suggestions */}
            <div className="mt-3 flex items-center gap-1.5 flex-wrap">
              <span className="text-xs text-neutral-400 me-1">{t.quickCommands}:</span>
              {server.type === 'minecraft' ? (
                <>
                  {['/tps', '/seed', '/time set day', '/weather clear', '/help'].map((cmd) => (
                    <button
                      key={cmd}
                      onClick={() => handleSendCommand(undefined, cmd)}
                      className="px-2 py-0.5 rounded bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white font-mono text-xs transition-colors border border-neutral-700/50"
                    >
                      {cmd}
                    </button>
                  ))}
                </>
              ) : server.type === 'database' ? (
                <>
                  {['PING', 'KEYS *', 'DBSIZE', 'SET welcome "Hello from Redis"', 'GET welcome'].map((cmd) => (
                    <button
                      key={cmd}
                      onClick={() => handleSendCommand(undefined, cmd)}
                      className="px-2 py-0.5 rounded bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white font-mono text-xs transition-colors border border-neutral-700/50"
                    >
                      {cmd}
                    </button>
                  ))}
                </>
              ) : (
                <>
                  {['GET /', 'GET /api/status', 'GET /api/ping'].map((cmd) => (
                    <button
                      key={cmd}
                      onClick={() => handleSendCommand(undefined, cmd)}
                      className="px-2 py-0.5 rounded bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white font-mono text-xs transition-colors border border-neutral-700/50"
                    >
                      {cmd}
                    </button>
                  ))}
                </>
              )}
            </div>

            {/* Command Input Form */}
            <form onSubmit={handleSendCommand} className="mt-3 flex items-center gap-2">
              <div className="relative flex-1">
                <span className="absolute start-3 top-1/2 -translate-y-1/2 font-mono text-neutral-500 text-xs">
                  &gt;
                </span>
                <input
                  type="text"
                  value={commandInput}
                  onChange={(e) => setCommandInput(e.target.value)}
                  placeholder={t.typeCommandPrompt}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg py-2.5 ps-7 pe-4 text-xs font-mono text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500/80 transition-colors"
                />
              </div>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-semibold transition-colors shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{t.runCommand}</span>
              </button>
            </form>
          </div>
        )}

        {/* 2. PLAYERS TAB (Minecraft / Game servers) */}
        {activeTab === 'players' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-white">{t.activePlayers}</h3>
                <p className="text-xs text-neutral-400">
                  {lang === 'ar'
                    ? 'إدارة اللاعبين المتصلين حالياً عبر شبكة ماين كرافت المحلية'
                    : 'Manage players connected on the local Minecraft network'}
                </p>
              </div>
              <div className="text-xs font-mono text-neutral-400">
                {server.players?.length || 0} / {server.minecraftConfig?.maxPlayers || 20}
              </div>
            </div>

            {(!server.players || server.players.length === 0) ? (
              <div className="py-12 text-center border border-dashed border-neutral-800 rounded-xl">
                <Users className="w-8 h-8 text-neutral-600 mx-auto mb-2" />
                <p className="text-sm text-neutral-400">{t.noPlayersOnline}</p>
                <p className="text-xs text-neutral-500 mt-1">
                  {lang === 'ar'
                    ? 'قم بتشغيل السيرفر والدخول عبر ماين كرافت بعنوان: '
                    : 'Start the server and join via Minecraft at: '}
                  <span className="font-mono text-emerald-400">{fullAddress}</span>
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {server.players.map((player) => (
                  <div
                    key={player.id}
                    className="bg-neutral-950 border border-neutral-800 rounded-lg p-4 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded bg-emerald-950/60 border border-emerald-800/40 flex items-center justify-center font-mono font-bold text-emerald-400 text-sm">
                            {player.name[0].toUpperCase()}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-sm font-semibold text-white">{player.name}</span>
                              {player.isOp && (
                                <span className="text-[10px] text-amber-400 font-mono font-bold">
                                  [OP]
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-neutral-500 font-mono">
                              {player.gamemode} · joined {player.joinedAt}
                            </span>
                          </div>
                        </div>

                        {/* Ping indicator */}
                        <div className="flex items-center gap-1 text-xs font-mono text-emerald-400">
                          <Wifi className="w-3.5 h-3.5" />
                          <span>{player.ping}ms</span>
                        </div>
                      </div>

                      {/* Health Bar (Minecraft Hearts) */}
                      <div className="flex items-center gap-2 mb-3 bg-neutral-900/60 p-2 rounded">
                        <Heart className="w-3.5 h-3.5 text-red-500 fill-current" />
                        <div className="flex-1 h-2 bg-neutral-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-red-500 rounded-full transition-all"
                            style={{ width: `${(player.health / 20) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs font-mono text-neutral-400 tabular-nums">
                          {player.health}/20
                        </span>
                      </div>
                    </div>

                    {/* Player Action Buttons */}
                    <div className="flex items-center gap-1.5 flex-wrap pt-2 border-t border-neutral-800/60">
                      <button
                        onClick={() => handleToggleOp(player)}
                        className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                          player.isOp
                            ? 'bg-amber-950/40 text-amber-400 hover:bg-amber-900/50'
                            : 'bg-neutral-800 text-neutral-300 hover:text-white'
                        }`}
                      >
                        {player.isOp ? t.revokeOp : t.makeOp}
                      </button>

                      <button
                        onClick={() => handleGiveDiamond(player.name)}
                        className="px-2.5 py-1 rounded bg-cyan-950/40 text-cyan-400 hover:bg-cyan-900/50 text-xs transition-colors"
                      >
                        {lang === 'ar' ? 'إعطاء دايموند 💎' : 'Give Diamond'}
                      </button>

                      <button
                        onClick={() => handleKickPlayer(player.name)}
                        className="px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs transition-colors"
                      >
                        {t.kickPlayer}
                      </button>

                      <button
                        onClick={() => handleBanPlayer(player.name)}
                        className="px-2 py-1 rounded bg-red-950/40 text-red-400 hover:bg-red-900/50 text-xs transition-colors"
                      >
                        {t.banPlayer}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 2.1 PLUGINS TAB (Paper / Spigot / Purpur) */}
        {activeTab === 'plugins' && (
          <PluginsManager
            server={server}
            onUpdateServer={onUpdateServer}
            lang={lang}
          />
        )}

        {/* 2.2 FABRIC MODS TAB */}
        {activeTab === 'mods' && (
          <FabricModsManager
            server={server}
            onUpdateServer={onUpdateServer}
            lang={lang}
          />
        )}

        {/* 2.3 FILE EXPLORER & EDITOR TAB (All Servers) */}
        {activeTab === 'files' && (
          <FileManager
            server={server}
            onUpdateServer={onUpdateServer}
            lang={lang}
          />
        )}

        {/* 3. WEB PREVIEW TAB (Local Web server) */}
        {activeTab === 'preview' && (
          <div className="flex-1 flex flex-col space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-white">{t.websitePreviewDesc}</h3>
                <span className="text-xs font-mono text-emerald-400">
                  http://localhost:{server.port} · http://{fullAddress}
                </span>
              </div>

              {/* Subtabs: Preview vs Code Editor vs API Tester */}
              <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-lg border border-neutral-800">
                <button
                  onClick={() => setWebSubTab('preview')}
                  className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                    webSubTab === 'preview' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {t.livePreviewTab}
                </button>
                <button
                  onClick={() => setWebSubTab('code')}
                  className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                    webSubTab === 'code' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {t.htmlEditorTab}
                </button>
                <button
                  onClick={() => setWebSubTab('api')}
                  className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                    webSubTab === 'api' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {t.simulateRequest}
                </button>
              </div>
            </div>

            {/* SubTab 1: Live Iframe Preview */}
            {webSubTab === 'preview' && (
              <div className="flex-1 border border-neutral-800 rounded-lg overflow-hidden bg-neutral-950 flex flex-col min-h-[360px]">
                {/* Fake browser address bar */}
                <div className="bg-neutral-900 px-3 py-2 border-b border-neutral-800 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                    <span className="font-mono text-neutral-400 ms-2">
                      http://{localIp}:{server.port}/
                    </span>
                  </div>
                  <span className="text-[11px] text-emerald-400 font-mono">200 OK</span>
                </div>
                <iframe
                  title="Local Web Server Preview"
                  srcDoc={server.webConfig?.htmlContent || webHtml}
                  className="w-full flex-1 border-0 min-h-[350px] bg-neutral-950"
                  sandbox="allow-scripts"
                />
              </div>
            )}

            {/* SubTab 2: HTML & Code Editor */}
            {webSubTab === 'code' && (
              <div className="flex-1 flex flex-col space-y-3">
                <div className="flex items-center justify-between text-xs text-neutral-400">
                  <span>ملف: <code className="text-emerald-400">/var/www/html/index.html</code></span>
                  <button
                    onClick={handleSaveWebContent}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold rounded text-xs transition-colors"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{t.saveChanges}</span>
                  </button>
                </div>
                <textarea
                  value={webHtml}
                  onChange={(e) => setWebHtml(e.target.value)}
                  className="w-full flex-1 min-h-[320px] bg-neutral-950 border border-neutral-800 rounded-lg p-3 font-mono text-xs text-neutral-200 focus:outline-none focus:border-emerald-500/80 resize-y"
                  spellCheck={false}
                />
              </div>
            )}

            {/* SubTab 3: API Tester */}
            {webSubTab === 'api' && (
              <div className="space-y-4">
                <div className="text-xs text-neutral-400">
                  {lang === 'ar'
                    ? 'قم باختبار مسارات الـ API المدعومة في خادم الويب المحلي:'
                    : 'Test the supported API endpoints on the local web server:'}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {server.webConfig?.routes.map((route) => (
                    <button
                      key={route.path}
                      onClick={() => handleTestRoute(route.path)}
                      className="bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 p-3 rounded-lg text-start transition-colors"
                    >
                      <div className="font-mono text-emerald-400 text-xs font-bold mb-1">
                        {route.method} {route.path}
                      </div>
                      <div className="text-[11px] text-neutral-400 truncate">
                        {route.response}
                      </div>
                    </button>
                  ))}
                </div>

                {apiRouteResponse && (
                  <div className="mt-4 p-4 rounded-lg bg-neutral-950 border border-neutral-800 font-mono text-xs">
                    <div className="text-neutral-500 mb-1">// API Response:</div>
                    <pre className="text-emerald-400">{apiRouteResponse}</pre>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* 4. DATABASE & REDIS TAB */}
        {activeTab === 'database' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-white">{t.database} (Redis Key-Value)</h3>
                <p className="text-xs text-neutral-400">
                  {lang === 'ar'
                    ? 'استعراض وإضافة المفاتيح المخزنة في الذاكرة'
                    : 'Explore and insert in-memory cache keys'}
                </p>
              </div>
              <span className="text-xs font-mono text-neutral-400">
                Port :{server.port} · {server.dbConfig?.keys.length || 0} Keys
              </span>
            </div>

            {/* Add Key Form */}
            <form onSubmit={handleAddDbKey} className="flex gap-2 items-center flex-wrap">
              <input
                type="text"
                placeholder="Key (مثال: session:token)"
                value={newDbKey}
                onChange={(e) => setNewDbKey(e.target.value)}
                className="bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs font-mono text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
              <input
                type="text"
                placeholder="Value (مثال: active_user_123)"
                value={newDbVal}
                onChange={(e) => setNewDbVal(e.target.value)}
                className="flex-1 bg-neutral-950 border border-neutral-800 rounded px-3 py-1.5 text-xs font-mono text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
              <button
                type="submit"
                className="px-3 py-1.5 rounded bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-semibold text-xs transition-colors"
              >
                + SET Key
              </button>
            </form>

            {/* Keys Table */}
            <div className="border border-neutral-800 rounded-lg overflow-hidden bg-neutral-950">
              <table className="w-full text-start text-xs font-mono">
                <thead className="bg-neutral-900 border-b border-neutral-800 text-neutral-400">
                  <tr>
                    <th className="py-2.5 px-3 text-start">Key</th>
                    <th className="py-2.5 px-3 text-start">Type</th>
                    <th className="py-2.5 px-3 text-start">Value</th>
                    <th className="py-2.5 px-3 text-end">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-800/60">
                  {(!server.dbConfig || server.dbConfig.keys.length === 0) ? (
                    <tr>
                      <td colSpan={4} className="py-6 text-center text-neutral-500 italic">
                        (empty database)
                      </td>
                    </tr>
                  ) : (
                    server.dbConfig.keys.map((k) => (
                      <tr key={k.key} className="hover:bg-neutral-900/50 transition-colors">
                        <td className="py-2 px-3 text-emerald-400 font-bold">{k.key}</td>
                        <td className="py-2 px-3 text-neutral-400">{k.type}</td>
                        <td className="py-2 px-3 text-neutral-200 truncate max-w-xs">{k.value}</td>
                        <td className="py-2 px-3 text-end">
                          <button
                            onClick={() => handleDeleteDbKey(k.key)}
                            className="text-red-400 hover:text-red-300 text-xs px-2 py-0.5 rounded hover:bg-red-950/40 transition-colors"
                          >
                            DEL
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* 5. CONFIG TAB */}
        {activeTab === 'config' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-white">
                  {server.type === 'minecraft' ? 'server.properties' : 'Configuration File'}
                </h3>
                <p className="text-xs text-neutral-400">
                  {lang === 'ar'
                    ? 'إعدادات وخيارات تشغيل السيرفر الأساسية'
                    : 'Core server configuration and launch flags'}
                </p>
              </div>
              <button
                onClick={() => {
                  alert(lang === 'ar' ? 'تم حفظ التغييرات بنجاح!' : 'Configuration updated successfully!');
                }}
                className="flex items-center gap-1 px-3 py-1.5 rounded bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold text-xs transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{t.saveChanges}</span>
              </button>
            </div>

            {/* System Software & Version Banner */}
            <div className="bg-neutral-950 border border-neutral-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-neutral-400">
                      {lang === 'ar' ? 'نظام السيرفر والإصدار المنزّل:' : 'Active Software & Downloaded Version:'}
                    </span>
                    <span className="text-xs font-mono font-bold text-white bg-neutral-900 px-2 py-0.5 rounded border border-neutral-800">
                      {server.minecraftConfig?.serverSoftware || (server.type === 'web' ? server.webConfig?.framework : 'Redis')} {server.minecraftConfig?.version || 'Latest'}
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-500 font-mono mt-0.5 flex items-center gap-2">
                    <span>
                      {lang === 'ar' ? 'الملف التنفيذي:' : 'Binary:'} {server.files?.find(f => f.name.endsWith('.jar') || f.name.endsWith('.zip'))?.name || (server.type === 'minecraft' ? 'paper-server.jar' : 'app.js')}
                    </span>
                    <span>·</span>
                    <span className="text-emerald-400">
                      {lang === 'ar' ? 'جاهز ومحدث' : 'Up to date'}
                    </span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowChangeSoftwareModal(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-semibold text-xs transition-colors shrink-0 border border-neutral-700 hover:border-emerald-500/40"
              >
                <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
                <span>
                  {lang === 'ar'
                    ? 'تغيير النظام أو تنزيل إصدار آخر'
                    : 'Change Software or Download Version'}
                </span>
              </button>
            </div>

            {server.type === 'minecraft' && server.minecraftConfig ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs text-neutral-400">MOTD (رسالة السيرفر):</label>
                  <input
                    type="text"
                    value={server.minecraftConfig.motd}
                    onChange={(e) => {
                      const updated = { ...server };
                      if (updated.minecraftConfig) updated.minecraftConfig.motd = e.target.value;
                      onUpdateServer(updated);
                    }}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-neutral-400">الحد الأقصى للاعبين (Max Players):</label>
                  <input
                    type="number"
                    value={server.minecraftConfig.maxPlayers}
                    onChange={(e) => {
                      const updated = { ...server };
                      if (updated.minecraftConfig)
                        updated.minecraftConfig.maxPlayers = Number(e.target.value);
                      onUpdateServer(updated);
                    }}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-neutral-400">صعوبة اللعبة (Difficulty):</label>
                  <select
                    value={server.minecraftConfig.difficulty}
                    onChange={(e) => {
                      const updated = { ...server };
                      if (updated.minecraftConfig)
                        updated.minecraftConfig.difficulty = e.target.value as any;
                      onUpdateServer(updated);
                    }}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white"
                  >
                    <option value="peaceful">Peaceful (سلمي)</option>
                    <option value="easy">Easy (سهل)</option>
                    <option value="normal">Normal (عادي)</option>
                    <option value="hard">Hard (صعب)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-neutral-400">نمط اللعبة (Gamemode):</label>
                  <select
                    value={server.minecraftConfig.gamemode}
                    onChange={(e) => {
                      const updated = { ...server };
                      if (updated.minecraftConfig)
                        updated.minecraftConfig.gamemode = e.target.value as any;
                      onUpdateServer(updated);
                    }}
                    className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white"
                  >
                    <option value="survival">Survival (سرفايفل)</option>
                    <option value="creative">Creative (إبداعي)</option>
                    <option value="adventure">Adventure (مغامرة)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-neutral-400">ميزة القتال بين اللاعبين (PvP):</label>
                  <div className="flex items-center gap-3 pt-1">
                    <label className="flex items-center gap-2 text-xs text-neutral-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={server.minecraftConfig.pvp}
                        onChange={(e) => {
                          const updated = { ...server };
                          if (updated.minecraftConfig)
                            updated.minecraftConfig.pvp = e.target.checked;
                          onUpdateServer(updated);
                        }}
                      />
                      <span>تفعيل الـ PvP</span>
                    </label>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-neutral-400">وضع الأونلاين (Online Mode):</label>
                  <div className="flex items-center gap-3 pt-1">
                    <label className="flex items-center gap-2 text-xs text-neutral-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={server.minecraftConfig.onlineMode}
                        onChange={(e) => {
                          const updated = { ...server };
                          if (updated.minecraftConfig)
                            updated.minecraftConfig.onlineMode = e.target.checked;
                          onUpdateServer(updated);
                        }}
                      />
                      <span>التحقق من حسابات Mojang (تعطيلها يتيح اللعب عبر الشبكة المحلية دون إنترنت)</span>
                    </label>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-neutral-950 p-4 border border-neutral-800 rounded-lg font-mono text-xs text-neutral-300">
                <p>PORT={server.port}</p>
                <p>AUTO_RESTART={server.autoRestart ? 'true' : 'false'}</p>
                <p>ALLOCATED_RAM_MB={server.allocatedRamMB}</p>
              </div>
            )}
          </div>
        )}

        {/* 6. NETWORK & LAN TAB */}
        {activeTab === 'network' && (
          <div className="space-y-6">
            {/* playit.gg Tunnel & Global IP Manager */}
            <PlayitTunnelManager
              server={server}
              onUpdateServer={onUpdateServer}
              lang={lang}
            />

            <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-5">
              <div className="flex items-start gap-3">
                <Wifi className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-sm font-bold text-white mb-1">{t.lanTitle}</h3>
                  <p className="text-xs text-neutral-300 leading-relaxed mb-3">{t.lanDesc}</p>
                  <div className="flex items-center gap-2 bg-neutral-950 p-2.5 rounded-lg border border-neutral-800 font-mono text-sm text-emerald-400">
                    <span className="flex-1 select-all">{fullAddress}</span>
                    <button
                      onClick={handleCopyAddress}
                      className="px-3 py-1 bg-emerald-400 hover:bg-emerald-300 text-neutral-950 rounded font-semibold text-xs transition-colors flex items-center gap-1"
                    >
                      {copiedIp ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedIp ? t.copied : t.copyAddress}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Tunnel & Online Play Guide */}
            <div className="border border-neutral-800 rounded-xl p-5 bg-neutral-950/40">
              <h4 className="text-sm font-semibold text-white mb-2">{t.tunnelGuide}</h4>
              <p className="text-xs text-neutral-400 leading-relaxed mb-4">
                {lang === 'ar'
                  ? 'إذا أردت دعوة أصدقاء خارج شبكة منزلك، يمكنك استخدام نفق مجاني مثل ngrok أو cloudflared أو playit.gg:'
                  : 'To invite friends from outside your home network, you can use a free TCP tunnel:'}
              </p>

              <div className="space-y-3 font-mono text-xs">
                <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
                  <div className="text-neutral-500 mb-1"># طريقة 1: باستخدام ngrok (TCP Tunnel)</div>
                  <code className="text-cyan-300">
                    ngrok {server.type === 'web' ? 'http' : 'tcp'} {server.port}
                  </code>
                </div>

                <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-800">
                  <div className="text-neutral-500 mb-1"># طريقة 2: Cloudflare Tunnel</div>
                  <code className="text-cyan-300">
                    cloudflared tunnel --url {server.type === 'web' ? `http://localhost:${server.port}` : `tcp://localhost:${server.port}`}
                  </code>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 7. BACKUPS TAB */}
        {activeTab === 'backups' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-white">{t.backups}</h3>
                <p className="text-xs text-neutral-400">
                  {lang === 'ar'
                    ? 'نقاط استعادة العالم وملفات التكوين لحماية سيرفرك من التلف أو الأخطاء'
                    : 'World snapshots & configs to safeguard your local server'}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowGoogleDriveModal(true)}
                  className="px-3 py-1.5 rounded-lg bg-blue-500/15 hover:bg-blue-500/25 border border-blue-500/30 text-blue-400 font-semibold text-xs transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <Cloud className="w-3.5 h-3.5" />
                  <span>{lang === 'ar' ? 'سحابة Google Drive' : 'Google Drive Cloud'}</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
                </button>
                <button
                  onClick={() => setShowSnapshotForm(!showSnapshotForm)}
                  className="px-3 py-1.5 rounded bg-emerald-400 hover:bg-emerald-300 text-neutral-950 font-bold text-xs transition-colors"
                >
                  + {t.createBackup}
                </button>
              </div>
            </div>

            {showSnapshotForm && (
              <form
                onSubmit={handleCreateSnapshot}
                className="bg-neutral-950 border border-neutral-800 p-4 rounded-xl space-y-3"
              >
                <div>
                  <label className="text-xs text-neutral-400 mb-1 block">{t.backupName}:</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: قبل تجربة المود الجديد"
                    value={snapshotName}
                    onChange={(e) => setSnapshotName(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs text-neutral-400 mb-1 block">{t.backupDesc}:</label>
                  <input
                    type="text"
                    placeholder="ملاحظات حول النسخة..."
                    value={snapshotDesc}
                    onChange={(e) => setSnapshotDesc(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded px-3 py-2 text-xs text-white"
                  />
                </div>
                <div className="flex gap-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setShowSnapshotForm(false)}
                    className="px-3 py-1.5 rounded text-xs text-neutral-400 hover:text-white"
                  >
                    {t.cancel}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded bg-emerald-400 text-neutral-950 font-bold text-xs"
                  >
                    {t.create}
                  </button>
                </div>
              </form>
            )}

            <div className="space-y-2">
              {server.backups.length === 0 ? (
                <div className="py-8 text-center text-neutral-500 italic border border-neutral-800 rounded-lg">
                  {lang === 'ar' ? 'لا توجد نسخ احتياطية محفوظة لهذا السيرفر.' : 'No snapshots created yet.'}
                </div>
              ) : (
                server.backups.map((bak) => (
                  <div
                    key={bak.id}
                    className="bg-neutral-950 border border-neutral-800 p-3.5 rounded-lg flex items-center justify-between"
                  >
                    <div>
                      <div className="text-sm font-semibold text-white mb-0.5">{bak.name}</div>
                      <div className="flex items-center gap-2 text-xs text-neutral-500 font-mono">
                        <span>{bak.createdAt}</span>
                        <span>·</span>
                        <span>{bak.sizeMB} MB</span>
                        {bak.description && (
                          <>
                            <span>·</span>
                            <span className="text-neutral-400">{bak.description}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => handleRestoreSnapshot(bak.name)}
                      className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold transition-colors"
                    >
                      {t.restoreBackup}
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Image Picker Modal */}
      <ImagePickerModal
        isOpen={showImagePicker}
        onClose={() => setShowImagePicker(false)}
        currentImage={server.imageBanner}
        onSaveImage={handleSaveBannerImage}
        serverName={server.name}
        lang={lang}
      />

      {/* Change Software & Version Modal */}
      <ChangeSoftwareModal
        isOpen={showChangeSoftwareModal}
        onClose={() => setShowChangeSoftwareModal(false)}
        server={server}
        onUpdateServer={onUpdateServer}
        lang={lang}
      />

      {/* Google Drive Cloud Backup & Sync Modal */}
      <GoogleDriveBackupModal
        isOpen={showGoogleDriveModal}
        onClose={() => setShowGoogleDriveModal(false)}
        server={server}
        onUpdateServer={onUpdateServer}
        lang={lang}
      />
    </div>
  );
};
