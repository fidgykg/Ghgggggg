import React, { useState } from 'react';
import { Layers, Plus, ToggleLeft, ToggleRight, Trash2, Download, Search, Check, Cpu, Zap, Radio } from 'lucide-react';
import { LocalServer, FabricMod } from '../types/server';
import { Language, I18N } from '../utils/i18n';
import { ensureFullServerFiles } from '../utils/fileHelpers';

interface FabricModsManagerProps {
  server: LocalServer;
  onUpdateServer: (updated: LocalServer) => void;
  lang: Language;
}

const FABRIC_CATALOG: Omit<FabricMod, 'id' | 'enabled'>[] = [
  {
    name: 'Fabric API',
    fileName: 'fabric-api-0.100.1+1.21.jar',
    version: '0.100.1',
    author: 'FabricMC',
    description: 'المكتبة الأساسية المشتركة لتشغيل وربط جميع مودات فابريك على السيرفر.',
    side: 'both',
    fileSizeMB: 2.4,
  },
  {
    name: 'Lithium',
    fileName: 'lithium-fabric-0.12.7.jar',
    version: '0.12.7',
    author: 'CaffeineMC',
    description: 'مود تسريع وتوليد وحسابات الفيزياء والذكاء الاصطناعي للأعداء لرفع الـ TPS إلى أقصى حد.',
    side: 'server',
    fileSizeMB: 0.8,
  },
  {
    name: 'FerriteCore',
    fileName: 'ferritecore-6.0.3-fabric.jar',
    version: '6.0.3',
    author: 'malte0811',
    description: 'تقليص استهلاك الذاكرة (RAM) بنسبة تصل إلى 40% وضغط استهلاك السيرفر.',
    side: 'both',
    fileSizeMB: 0.3,
  },
  {
    name: 'Simple Voice Chat',
    fileName: 'voicechat-fabric-1.21-2.5.15.jar',
    version: '2.5.15',
    author: 'henkelmax',
    description: 'نظام شات صوتي تقاربي ثلاثي الأبعاد مجاني داخل اللعبة للتحدث مع أصدقائك في نفس العالم.',
    side: 'both',
    fileSizeMB: 5.6,
  },
  {
    name: 'Terralith',
    fileName: 'Terralith_1.21_v2.5.4.jar',
    version: '2.5.4',
    author: 'Stardust Labs',
    description: 'إضافة ما يزيد عن 85 منطقة حيوية وجبال ضخمة وعوالم فريدة دون الحاجة لتثبيت مودات على جهاز اللاعب!',
    side: 'both',
    fileSizeMB: 8.2,
  },
  {
    name: 'Waystones',
    fileName: 'waystones-fabric-1.21-14.1.3.jar',
    version: '14.1.3',
    author: 'BlayTheNinth',
    description: 'أحجار الانتقال الآني بين القواعد والقرى لحفظ مواقع البناء وسرعة السفر.',
    side: 'both',
    fileSizeMB: 1.1,
  },
  {
    name: 'AppleSkin',
    fileName: 'appleskin-fabric-mc1.21-2.5.1.jar',
    version: '2.5.1',
    author: 'squeek502',
    description: 'عرض قيمة الشبع ومقدار استعادة الصحة للطعام في اللعبة بدقة فائقة.',
    side: 'both',
    fileSizeMB: 0.2,
  },
  {
    name: 'No Chat Reports',
    fileName: 'NoChatReports-FABRIC-1.21-v2.8.0.jar',
    version: '2.8.0',
    author: 'Aizistral',
    description: 'تعطيل تشفير وبلاغات المحادثة لضمان الخصوصية التامة والحرية للاعبين على السيرفر.',
    side: 'server',
    fileSizeMB: 0.4,
  },
];

export const FabricModsManager: React.FC<FabricModsManagerProps> = ({
  server,
  onUpdateServer,
  lang,
}) => {
  const t = I18N[lang];
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customDesc, setCustomDesc] = useState('');
  const [customVersion, setCustomVersion] = useState('1.0.0');

  const installedMods = server.mods || [];

  const handleToggleMod = (modId: string) => {
    const time = new Date().toLocaleTimeString('en-GB');
    const target = installedMods.find((m) => m.id === modId);
    if (!target) return;

    const nextState = !target.enabled;
    const updatedMods = installedMods.map((m) =>
      m.id === modId ? { ...m, enabled: nextState } : m
    );

    const updated: LocalServer = {
      ...server,
      mods: updatedMods,
      logs: [
        ...server.logs,
        {
          id: `mod-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: `[Fabric Loader] Mod ${target.name} (${target.fileName}) ${nextState ? 'LOADED' : 'UNLOADED'}.`,
        },
      ],
    };
    updated.files = ensureFullServerFiles(updated);
    onUpdateServer(updated);
  };

  const handleUninstallMod = (modId: string) => {
    const time = new Date().toLocaleTimeString('en-GB');
    const target = installedMods.find((m) => m.id === modId);
    if (!target) return;

    const updatedMods = installedMods.filter((m) => m.id !== modId);
    // Also remove the mod jar and its folder from virtual files
    const remainingFiles = (server.files || []).filter(
      (f) =>
        f.path !== `/mods/${target.fileName}` &&
        !f.path.startsWith(`/mods/${target.name}/`)
    );

    const updated: LocalServer = {
      ...server,
      mods: updatedMods,
      files: remainingFiles,
      logs: [
        ...server.logs,
        {
          id: `mod-log-${Date.now()}`,
          timestamp: time,
          level: 'WARN',
          message: `[Fabric Loader] Removed mod: ${target.name} (${target.fileName}) from /mods/.`,
        },
      ],
    };
    updated.files = ensureFullServerFiles(updated);
    onUpdateServer(updated);
  };

  const handleInstallFromCatalog = (item: (typeof FABRIC_CATALOG)[0]) => {
    const time = new Date().toLocaleTimeString('en-GB');
    const newMod: FabricMod = {
      ...item,
      id: `mod-${Date.now()}`,
      enabled: true,
    };

    const updated: LocalServer = {
      ...server,
      mods: [...installedMods, newMod],
      logs: [
        ...server.logs,
        {
          id: `mod-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: `[Fabric Loader] Downloaded mod ${item.name} v${item.version} to /mods/${item.fileName}`,
        },
      ],
    };
    updated.files = ensureFullServerFiles(updated);
    onUpdateServer(updated);
  };

  const handleAddCustomMod = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;

    const time = new Date().toLocaleTimeString('en-GB');
    const sanitizedFileName = `${customName.trim().replace(/\s+/g, '-')}-${customVersion}.jar`;

    const newMod: FabricMod = {
      id: `mod-custom-${Date.now()}`,
      name: customName.trim(),
      fileName: sanitizedFileName,
      version: customVersion,
      author: 'Custom / Local',
      enabled: true,
      description: customDesc.trim() || 'مود فابريك مخصص تم إدراجه محلياً.',
      side: 'both',
      fileSizeMB: 1.5,
    };

    const updated: LocalServer = {
      ...server,
      mods: [...installedMods, newMod],
      logs: [
        ...server.logs,
        {
          id: `mod-log-${Date.now()}`,
          timestamp: time,
          level: 'INFO',
          message: `[Fabric Loader] Injected custom mod: ${newMod.fileName}`,
        },
      ],
    };
    updated.files = ensureFullServerFiles(updated);
    onUpdateServer(updated);

    setCustomName('');
    setCustomDesc('');
    setShowAddModal(false);
  };

  const filteredCatalog = FABRIC_CATALOG.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Layers className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-white">{t.mods}</h3>
            <span className="text-[11px] font-mono text-cyan-400 border border-cyan-800/60 bg-cyan-950/40 px-2 py-0.5 rounded">
              Fabric Loader 0.16.5
            </span>
          </div>
          <p className="text-xs text-neutral-400">{t.modsDesc}</p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-neutral-950 font-bold text-xs transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'ar' ? 'إضافة مود فابريك مخصص (.jar)' : 'Add Custom Mod'}</span>
          </button>
        </div>
      </div>

      {/* Installed Mods in /mods/ */}
      <div className="bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden">
        <div className="p-3.5 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-white">
              {lang === 'ar' ? 'المودات النشطة في مجلد /mods/' : 'Active Mods in /mods/'}
            </span>
            <span className="text-xs font-mono text-cyan-400">
              ({installedMods.length})
            </span>
          </div>
          <span className="text-xs font-mono text-neutral-400">
            {installedMods.filter((m) => m.enabled).length} {lang === 'ar' ? 'مفعل' : 'Active'}
          </span>
        </div>

        {installedMods.length === 0 ? (
          <div className="py-10 text-center text-neutral-500 italic text-xs">
            {lang === 'ar'
              ? 'لا توجد مودات فابريك مثبتة حالياً. يمكنك تثبيت أفضل مودات التسريع والعوالم من القائمة أدناه.'
              : 'No Fabric mods installed yet. Pick from the catalog below.'}
          </div>
        ) : (
          <div className="divide-y divide-neutral-800/80">
            {installedMods.map((mod) => (
              <div
                key={mod.id}
                className="p-3.5 hover:bg-neutral-900/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 font-mono text-xs font-bold ${
                      mod.enabled
                        ? 'bg-cyan-950/60 text-cyan-400 border border-cyan-800/50'
                        : 'bg-neutral-900 text-neutral-500 border border-neutral-800'
                    }`}
                  >
                    MOD
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-white text-sm">{mod.name}</span>
                      <span className="font-mono text-neutral-400 text-[11px]">v{mod.version}</span>
                      <span className="text-neutral-500 text-[11px]">بواسطة {mod.author}</span>
                      <span className="text-cyan-400/80 font-mono text-[11px]">{mod.fileSizeMB} MB</span>
                      <span className="text-[10px] text-neutral-400 font-mono bg-neutral-900 px-1.5 py-0.5 rounded border border-neutral-800">
                        {mod.side === 'both' ? 'Server & Client' : mod.side === 'server' ? 'Server-Only' : 'Client-Only'}
                      </span>
                    </div>
                    <p className="text-neutral-400 text-xs mt-0.5 line-clamp-1">{mod.description}</p>
                    <div className="text-[11px] font-mono text-neutral-500 mt-1">
                      /mods/{mod.fileName}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 justify-end shrink-0">
                  <button
                    onClick={() => handleToggleMod(mod.id)}
                    className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                      mod.enabled
                        ? 'bg-cyan-950/40 text-cyan-300 border border-cyan-800/60 hover:bg-cyan-900/40'
                        : 'bg-neutral-900 text-neutral-400 border border-neutral-800 hover:text-white'
                    }`}
                  >
                    {mod.enabled ? (
                      <>
                        <ToggleRight className="w-4 h-4 text-cyan-400" />
                        <span>{lang === 'ar' ? 'مفعل' : 'Enabled'}</span>
                      </>
                    ) : (
                      <>
                        <ToggleLeft className="w-4 h-4 text-neutral-500" />
                        <span>{lang === 'ar' ? 'معطل' : 'Disabled'}</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => handleUninstallMod(mod.id)}
                    title={lang === 'ar' ? 'إزالة المود' : 'Remove Mod'}
                    className="p-1.5 text-neutral-500 hover:text-red-400 rounded hover:bg-neutral-800 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Fabric Mod Catalog */}
      <div className="bg-neutral-900/60 border border-neutral-800 rounded-xl p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            <h4 className="text-sm font-bold text-white">
              {lang === 'ar' ? 'متجر مودات فابريك الرسمية (Modrinth / Fabric)' : 'Fabric Mods Catalog (1-Click Install)'}
            </h4>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute start-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={lang === 'ar' ? 'بحث في مودات فابريك...' : 'Search Fabric mods...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-950 border border-neutral-800 rounded-lg py-1.5 ps-8 pe-3 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredCatalog.map((cat) => {
            const isInstalled = installedMods.some(
              (m) => m.name.toLowerCase() === cat.name.toLowerCase()
            );

            return (
              <div
                key={cat.name}
                className="bg-neutral-950 border border-neutral-800/80 rounded-lg p-3.5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-semibold text-white text-sm">{cat.name}</span>
                    <span className="text-[11px] font-mono text-neutral-500">{cat.fileSizeMB} MB</span>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed line-clamp-2 mb-3">
                    {cat.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-neutral-800/60 text-xs">
                  <span className="text-[11px] font-mono text-neutral-500">
                    v{cat.version} · {cat.side === 'both' ? 'سيرفر ولاعب' : 'سيرفر'}
                  </span>

                  {isInstalled ? (
                    <span className="flex items-center gap-1 text-cyan-400 font-semibold font-mono text-xs">
                      <Check className="w-3.5 h-3.5" />
                      <span>{lang === 'ar' ? 'مثبت' : 'Installed'}</span>
                    </span>
                  ) : (
                    <button
                      onClick={() => handleInstallFromCatalog(cat)}
                      className="flex items-center gap-1 px-3 py-1 rounded bg-neutral-800 hover:bg-cyan-500 hover:text-neutral-950 text-white font-medium transition-colors"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{lang === 'ar' ? 'تثبيت' : 'Install'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Custom Mod Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-neutral-900 border border-neutral-800 rounded-xl w-full max-w-md p-5 space-y-4 shadow-2xl">
            <h4 className="text-base font-bold text-white">
              {lang === 'ar' ? 'إضافة مود فابريك مخصص إلى السيرفر' : 'Add Custom Fabric Mod (.jar)'}
            </h4>

            <form onSubmit={handleAddCustomMod} className="space-y-3">
              <div>
                <label className="text-xs text-neutral-400 block mb-1">اسم المود:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: CustomDungeons-Fabric"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400 block mb-1">الإصدار (Version):</label>
                <input
                  type="text"
                  value={customVersion}
                  onChange={(e) => setCustomVersion(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="text-xs text-neutral-400 block mb-1">الوصف:</label>
                <input
                  type="text"
                  placeholder="وصف لمميزات المود..."
                  value={customDesc}
                  onChange={(e) => setCustomDesc(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="flex gap-2 justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-cyan-400 text-neutral-950 font-bold text-xs"
                >
                  {lang === 'ar' ? 'إدراج المود وتثبيته' : 'Install Mod'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
