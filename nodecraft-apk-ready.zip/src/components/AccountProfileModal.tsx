import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Image as ImageIcon,
  Check,
  Shield,
  Crown,
  ShieldCheck,
  Sparkles,
  Lock,
  EyeOff,
  AlertTriangle,
  RefreshCw,
  Camera
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Language } from '../utils/i18n';
import { maskEmail } from '../utils/privacy';

interface AccountProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

// Preset gaming / Minecraft avatars
const PRESET_AVATARS = [
  {
    id: 'steve',
    name: 'ستيف الكلاسيكي (Steve)',
    url: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=160&auto=format&fit=crop&q=80',
  },
  {
    id: 'alex',
    name: 'أليكس (Alex)',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80',
  },
  {
    id: 'knight',
    name: 'فارس النيثر (Nether Knight)',
    url: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=160&auto=format&fit=crop&q=80',
  },
  {
    id: 'creeper_gamer',
    name: 'لاعب الكريبر (Creeper Gamer)',
    url: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=160&auto=format&fit=crop&q=80',
  },
  {
    id: 'cyber',
    name: 'سايبر كرافت (Cyber Craft)',
    url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=160&auto=format&fit=crop&q=80',
  },
  {
    id: 'redstone',
    name: 'مهندس ريدستون (Redstone)',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=160&auto=format&fit=crop&q=80',
  },
  {
    id: 'enderman',
    name: 'شبح الإندر (Ender Rogue)',
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=160&auto=format&fit=crop&q=80',
  },
  {
    id: 'diamond',
    name: 'مقاتل الدايموند (Diamond)',
    url: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=160&auto=format&fit=crop&q=80',
  },
];

export const AccountProfileModal: React.FC<AccountProfileModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const { currentUser, userProfile, updateUserProfile, isSuperAdmin, isAdmin, isChatModerator } = useAuth();

  const [displayName, setDisplayName] = useState('');
  const [photoURL, setPhotoURL] = useState('');
  const [customUrlInput, setCustomUrlInput] = useState('');
  const [selectedPresetId, setSelectedPresetId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Initialize form with current profile data
  useEffect(() => {
    if (isOpen) {
      const currentName = userProfile?.displayName || currentUser?.displayName || '';
      const currentPhoto = userProfile?.photoURL || currentUser?.photoURL || '';
      setDisplayName(currentName);
      setPhotoURL(currentPhoto);
      setCustomUrlInput(currentPhoto);

      // Check if matches preset
      const match = PRESET_AVATARS.find((p) => p.url === currentPhoto);
      setSelectedPresetId(match ? match.id : null);
      setSaveSuccess(null);
      setSaveError(null);
    }
  }, [isOpen, userProfile, currentUser]);

  if (!isOpen) return null;

  const handleSelectPreset = (preset: typeof PRESET_AVATARS[0]) => {
    setSelectedPresetId(preset.id);
    setPhotoURL(preset.url);
    setCustomUrlInput(preset.url);
  };

  const handleCustomUrlChange = (url: string) => {
    setCustomUrlInput(url);
    setPhotoURL(url);
    setSelectedPresetId(null);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim()) {
      setSaveError(lang === 'ar' ? 'يرجى كتابة اسم صحيح للحساب' : 'Please provide a valid display name');
      return;
    }

    setIsSaving(true);
    setSaveError(null);
    setSaveSuccess(null);

    const res = await updateUserProfile(displayName.trim(), photoURL.trim());
    setIsSaving(false);

    if (res.success) {
      setSaveSuccess(
        lang === 'ar'
          ? 'تم حفظ وتحديث بيانات حسابك وصورتك الرمزية بنجاح!'
          : 'Profile and avatar updated successfully!'
      );
      setTimeout(() => {
        onClose();
      }, 900);
    } else {
      setSaveError(res.error || (lang === 'ar' ? 'فشل حفظ التغييرات' : 'Failed to update profile'));
    }
  };

  const rawEmail = userProfile?.email || currentUser?.email || '';
  const maskedEmailDisplay = maskEmail(rawEmail);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-neutral-800 bg-neutral-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-tight">
                {lang === 'ar' ? 'إعدادات الحساب والملف الشخصي' : 'Account & Profile Settings'}
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">
                {lang === 'ar'
                  ? 'تعديل اسم اللاعب وتغيير الصورة الرمزية مع حماية الخصوصية'
                  : 'Update player nickname and avatar with privacy protection'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Notifications */}
          {saveSuccess && (
            <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
              <Check className="w-4 h-4 shrink-0" />
              <span>{saveSuccess}</span>
            </div>
          )}

          {saveError && (
            <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{saveError}</span>
            </div>
          )}

          {/* Privacy & Account Overview Card */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <div className="relative shrink-0">
                {photoURL ? (
                  <img
                    src={photoURL}
                    alt={displayName}
                    className="w-14 h-14 rounded-full object-cover border-2 border-emerald-500/50 shadow-md"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80';
                    }}
                  />
                ) : (
                  <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-lg flex items-center justify-center border-2 border-emerald-500/50">
                    {(displayName[0] || 'U').toUpperCase()}
                  </div>
                )}
                <div className="absolute -bottom-1 -end-1 p-1 rounded-full bg-neutral-900 border border-neutral-700 text-emerald-400">
                  <Camera className="w-3 h-3" />
                </div>
              </div>

              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-bold text-white truncate">{displayName || 'لاعب السيرفر'}</h3>
                  {isSuperAdmin ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                      <Crown className="w-3 h-3 text-amber-400" />
                      {lang === 'ar' ? 'مدير أعلى' : 'Super Admin'}
                    </span>
                  ) : isChatModerator ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30 flex items-center gap-1">
                      <Shield className="w-3 h-3 text-sky-400" />
                      {lang === 'ar' ? 'ضابط شات' : 'Mod'}
                    </span>
                  ) : isAdmin ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      {lang === 'ar' ? 'مشرف' : 'Admin'}
                    </span>
                  ) : (
                    <span className="px-1.5 py-0.5 rounded text-[10px] bg-neutral-800 text-neutral-300">
                      {lang === 'ar' ? 'عضو' : 'Member'}
                    </span>
                  )}
                </div>

                {/* Masked Email for Privacy */}
                <div className="flex items-center gap-1.5 text-xs text-neutral-400 mt-1">
                  <EyeOff className="w-3.5 h-3.5 text-emerald-400/80" />
                  <span className="font-mono text-[11px]">{maskedEmailDisplay}</span>
                  <span className="text-[10px] text-neutral-500 bg-neutral-800/80 px-1.5 py-0.2 rounded">
                    {lang === 'ar' ? 'مخفي للخصوصية' : 'Masked'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSave} className="space-y-5">
            {/* Field 1: Display Name */}
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                {lang === 'ar' ? 'اسم الحساب / لقب اللاعب (Display Name)' : 'Display Name / Nickname'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder={lang === 'ar' ? 'اكتب اسمك في السيرفر...' : 'Enter your server nickname...'}
                  maxLength={30}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 transition-colors"
                />
              </div>
              <p className="text-[11px] text-neutral-500 mt-1">
                {lang === 'ar'
                  ? 'هذا الاسم سيظهر للجميع في الشات، الاقتراحات، وقائمة اللاعبين.'
                  : 'This name appears to all players in chat, suggestions, and player lists.'}
              </p>
            </div>

            {/* Field 2: Avatar Preset Selection */}
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-2">
                {lang === 'ar' ? 'اختر صورة جاهزة من شخصيات السيرفر:' : 'Choose a character avatar preset:'}
              </label>
              <div className="grid grid-cols-4 sm:grid-cols-4 gap-2.5">
                {PRESET_AVATARS.map((preset) => {
                  const isSelected = selectedPresetId === preset.id || photoURL === preset.url;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handleSelectPreset(preset)}
                      className={`group relative p-2 rounded-xl border flex flex-col items-center gap-1.5 transition-all text-center ${
                        isSelected
                          ? 'bg-emerald-500/15 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-950'
                          : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white hover:border-neutral-700'
                      }`}
                    >
                      <div className="relative">
                        <img
                          src={preset.url}
                          alt={preset.name}
                          className="w-12 h-12 rounded-full object-cover border border-neutral-700 group-hover:scale-105 transition-transform"
                        />
                        {isSelected && (
                          <div className="absolute -top-1 -end-1 w-4 h-4 rounded-full bg-emerald-500 text-neutral-950 flex items-center justify-center">
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </div>
                        )}
                      </div>
                      <span className="text-[10px] font-medium leading-tight truncate w-full">
                        {preset.name.split(' ')[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Field 3: Custom Avatar URL */}
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5 flex items-center justify-between">
                <span>{lang === 'ar' ? 'أو أدخل رابط صورة مخصص (Custom Image URL):' : 'Or enter custom avatar image URL:'}</span>
                <ImageIcon className="w-3.5 h-3.5 text-neutral-400" />
              </label>
              <input
                type="url"
                value={customUrlInput}
                onChange={(e) => handleCustomUrlChange(e.target.value)}
                placeholder="https://images.unsplash.com/... or https://..."
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 transition-colors"
              />
              <p className="text-[11px] text-neutral-500 mt-1">
                {lang === 'ar'
                  ? 'يمكنك وضع رابط صورة خارجية أو سكن ماين كرافت خاص بك.'
                  : 'You can paste a direct link to any image or custom Minecraft skin head.'}
              </p>
            </div>

            {/* Modal Actions */}
            <div className="pt-4 border-t border-neutral-800 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-neutral-400 hover:text-white rounded-xl transition-colors"
              >
                {lang === 'ar' ? 'إلغاء' : 'Cancel'}
              </button>

              <button
                type="submit"
                disabled={isSaving || !displayName.trim()}
                className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-xl flex items-center gap-2 transition-all shadow-md disabled:opacity-50"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>{lang === 'ar' ? 'جارٍ الحفظ...' : 'Saving...'}</span>
                  </>
                ) : (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>{lang === 'ar' ? 'حفظ التغييرات' : 'Save Profile'}</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
