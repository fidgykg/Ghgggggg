import React, { useState } from 'react';
import {
  Cloud,
  CloudUpload,
  CloudDownload,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Folder,
  HardDrive,
  ShieldCheck,
  FileText,
  RefreshCw,
  Trash2,
  X,
  Database,
  Layers,
} from 'lucide-react';
import { LocalServer, BackupSnapshot } from '../types/server';
import { Language } from '../utils/i18n';

interface GoogleDriveBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  server: LocalServer;
  onUpdateServer: (updated: LocalServer) => void;
  lang: Language;
}

interface DriveCloudFile {
  id: string;
  name: string;
  sizeMB: number;
  createdAt: string;
  description: string;
  serverType: string;
  version: string;
  software: string;
}

export const GoogleDriveBackupModal: React.FC<GoogleDriveBackupModalProps> = ({
  isOpen,
  onClose,
  server,
  onUpdateServer,
  lang,
}) => {
  const isAr = lang === 'ar';
  const [activeTab, setActiveTab] = useState<'upload' | 'cloudList'>('upload');
  const [backupNote, setBackupNote] = useState('');
  const [includeWorldData, setIncludeWorldData] = useState(true);
  const [includeConfigs, setIncludeConfigs] = useState(true);
  const [includePluginsMods, setIncludePluginsMods] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatusMsg, setUploadStatusMsg] = useState('');
  const [justUploadedId, setJustUploadedId] = useState<string | null>(null);

  const serverSoftware =
    server.minecraftConfig?.serverSoftware ||
    server.webConfig?.framework ||
    server.dbConfig?.dbType ||
    'Minecraft';

  const serverVersion =
    server.minecraftConfig?.version ||
    (server.type === 'web' ? '22.14.0' : server.type === 'database' ? '7.4.2' : '1.21.4');

  const filesSizeTotalBytes =
    server.files?.reduce((acc, f) => acc + (f.sizeBytes || 0), 0) || 52000000;
  const storageMB = Number((filesSizeTotalBytes / (1024 * 1024)).toFixed(1));

  // Initial cloud files state stored in local server or default mock list
  const [cloudBackups, setCloudBackups] = useState<DriveCloudFile[]>([
    {
      id: 'gdrive_bak_101',
      name: `${server.name}_CloudAutoBackup_${serverVersion}`,
      sizeMB: Math.max(storageMB, 24.5),
      createdAt: '2025-01-24 14:30',
      description: 'نسخة سحابية متزامنة تلقائياً مع Google Drive قبل تعديل الإعدادات',
      serverType: server.type,
      version: serverVersion,
      software: serverSoftware,
    },
    {
      id: 'gdrive_bak_102',
      name: `${server.name}_FullWorldSnapshot`,
      sizeMB: Math.max(Number((storageMB * 1.4).toFixed(1)), 48.0),
      createdAt: '2025-01-20 09:15',
      description: 'نسخة كاملة لعوالم السيرفر والإعدادات',
      serverType: server.type,
      version: serverVersion,
      software: serverSoftware,
    },
  ]);

  if (!isOpen) return null;

  const handleStartCloudUpload = async () => {
    setIsUploading(true);
    setUploadProgress(10);
    setUploadStatusMsg(
      isAr
        ? 'جاري تجميع ملفات السيرفر والعوالم والإعدادات...'
        : 'Packaging server world & configuration files...'
    );

    // Progressive visual upload
    await new Promise((r) => setTimeout(r, 600));
    setUploadProgress(45);
    setUploadStatusMsg(
      isAr
        ? 'الاتصال بحساب Google Drive (ahmedopyj@gmail.com)...'
        : 'Connecting to Google Drive (ahmedopyj@gmail.com)...'
    );

    await new Promise((r) => setTimeout(r, 700));
    setUploadProgress(78);
    setUploadStatusMsg(
      isAr
        ? `جاري رفع الحزمة إلى مجلد /ahop508_Backups/${server.name}/...`
        : `Uploading bundle to /ahop508_Backups/${server.name}/...`
    );

    await new Promise((r) => setTimeout(r, 600));
    setUploadProgress(100);
    setUploadStatusMsg(
      isAr
        ? 'تم اكتمال الرفع والمزامنة بنجاح مع Google Drive!'
        : 'Cloud upload completed and verified on Google Drive!'
    );

    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
      now.getDate()
    ).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(
      now.getMinutes()
    ).padStart(2, '0')}`;

    const newDriveBackup: DriveCloudFile = {
      id: `gdrive_bak_${Date.now()}`,
      name: `${server.name}_GDrive_${now.toISOString().slice(0, 10)}`,
      sizeMB: Number((storageMB + 8.5).toFixed(1)),
      createdAt: timeStr,
      description: backupNote.trim() || (isAr ? 'نسخة سحابية عبر Google Drive' : 'Cloud snapshot via Google Drive'),
      serverType: server.type,
      version: serverVersion,
      software: serverSoftware,
    };

    setCloudBackups([newDriveBackup, ...cloudBackups]);
    setJustUploadedId(newDriveBackup.id);

    // Also register in server local backups list
    const localBak: BackupSnapshot = {
      id: `bak-${Date.now()}`,
      name: `[Google Drive] ${newDriveBackup.name}`,
      createdAt: timeStr,
      sizeMB: newDriveBackup.sizeMB,
      serverType: server.type,
      description: `Google Drive Sync (ahmedopyj@gmail.com) - ${newDriveBackup.description}`,
    };

    const updatedLogs = [
      ...server.logs,
      {
        id: `log-drive-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString('en-GB'),
        level: 'INFO' as const,
        message: `[Google Drive] Snapshot "${newDriveBackup.name}" (${newDriveBackup.sizeMB}MB) successfully uploaded to Google Drive.`,
      },
    ];

    onUpdateServer({
      ...server,
      backups: [localBak, ...server.backups],
      logs: updatedLogs,
    });

    setTimeout(() => {
      setIsUploading(false);
      setActiveTab('cloudList');
    }, 900);
  };

  const handleRestoreFromCloud = (file: DriveCloudFile) => {
    const confirmRestore = window.confirm(
      isAr
        ? `هل تريد استعادة السيرفر من النسخة السحابية "${file.name}"؟ سيتم استرجاع الإعدادات والعالم إلى حالته عند تاريخ ${file.createdAt}.`
        : `Do you want to restore the server from cloud snapshot "${file.name}"?`
    );
    if (!confirmRestore) return;

    const updatedLogs = [
      ...server.logs,
      {
        id: `restore-drive-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString('en-GB'),
        level: 'WARN' as const,
        message: `[Google Drive] Restored server state from cloud backup: "${file.name}" (${file.sizeMB}MB).`,
      },
    ];

    onUpdateServer({
      ...server,
      logs: updatedLogs,
    });

    alert(
      isAr
        ? `تم استعادة النسخة السحابية "${file.name}" بنجاح!`
        : `Successfully restored cloud backup "${file.name}"!`
    );
    onClose();
  };

  const handleDeleteCloudFile = (id: string) => {
    setCloudBackups(cloudBackups.filter((f) => f.id !== id));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 border-b border-neutral-800 bg-neutral-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">
                  {isAr ? 'النسخ السحابي مع Google Drive' : 'Google Drive Cloud Sync'}
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-950/80 border border-blue-800/60 text-blue-400 font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  {isAr ? 'متصل وموثق' : 'Connected'}
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5 font-mono">
                ahmedopyj@gmail.com · gen-lang-client-0635046861
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-neutral-800 bg-neutral-950/50 px-5 pt-2 text-xs font-semibold gap-4">
          <button
            onClick={() => setActiveTab('upload')}
            className={`pb-2.5 flex items-center gap-2 border-b-2 transition-colors ${
              activeTab === 'upload'
                ? 'border-blue-500 text-blue-400 font-bold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <CloudUpload className="w-4 h-4" />
            <span>{isAr ? 'رفع نسخة سحابية جديدة' : 'Upload New Cloud Backup'}</span>
          </button>
          <button
            onClick={() => setActiveTab('cloudList')}
            className={`pb-2.5 flex items-center gap-2 border-b-2 transition-colors relative ${
              activeTab === 'cloudList'
                ? 'border-blue-500 text-blue-400 font-bold'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <CloudDownload className="w-4 h-4" />
            <span>{isAr ? 'النسخ المخزنة في السحابة' : 'Stored Cloud Backups'}</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-neutral-800 text-neutral-300 font-mono">
              {cloudBackups.length}
            </span>
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4">
          {activeTab === 'upload' ? (
            <div className="space-y-4">
              {/* Server Info Card */}
              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold">
                    {serverSoftware.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold text-white">{server.name}</div>
                    <div className="text-[11px] text-neutral-400 font-mono">
                      {serverSoftware} · {serverVersion} · المنفذ {server.port}
                    </div>
                  </div>
                </div>

                <div className="text-end font-mono">
                  <div className="text-neutral-400 text-[10px]">
                    {isAr ? 'حجم الملفات الحالي' : 'Current Size'}
                  </div>
                  <div className="font-bold text-cyan-400">{storageMB} MB</div>
                </div>
              </div>

              {/* Upload Scope Checkboxes */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-neutral-300 block">
                  {isAr ? 'محتويات النسخة السحابية:' : 'Cloud Backup Contents:'}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <label className="flex items-center gap-2 p-2.5 rounded-lg border border-neutral-800 bg-neutral-950/60 text-xs text-neutral-300 cursor-pointer hover:border-neutral-700">
                    <input
                      type="checkbox"
                      checked={includeWorldData}
                      onChange={(e) => setIncludeWorldData(e.target.checked)}
                      className="rounded border-neutral-700 text-blue-500 focus:ring-blue-500"
                    />
                    <span>{isAr ? 'بيانات العالم (Worlds)' : 'World Data'}</span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 rounded-lg border border-neutral-800 bg-neutral-950/60 text-xs text-neutral-300 cursor-pointer hover:border-neutral-700">
                    <input
                      type="checkbox"
                      checked={includeConfigs}
                      onChange={(e) => setIncludeConfigs(e.target.checked)}
                      className="rounded border-neutral-700 text-blue-500 focus:ring-blue-500"
                    />
                    <span>{isAr ? 'ملفات التكوين (Configs)' : 'Configs & Props'}</span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 rounded-lg border border-neutral-800 bg-neutral-950/60 text-xs text-neutral-300 cursor-pointer hover:border-neutral-700">
                    <input
                      type="checkbox"
                      checked={includePluginsMods}
                      onChange={(e) => setIncludePluginsMods(e.target.checked)}
                      className="rounded border-neutral-700 text-blue-500 focus:ring-blue-500"
                    />
                    <span>{isAr ? 'البلوجنات والمودات' : 'Plugins & Mods'}</span>
                  </label>
                </div>
              </div>

              {/* Notes Input */}
              <div>
                <label className="text-xs font-semibold text-neutral-300 mb-1.5 block">
                  {isAr ? 'ملاحظة أو وصف للنسخة (اختياري):' : 'Backup Note (Optional):'}
                </label>
                <input
                  type="text"
                  placeholder={
                    isAr
                      ? 'مثال: نسخة استقرار بعد بناء قلعة السيرفر الرئيسية'
                      : 'e.g. Snapshot before major plugin overhaul'
                  }
                  value={backupNote}
                  onChange={(e) => setBackupNote(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:border-blue-500 focus:outline-none"
                />
              </div>

              {/* Google Drive Folder Location Info */}
              <div className="p-3 bg-blue-950/20 border border-blue-900/30 rounded-xl text-xs space-y-1.5">
                <div className="flex items-center gap-1.5 text-blue-400 font-semibold">
                  <Folder className="w-3.5 h-3.5" />
                  <span>{isAr ? 'المسار على Google Drive:' : 'Drive Storage Destination:'}</span>
                </div>
                <div className="font-mono text-[11px] text-neutral-300">
                  My Drive / ahop508_Backups / {server.name} / {serverVersion}/
                </div>
                <div className="text-[10px] text-neutral-400 leading-relaxed">
                  {isAr
                    ? 'سيتم رفع الملف بصيغة مضغوطة مشفرة متوافقة مع Google Drive API ويمكن تنزيلها أو استعادتها في أي وقت.'
                    : 'The archive will be securely uploaded via the Google Drive API and can be restored or downloaded at any time.'}
                </div>
              </div>

              {/* Upload Progress */}
              {isUploading && (
                <div className="p-3.5 bg-neutral-950 border border-blue-500/30 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-blue-400 font-semibold flex items-center gap-2">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>{uploadStatusMsg}</span>
                    </span>
                    <span className="font-mono font-bold text-white">{uploadProgress}%</span>
                  </div>
                  <div className="w-full bg-neutral-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-blue-500 to-cyan-400 h-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Action Button */}
              <button
                type="button"
                disabled={isUploading}
                onClick={handleStartCloudUpload}
                className="w-full py-2.5 rounded-xl bg-blue-500 hover:bg-blue-400 disabled:opacity-50 text-neutral-950 font-bold text-xs transition-colors flex items-center justify-center gap-2 shadow-lg shadow-blue-500/10"
              >
                <CloudUpload className="w-4 h-4" />
                <span>
                  {isUploading
                    ? isAr
                      ? 'جاري الرفع إلى Google Drive...'
                      : 'Uploading to Google Drive...'
                    : isAr
                    ? 'بدء الرفع السحابي إلى Google Drive الآن'
                    : 'Start Google Drive Cloud Upload Now'}
                </span>
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-neutral-400 mb-1">
                <span>
                  {isAr
                    ? 'النسخ الاحتياطية المتوفرة في حساب Google Drive المرتبط:'
                    : 'Available snapshots stored in linked Google Drive:'}
                </span>
                <span className="font-mono text-blue-400">{cloudBackups.length} ملفات</span>
              </div>

              {cloudBackups.length === 0 ? (
                <div className="py-10 text-center text-neutral-500 italic text-xs border border-neutral-800 rounded-xl">
                  {isAr
                    ? 'لا توجد نسخ سحابية مخزنة على Google Drive حالياً.'
                    : 'No cloud backups found on Google Drive.'}
                </div>
              ) : (
                <div className="space-y-2">
                  {cloudBackups.map((bak) => {
                    const isNew = justUploadedId === bak.id;
                    return (
                      <div
                        key={bak.id}
                        className={`p-3.5 rounded-xl border transition-all ${
                          isNew
                            ? 'bg-blue-950/30 border-blue-500/60'
                            : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3 mb-2">
                          <div className="flex items-start gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shrink-0 mt-0.5">
                              <Cloud className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="text-xs font-bold text-white flex items-center gap-2">
                                <span>{bak.name}</span>
                                {isNew && (
                                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 font-semibold">
                                    {isAr ? 'تم الرفع الآن' : 'Just uploaded'}
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-neutral-400 font-mono mt-0.5 flex items-center gap-2">
                                <span>{bak.createdAt}</span>
                                <span>·</span>
                                <span className="text-cyan-400">{bak.sizeMB} MB</span>
                                <span>·</span>
                                <span>{bak.software} {bak.version}</span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              onClick={() => handleRestoreFromCloud(bak)}
                              className="px-2.5 py-1 rounded bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/40 text-blue-300 text-xs font-semibold flex items-center gap-1 transition-colors"
                            >
                              <CloudDownload className="w-3.5 h-3.5" />
                              <span>{isAr ? 'استعادة' : 'Restore'}</span>
                            </button>
                            <button
                              onClick={() => handleDeleteCloudFile(bak.id)}
                              className="p-1 rounded text-neutral-500 hover:text-red-400 transition-colors"
                              title={isAr ? 'حذف من السحابة' : 'Delete'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {bak.description && (
                          <div className="text-[11px] text-neutral-400 bg-neutral-900/60 p-2 rounded-lg leading-relaxed">
                            {bak.description}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950 flex items-center justify-between text-xs text-neutral-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
            <span>
              {isAr ? 'Google Drive OAuth: مفعل ونشط' : 'Google Drive OAuth: Active'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white font-semibold transition-colors"
          >
            {isAr ? 'إغلاق' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
