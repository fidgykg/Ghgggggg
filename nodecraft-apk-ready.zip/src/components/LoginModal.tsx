import React, { useState } from 'react';
import { X, Lock, LogIn, User, Sparkles, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { SUPER_ADMIN_EMAIL } from '../lib/firebase';
import { Language } from '../utils/i18n';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose, lang }) => {
  const { loginAs, signInWithGoogle, loading, currentUser } = useAuth();
  const [playerName, setPlayerName] = useState('');
  const [playerEmail, setPlayerEmail] = useState('');

  if (!isOpen) return null;

  const handlePlayerJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!playerName.trim()) return;
    const email = playerEmail.trim() || `${playerName.toLowerCase().replace(/\s+/g, '')}@nodecraft.local`;
    // Regular users always log in strictly as 'user' role. Admin and Moderator roles are granted only by Super Admin.
    loginAs('user', email, playerName.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="relative px-6 py-5 border-b border-neutral-800 bg-gradient-to-r from-neutral-900 via-neutral-900 to-emerald-950/40">
          <button
            onClick={onClose}
            className="absolute top-5 end-5 p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                {lang === 'ar' ? 'تسجيل الدخول' : 'Sign In'}
              </h2>
              <p className="text-xs text-neutral-400">
                {lang === 'ar'
                  ? 'سجّل دخولك للمشاركة في الشات والاقتراحات وإدارة السيرفرات'
                  : 'Sign in to access chat, suggestions, and server tools'}
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Real Google Authentication */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2.5">
              {lang === 'ar' ? 'الدخول بحساب Google' : 'Sign in with Google'}
            </label>

            <button
              type="button"
              disabled={loading}
              onClick={() => {
                signInWithGoogle();
                onClose();
              }}
              className="w-full flex items-center justify-center gap-3 py-2.5 px-4 bg-white hover:bg-neutral-100 text-neutral-900 font-semibold text-xs rounded-xl transition-all shadow-sm disabled:opacity-50"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>
                {lang === 'ar' ? 'متابعة باستخدام حساب Google' : 'Continue with Google Account'}
              </span>
            </button>

            <div className="mt-2.5 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300 flex items-start gap-2">
              <Sparkles className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
              <span>
                {lang === 'ar'
                  ? `الحساب (${SUPER_ADMIN_EMAIL}) يمتلك صلاحيات المدير العام الأعلى (Super Admin) حصرياً.`
                  : `Account (${SUPER_ADMIN_EMAIL}) exclusively holds Super Admin authority.`}
              </span>
            </div>
          </div>

          {/* Divider */}
          <div className="relative flex items-center justify-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-neutral-800" />
            </div>
            <span className="relative px-3 bg-neutral-900 text-xs text-neutral-500">
              {lang === 'ar' ? 'أو دخول كلاعب / عضو' : 'Or join as Player / Member'}
            </span>
          </div>

          {/* Player/Member Guest Registration */}
          <form onSubmit={handlePlayerJoin} className="space-y-3">
            <div>
              <label className="text-xs text-neutral-300 block mb-1 font-medium">
                {lang === 'ar' ? 'اسم اللاعب / العضو' : 'Player / Member Name'}
              </label>
              <div className="relative">
                <User className="absolute start-3 top-2.5 w-4 h-4 text-neutral-500" />
                <input
                  type="text"
                  required
                  placeholder={lang === 'ar' ? 'مثال: أحمد اللاعب' : 'e.g. AlexPlayer'}
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-lg ps-9 pe-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-neutral-300 block mb-1 font-medium">
                {lang === 'ar' ? 'البريد الإلكتروني (اختياري)' : 'Email (Optional)'}
              </label>
              <input
                type="email"
                placeholder={lang === 'ar' ? 'player@example.com' : 'player@example.com'}
                value={playerEmail}
                onChange={(e) => setPlayerEmail(e.target.value)}
                className="w-full bg-neutral-950 border border-neutral-800 rounded-lg px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="p-2.5 rounded-lg bg-neutral-950 border border-neutral-800 text-[10px] text-neutral-400 flex items-center gap-2">
              <AlertCircle className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
              <span>
                {lang === 'ar'
                  ? 'رتبة المشرف وضابط الشات يتم تعيينها حصرياً بواسطة مدير النظام من لوحة التحكم.'
                  : 'Admin and Chat Moderator ranks can only be granted by the Super Admin in Admin Panel.'}
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 shadow-sm"
            >
              <LogIn className="w-4 h-4" />
              <span>{lang === 'ar' ? 'دخول كعضو' : 'Sign In as Member'}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
