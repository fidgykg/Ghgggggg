import React, { useState, useMemo } from 'react';
import {
  Download,
  CheckCircle2,
  HardDrive,
  Cpu,
  Layers,
  Sparkles,
  Info,
  Calendar,
  ShieldCheck,
  Server as ServerIcon,
  Search,
  Filter,
  Clock,
  History,
} from 'lucide-react';
import {
  MINECRAFT_SOFTWARES,
  WEB_SOFTWARES,
  DATABASE_SOFTWARES,
  SoftwareVersionInfo,
  ServerSoftwareMeta,
  getSoftwareMeta,
} from '../data/softwareVersions';
import { Language } from '../utils/i18n';
import { ServerType } from '../types/server';

interface SoftwareVersionSelectorProps {
  category: ServerType;
  selectedSoftware: string;
  onSoftwareChange: (software: string) => void;
  selectedVersion: string;
  onVersionChange: (version: string, versionInfo: SoftwareVersionInfo) => void;
  lang: Language;
  compact?: boolean;
}

export const SoftwareVersionSelector: React.FC<SoftwareVersionSelectorProps> = ({
  category,
  selectedSoftware,
  onSoftwareChange,
  selectedVersion,
  onVersionChange,
  lang,
  compact = false,
}) => {
  const isAr = lang === 'ar';
  const [versionSearch, setVersionSearch] = useState('');
  const [eraFilter, setEraFilter] = useState<'all' | 'modern' | 'middle' | 'legacy' | 'classic'>('all');

  // Get available software list for current category
  const softwareDict =
    category === 'web'
      ? WEB_SOFTWARES
      : category === 'database'
      ? DATABASE_SOFTWARES
      : MINECRAFT_SOFTWARES;

  const softwareList: ServerSoftwareMeta[] = Object.values(softwareDict);

  // Active software metadata
  const currentMeta = getSoftwareMeta(category, selectedSoftware) || softwareList[0];

  // Currently selected version info
  const activeVersionInfo =
    currentMeta.versions.find((v) => v.version === selectedVersion) ||
    currentMeta.versions[0];

  const handleSoftwareSelect = (swId: string) => {
    onSoftwareChange(swId);
    const meta = softwareDict[swId];
    if (meta && meta.versions.length > 0) {
      // Pick recommended or latest version by default
      const recommended =
        meta.versions.find((v) => v.tag === 'recommended') || meta.versions[0];
      onVersionChange(recommended.version, recommended);
    }
  };

  // Filtered versions based on search and era
  const filteredVersions = useMemo(() => {
    return currentMeta.versions.filter((v) => {
      // Search text match
      const query = versionSearch.trim().toLowerCase();
      const matchesSearch =
        !query ||
        v.version.toLowerCase().includes(query) ||
        v.fileName.toLowerCase().includes(query) ||
        (v.buildNumber && v.buildNumber.toLowerCase().includes(query)) ||
        (v.descriptionAr && v.descriptionAr.toLowerCase().includes(query)) ||
        (v.descriptionEn && v.descriptionEn.toLowerCase().includes(query));

      // Era filter match
      let matchesEra = true;
      if (eraFilter !== 'all') {
        if (v.era) {
          matchesEra = v.era === eraFilter;
        } else {
          // Fallback parsing for web/db
          matchesEra = true;
        }
      }

      return matchesSearch && matchesEra;
    });
  }, [currentMeta.versions, versionSearch, eraFilter]);

  return (
    <div className="space-y-4">
      {/* 1. Software / System Choice */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-semibold text-neutral-300 flex items-center gap-1.5">
            <ServerIcon className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              {isAr ? 'اختر نظام السيرفر (Server Software):' : 'Select Server Software:'}
            </span>
          </label>
          <span className="text-[11px] text-neutral-400 font-mono">
            {isAr
              ? `${softwareList.length} أنظمة متوفرة للتنزيل`
              : `${softwareList.length} systems available`}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {softwareList.map((sw) => {
            const isSelected = selectedSoftware === sw.id;
            return (
              <button
                key={sw.id}
                type="button"
                onClick={() => handleSoftwareSelect(sw.id)}
                className={`p-2.5 rounded-lg border text-start transition-all relative overflow-hidden ${
                  isSelected
                    ? 'bg-neutral-800/90 border-emerald-500 shadow-sm shadow-emerald-500/10'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-300 hover:border-neutral-700 hover:bg-neutral-900/40'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-xs font-bold ${isSelected ? 'text-emerald-400' : 'text-white'}`}>
                    {sw.name.split(' ')[0]}
                  </span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-400">
                    {sw.badge}
                  </span>
                </div>
                <div className="text-[10px] text-neutral-400 line-clamp-1 leading-tight">
                  {isAr ? sw.shortDescAr : sw.shortDescEn}
                </div>
                {isSelected && (
                  <div className="absolute top-1 end-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Version Numbers Available to Download */}
      <div className="bg-neutral-950/70 border border-neutral-800 rounded-xl p-3.5 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-xs font-semibold text-neutral-200">
              {isAr
                ? `طيف إصدارات ${currentMeta.name.split(' ')[0]} (من 26.3 حتى 1.7.5):`
                : `${currentMeta.name.split(' ')[0]} Versions (from 26.3 down to 1.7.5):`}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
              {activeVersionInfo?.fileName || activeVersionInfo?.version}
            </span>
          </div>
        </div>

        {/* Quick Search and Filter Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute start-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={versionSearch}
              onChange={(e) => setVersionSearch(e.target.value)}
              placeholder={
                isAr
                  ? 'بحث برقم الإصدار (مثال: 1.21.11 أو 1.21.11-26.2 أو 1.7.5)...'
                  : 'Search version (e.g. 1.21.11, 1.21.11-26.2, 1.7.5)...'
              }
              className="w-full bg-neutral-900 border border-neutral-800 rounded-lg ps-8 pe-3 py-1.5 text-xs text-white placeholder-neutral-500 focus:border-emerald-500 focus:outline-none"
            />
            {versionSearch && (
              <button
                type="button"
                onClick={() => setVersionSearch('')}
                className="absolute end-2 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-white text-xs px-1"
              >
                ✕
              </button>
            )}
          </div>

          {/* Era Filter Buttons (Minecraft specific) */}
          {(category === 'minecraft' || category === 'game') && (
            <div className="flex items-center gap-1 overflow-x-auto text-[10px] font-mono py-0.5">
              <button
                type="button"
                onClick={() => setEraFilter('all')}
                className={`px-2 py-1 rounded border transition-colors whitespace-nowrap ${
                  eraFilter === 'all'
                    ? 'bg-neutral-800 text-white border-neutral-600'
                    : 'bg-neutral-950/60 text-neutral-400 border-neutral-800 hover:text-white'
                }`}
              >
                {isAr ? 'الكل' : 'All'} ({currentMeta.versions.length})
              </button>

              <button
                type="button"
                onClick={() => setEraFilter('modern')}
                className={`px-2 py-1 rounded border transition-colors whitespace-nowrap ${
                  eraFilter === 'modern'
                    ? 'bg-emerald-950 border-emerald-500 text-emerald-400'
                    : 'bg-neutral-950/60 text-neutral-400 border-neutral-800 hover:text-white'
                }`}
              >
                26.3 - 1.21
              </button>

              <button
                type="button"
                onClick={() => setEraFilter('middle')}
                className={`px-2 py-1 rounded border transition-colors whitespace-nowrap ${
                  eraFilter === 'middle'
                    ? 'bg-cyan-950 border-cyan-500 text-cyan-400'
                    : 'bg-neutral-950/60 text-neutral-400 border-neutral-800 hover:text-white'
                }`}
              >
                1.17 - 1.20
              </button>

              <button
                type="button"
                onClick={() => setEraFilter('legacy')}
                className={`px-2 py-1 rounded border transition-colors whitespace-nowrap ${
                  eraFilter === 'legacy'
                    ? 'bg-purple-950 border-purple-500 text-purple-400'
                    : 'bg-neutral-950/60 text-neutral-400 border-neutral-800 hover:text-white'
                }`}
              >
                1.12 - 1.16
              </button>

              <button
                type="button"
                onClick={() => setEraFilter('classic')}
                className={`px-2 py-1 rounded border transition-colors whitespace-nowrap ${
                  eraFilter === 'classic'
                    ? 'bg-amber-950 border-amber-500 text-amber-400'
                    : 'bg-neutral-950/60 text-neutral-400 border-neutral-800 hover:text-white'
                }`}
              >
                1.7.5 - 1.11
              </button>
            </div>
          )}
        </div>

        {/* Version Badges Grid */}
        {filteredVersions.length === 0 ? (
          <div className="py-6 text-center text-xs text-neutral-500 italic border border-neutral-800/60 rounded-lg">
            {isAr
              ? `لا توجد نتائج للإصدار "${versionSearch}". جرب البحث برقم آخر كـ 1.7.5 أو 1.20.`
              : `No versions found matching "${versionSearch}".`}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-2 max-h-56 overflow-y-auto pe-1">
            {filteredVersions.map((v) => {
              const isVerSelected = selectedVersion === v.version;
              const isClassic175 = v.version === '1.7.5';
              const is263 = v.version === '26.3' || v.version === '26.3.0';

              return (
                <button
                  key={v.version}
                  type="button"
                  onClick={() => onVersionChange(v.version, v)}
                  className={`p-2 rounded-lg border text-start transition-all relative ${
                    isVerSelected
                      ? 'bg-emerald-950/50 border-emerald-500 text-white shadow-sm ring-1 ring-emerald-500/30'
                      : 'bg-neutral-900/60 border-neutral-800/80 text-neutral-300 hover:border-neutral-700 hover:text-white'
                  }`}
                >
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="font-mono text-xs font-bold flex items-center gap-1">
                      {v.version}
                      {isClassic175 && (
                        <span className="text-[8px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-400 font-bold">
                          1.7.5
                        </span>
                      )}
                      {is263 && (
                        <span className="text-[8px] px-1 py-0.2 rounded bg-blue-500/20 text-blue-400 font-bold">
                          26.3
                        </span>
                      )}
                    </span>
                    {v.tag === 'latest' && !is263 && (
                      <span className="text-[9px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-semibold">
                        {isAr ? 'الأحدث' : 'Latest'}
                      </span>
                    )}
                    {v.tag === 'recommended' && (
                      <span className="text-[9px] px-1 py-0.2 rounded bg-cyan-500/20 text-cyan-400 font-semibold">
                        {isAr ? 'موصى به' : 'Rec'}
                      </span>
                    )}
                    {v.tag === 'lts' && (
                      <span className="text-[9px] px-1 py-0.2 rounded bg-purple-500/20 text-purple-400 font-semibold">
                        LTS
                      </span>
                    )}
                  </div>

                  <div className="text-[10px] text-neutral-400 font-mono flex items-center justify-between">
                    <span>{v.fileSizeMB}MB</span>
                    {v.javaRequirement ? (
                      <span className="text-[9px] opacity-75 truncate max-w-[70px]">
                        {v.javaRequirement.replace(' LTS', '')}
                      </span>
                    ) : (
                      v.buildNumber && <span className="opacity-75">{v.buildNumber}</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {/* Selected Version Detail Card */}
        {activeVersionInfo && (
          <div className="bg-neutral-900/90 border border-neutral-800 rounded-lg p-3 text-xs space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-neutral-800/70 pb-2">
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-emerald-400 text-sm">
                  {currentMeta.name.split(' ')[0]} {activeVersionInfo.version}
                </span>
                <span className="text-[11px] text-neutral-400 font-mono">
                  ({activeVersionInfo.tagAr})
                </span>
              </div>
              <div className="flex items-center gap-3 text-[11px] text-neutral-400 font-mono">
                {activeVersionInfo.javaRequirement && (
                  <span className="flex items-center gap-1 text-amber-300/90">
                    <Cpu className="w-3 h-3" />
                    <span>{activeVersionInfo.javaRequirement}</span>
                  </span>
                )}
                <span className="flex items-center gap-1 text-neutral-300">
                  <HardDrive className="w-3 h-3 text-cyan-400" />
                  <span>{activeVersionInfo.fileSizeMB} MB</span>
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-neutral-500" />
                  <span>{activeVersionInfo.releaseDate}</span>
                </span>
              </div>
            </div>

            <div className="flex items-start justify-between gap-3 text-[11px] text-neutral-400 leading-relaxed">
              <span>{isAr ? activeVersionInfo.descriptionAr : activeVersionInfo.descriptionEn}</span>
              <span className="text-emerald-400 shrink-0 flex items-center gap-1 font-mono text-[10px] bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-800/40">
                <ShieldCheck className="w-3 h-3" />
                {isAr ? 'جاهز للتنزيل المباشر' : 'Verified Binary'}
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
