<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/86e79393-b75f-4b49-9917-2e9b42a9afc4

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## بناء APK
1. ارفع المشروع إلى GitHub  2. تبويب Actions ← Build APK ← Run workflow  3. نزّل app-debug.apk من Artifacts.
محلياً: npm install && npm run build && npx cap add android && npx cap sync android && cd android && ./gradlew assembleDebug
